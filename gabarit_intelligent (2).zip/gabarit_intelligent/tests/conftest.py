import random
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from smart_jig import body_from_profile  # noqa: E402
from camera_measure import LM  # noqa: E402


def synthetic_frames(body, n=40, vis=0.95, seed=1, noise_px=1.5, arms_up=False, asym=1.0):
    """Points MediaPipe synthétiques d'une personne de morphologie connue, debout bras le long
    du corps, vue de face (400 px/m, image 720×1280). Sert uniquement aux TESTS du traitement."""
    rnd = random.Random(seed)
    W, H, K, X0, FLOOR = 720, 1280, 400.0, 360.0, 1200.0
    half = body.shoulder_width / 2
    ys = {"eye": body.eye_h, "sh": body.shoulder_h}
    el_y = body.shoulder_h - body.upper_arm
    wr_y = el_y - body.forearm
    pts3 = {
        "l_eye": (-0.03, ys["eye"]), "r_eye": (0.03, ys["eye"]),
        "l_sh": (-half, ys["sh"]), "r_sh": (half, ys["sh"]),
        "l_el": (-half - 0.01, el_y), "r_el": (half + 0.01, body.shoulder_h - body.upper_arm * asym),
        "l_wr": (-half - 0.01, wr_y), "r_wr": (half + 0.01, body.shoulder_h - body.upper_arm * asym - body.forearm),
        "l_hip": (-0.09, 0.53 * body.stature), "r_hip": (0.09, 0.53 * body.stature),
        "l_heel": (-0.09, 0.0), "r_heel": (0.09, 0.0), "l_toe": (-0.10, 0.0), "r_toe": (0.10, 0.0),
    }
    if arms_up:
        pts3["l_el"] = (-half - 0.25, body.shoulder_h + 0.05)
        pts3["l_wr"] = (-half - 0.45, body.shoulder_h + 0.15)
    frames = []
    for _ in range(n):
        f = [[0.5, 0.5, 0.0, 0.1] for _ in range(33)]
        for k, (x, y) in pts3.items():
            px = X0 + x * K + rnd.gauss(0, noise_px)
            py = FLOOR - y * K + rnd.gauss(0, noise_px)
            f[LM[k]] = [px / W, py / H, 0.0, vis]
        frames.append(f)
    return frames, W, H


@pytest.fixture
def p50():
    return body_from_profile("P50F")
