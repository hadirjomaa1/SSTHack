"""Tests du traitement des points webcam et du protocole ESP32."""
import pytest

from conftest import synthetic_frames
from camera_measure import process_webcam_frames
from firmware_protocol import SimulatedController, build_move, checksum, parse_frame
from smart_jig import JigConfig, move_time


# ---------- Acquisition webcam 2D
def test_webcam_recovers_known_body(p50):
    frames, W, H = synthetic_frames(p50)
    r = process_webcam_frames(frames, W, H, p50.stature)
    assert r["ok"], r["errors"]
    b = r["body"]
    for k in ("eye_h", "shoulder_h", "upper_arm", "forearm", "shoulder_width"):
        assert b[k] == pytest.approx(getattr(p50, k), abs=0.02), k
    assert b["source"] == "webcam_2d" and b["origin"]["stature"] == "declaree"
    assert b["uncertainty_m"] > 0
    assert any("non calibrée" in w for w in r["warnings"])


def test_webcam_requires_declared_stature(p50):
    frames, W, H = synthetic_frames(p50)
    r = process_webcam_frames(frames, W, H, None)
    assert not r["ok"] and "Stature déclarée" in r["errors"][0]


def test_webcam_refuses_low_visibility(p50):
    frames, W, H = synthetic_frames(p50, vis=0.3)
    r = process_webcam_frames(frames, W, H, p50.stature)
    assert not r["ok"] and "Détection insuffisante" in r["errors"][0]
    assert r["body"] is None


def test_webcam_refuses_wrong_posture(p50):
    frames, W, H = synthetic_frames(p50, arms_up=True)
    r = process_webcam_frames(frames, W, H, p50.stature)
    assert not r["ok"] and "bras non tendus" in r["errors"][0]


def test_webcam_flags_asymmetry(p50):
    frames, W, H = synthetic_frames(p50, asym=1.3)
    r = process_webcam_frames(frames, W, H, p50.stature)
    assert not r["ok"] and any("Asymétrie" in e for e in r["errors"])


def test_webcam_rejects_outliers(p50):
    frames, W, H = synthetic_frames(p50, n=40)
    bad, _, _ = synthetic_frames(p50, n=3, seed=9, noise_px=60)
    r = process_webcam_frames(frames + bad, W, H, p50.stature)
    assert r["ok"] and r["quality"]["outliers_rejected"] >= 1


# ---------- Protocole ESP32
def test_checksum_and_frame():
    cmd = build_move(JigConfig(1.21, 7.0, 0.378), 12)
    assert cmd.startswith("MOVE H=1210 A=70 D=378 ID=12*")
    body, ok = parse_frame(cmd)
    assert ok and body == "MOVE H=1210 A=70 D=378 ID=12"
    assert not parse_frame(body + "*00")[1] or checksum(body) == "00"


def test_build_move_refuses_out_of_range():
    with pytest.raises(ValueError):
        build_move(JigConfig(1.60, 0, 0.4), 1)
    with pytest.raises(ValueError):
        build_move(JigConfig(1.2, 0, 0.4), 0)


def test_simulated_controller_is_labelled_and_timed():
    src, dst = JigConfig(1.30, 15, 0.45), JigConfig(1.16, 7, 0.378)
    plan = SimulatedController().plan_move(src, dst)
    assert plan["simulated"] is True and "SIMULATION" in plan["note"]
    assert plan["total_s"] == pytest.approx(move_time(src, dst), abs=0.01)
    assert plan["events"][-1]["line"].startswith("DONE H=1160 A=70 D=378")
