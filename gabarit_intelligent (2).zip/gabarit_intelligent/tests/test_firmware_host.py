"""Compile le firmware ESP32 réel avec un bouchon Arduino et exécute ses tests de logique sur PC."""
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.mark.skipif(shutil.which("g++") is None, reason="g++ absent")
def test_firmware_logic(tmp_path):
    exe = tmp_path / "fwtest"
    subprocess.run(["g++", "-std=c++17", "-I", str(ROOT / "tests/firmware_host"),
                    str(ROOT / "tests/firmware_host/test_firmware.cpp"), "-o", str(exe)], check=True)
    r = subprocess.run([str(exe)], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout


def test_cli_compare_runs():
    r = subprocess.run(["python3", "smart_jig.py", "--compare"], cwd=ROOT / "backend", capture_output=True, text=True, timeout=120)
    assert r.returncode == 0 and "P50F" in r.stdout and "optimal" in r.stdout
