"""Tests des échanges API (FastAPI TestClient)."""
import pytest
from fastapi.testclient import TestClient

from conftest import synthetic_frames
from app import app
from smart_jig import body_from_profile

client = TestClient(app)


@pytest.fixture(scope="module")
def body():
    r = client.post("/api/acquire", json={"mode": "simulation", "profile_id": "P50F"})
    assert r.status_code == 200 and r.json()["ok"]
    return r.json()["body"]


def test_health():
    r = client.get("/api/health").json()
    assert r["status"] == "ok" and r["engine"] == "python"
    assert r["capabilities"]["esp32_connected"] is False


def test_profiles():
    r = client.get("/api/profiles").json()
    assert {p["id"] for p in r["profiles"]} >= {"P5F", "P50F", "P95F", "P95H"}
    assert all(p["validation"]["ok"] for p in r["profiles"])
    assert r["axis_limits"]["h"] == [0.85, 1.45]


def test_acquire_unknown_profile():
    r = client.post("/api/acquire", json={"mode": "simulation", "profile_id": "XX"})
    assert r.status_code == 404 and r.json()["error"]["code"] == "profil_inconnu"


def test_acquire_custom_incoherent():
    dims = {**body_from_profile("P50F").dims(), "eye_h": 1.20}
    r = client.post("/api/acquire", json={"mode": "personnalise", "dimensions": dims}).json()
    assert r["ok"] is False and r["errors"]


def test_acquire_custom_missing_dimension():
    r = client.post("/api/acquire", json={"mode": "personnalise", "dimensions": {"stature": 1.6}})
    assert r.status_code == 422 and r.json()["error"]["code"] == "dimensions_manquantes"


def test_acquire_webcam_frames():
    b = body_from_profile("P50F")
    frames, W, H = synthetic_frames(b)
    r = client.post("/api/acquire", json={"mode": "webcam_2d", "frames": frames, "image_w": W, "image_h": H,
                                          "declared_stature": b.stature}).json()
    assert r["ok"] and r["body"]["source"] == "webcam_2d"


def test_acquire_realsense_without_hardware():
    r = client.post("/api/acquire", json={"mode": "realsense"})
    assert r.status_code == 503 and r.json()["error"]["code"] == "materiel_requis"


def test_invalid_payload_is_422():
    r = client.post("/api/acquire", json={"mode": "laser"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "requete_invalide"


def test_evaluate(body):
    r = client.post("/api/evaluate", json={"body": body, "config": {"h": 1.2, "a": 10, "d": 0.4}}).json()
    assert len(r["postures"]["work"]) == 35 and "rest" in r["postures"]
    assert r["indicators"]["shoulder"]["mean"] > 0


def test_optimize(body):
    r = client.post("/api/optimize", json={"body": body, "initial": {"h": 1.3, "a": 15, "d": 0.45}}).json()
    assert r["status"] == "optimal"
    assert r["controller"]["simulated"] is True and r["controller"]["command"].startswith("MOVE")
    assert set(r["postures"]) == {"initial", "optimal"}
    assert r["optimal"]["J"] < r["initial"]["J"]


def test_optimize_refuses_invalid_body(body):
    bad = {**body, "elbow_h": 1.30}
    r = client.post("/api/optimize", json={"body": bad})
    assert r.status_code == 422 and r.json()["error"]["code"] == "mesures_invalides"


def test_optimize_bad_weights(body):
    r = client.post("/api/optimize", json={"body": body, "weights": {"epaule": 9}})
    assert r.status_code == 422 and r.json()["error"]["code"] == "poids_invalides"


def test_report(body):
    r = client.post("/api/report", json={"body": body}).json()
    md = r["markdown"]
    for section in ("Profil anthropométrique", "Réglages", "Indicateurs avant / après", "Contraintes", "Limites de l'analyse"):
        assert section in md
    assert "simulés" in md


def test_frontend_served():
    r = client.get("/", follow_redirects=False)
    assert r.status_code in (302, 307)


def test_acquire_aruco_without_camera():
    r = client.post("/api/acquire", json={"mode": "aruco"})
    assert r.status_code == 503 and r.json()["error"]["code"] == "materiel_requis"
