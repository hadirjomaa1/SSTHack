// Tests « sur PC » de la logique du firmware (analyse des trames, machine d'états, défauts).
// Compilation : g++ -std=c++17 -I tests/firmware_host tests/firmware_host/test_firmware.cpp -o fwtest && ./fwtest
#include "Arduino.h"
#include <iostream>
#include "../../firmware/firmware_gabarit_esp32.ino"   // le firmware réel, sans modification

static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { std::cout << "ÉCHEC : " << msg << "\n  sortie : " << Serial.out << "\n"; fails++; } else std::cout << "ok   : " << msg << "\n"; } while (0)

static std::string framed(const std::string& b){ unsigned x=0; for(char c:b) x^=(unsigned char)c; char t[8]; snprintf(t,8,"*%02X",x); return b+t+"\n"; }
static int unitsToAdc(const Axis& a, float u){ return (int)(a.adcMin + (u - a.minU) * (a.adcMax - a.adcMin) / float(a.maxU - a.minU)); }
static void setPos(int i, float u){ g_adc[axes[i].pinPot] = unitsToAdc(axes[i], u); if (i == 0) g_adc[13] = g_adc[axes[0].pinPot]; }
static float pos[3] = {1300, 150, 450};
// Banc simulé : la position suit le signe de la PWM (≈ 30 mm/s à pleine PWM)
static void run(uint32_t ms, bool hb = true){
  for (uint32_t t = 0; t < ms; t += 10){
    g_ms += 10;
    for (int i=0;i<3;i++){ int d = g_duty[axes[i].chR] - g_duty[axes[i].chL]; pos[i] += d / 200.0f * 0.3f; setPos(i, pos[i]); }
    if (hb && g_ms % 500 == 0) Serial.in += framed("HB");
    loop();
  }
}
static void send(const std::string& s){ Serial.out.clear(); Serial.in += s; run(20); }

int main(){
  g_din[4] = HIGH; g_din[16] = HIGH;              // chaîne de sécurité fermée, zone libre
  for (int i=0;i<3;i++) setPos(i, pos[i]);
  setup(); run(30);

  send(framed("MOVE H=1200 A=abc D=400 ID=1"));   CHECK(Serial.out.find("ERR RANGE A") != std::string::npos, "valeur non numérique refusée (défaut F1 de la v1)");
  send(framed("MOVE H=1600 A=100 D=400 ID=1"));   CHECK(Serial.out.find("ERR RANGE H") != std::string::npos, "hors course refusé");
  send("MOVE H=1200 A=100 D=400 ID=1*00\n");      CHECK(Serial.out.find("ERR CHECKSUM") != std::string::npos, "somme de contrôle fausse refusée");
  send(framed("MOVE H=1200 A=100 D=400"));        CHECK(Serial.out.find("ERR SYNTAX") != std::string::npos, "champ ID manquant refusé");
  send(framed("MOVE H=1200 A=100 D=400 ID=7 X=1")); CHECK(Serial.out.find("ERR SYNTAX") != std::string::npos, "champ en trop refusé");
  g_din[16] = LOW; send(framed("MOVE H=1200 A=100 D=400 ID=2")); CHECK(Serial.out.find("ERR ZONE_OCCUPIED") != std::string::npos, "mouvement refusé mains dans la zone"); g_din[16] = HIGH;

  send(framed("MOVE H=1200 A=100 D=420 ID=3"));   CHECK(Serial.out.find("OK ID=3") != std::string::npos, "commande valide acceptée");
  Serial.out.clear(); run(15000);
  CHECK(Serial.out.find("DONE") != std::string::npos && Serial.out.find("ID=3") != std::string::npos, "mouvement terminé (DONE)");
  CHECK(fabsf(pos[0]-1200) < 4 && fabsf(pos[1]-100) < 5 && fabsf(pos[2]-420) < 4, "positions atteintes dans la tolérance");

  send(framed("MOVE H=1350 A=100 D=420 ID=4")); Serial.out.clear(); run(3000, false);
  CHECK(Serial.out.find("FAULT HOST_TIMEOUT") != std::string::npos, "arrêt si l'hôte ne répond plus (battement de cœur)");
  send(framed("MOVE H=1300 A=100 D=420 ID=5"));   CHECK(Serial.out.find("ERR LOCKED") != std::string::npos, "défaut verrouillé : nouvelle commande refusée");
  send(framed("RESET"));                          CHECK(Serial.out.find("STATE IDLE") != std::string::npos, "RESET lève le défaut quand la cause a disparu");

  g_adc[axes[2].pinPot] = 5; Serial.out.clear(); g_ms += 10; loop();
  CHECK(Serial.out.find("FAULT SENSOR D") != std::string::npos, "recopie coupée détectée");
  setPos(2, pos[2]); send(framed("RESET"));

  g_adc[13] = unitsToAdc(axes[0], pos[0] + 12); Serial.out.clear(); g_ms += 10; loop();
  CHECK(Serial.out.find("FAULT SYNC H") != std::string::npos, "désynchronisation des colonnes détectée");
  setPos(0, pos[0]); send(framed("RESET"));

  send(framed("MOVE H=1400 A=100 D=420 ID=6")); g_din[4] = LOW; Serial.out.clear(); run(30);
  CHECK(Serial.out.find("FAULT SAFETY_OPEN") != std::string::npos, "ouverture de la chaîne de sécurité mémorisée");
  send(framed("RESET")); CHECK(Serial.out.find("ERR SAFETY_OPEN") != std::string::npos, "RESET refusé tant que la chaîne est ouverte");

  send(framed("RESET")); g_din[4] = HIGH; send(framed("RESET"));
  send(framed("MOVE H=1250 A=100 D=420 ID=8")); run(400); g_adc[axes[0].pinCur] = 4000; Serial.out.clear(); run(600);
  CHECK(Serial.out.find("FAULT PINCH H") != std::string::npos, "surintensité : recul non bloquant puis défaut PINCH");
  g_adc[axes[0].pinCur] = 0;

  std::cout << (fails ? "\nÉCHECS : " : "\nTous les tests firmware passent : ") << fails << "\n";
  return fails ? 1 : 0;
}
