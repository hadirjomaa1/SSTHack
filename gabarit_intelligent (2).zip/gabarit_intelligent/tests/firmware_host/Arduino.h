// Bouchon minimal de l'API Arduino-ESP32 pour exécuter la logique du firmware sur PC (tests).
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdarg>
#include <cmath>
#include <string>
#include <map>
#include <algorithm>
using std::min;
#define INPUT_PULLDOWN 3
#define OUTPUT 1
#define HIGH 1
#define LOW 0
inline std::map<int,int> g_adc, g_din, g_duty;   // ADC par broche, entrées numériques, PWM par canal
inline uint32_t g_ms = 0;
inline int analogRead(int p){ return g_adc[p]; }
inline void analogReadResolution(int){}
inline void pinMode(int,int){}
inline int digitalRead(int p){ return g_din[p]; }
inline void digitalWrite(int,int){}
inline void ledcSetup(int,int,int){}
inline void ledcAttachPin(int,int){}
inline void ledcWrite(int ch,int v){ g_duty[ch]=v; }
inline uint32_t millis(){ return g_ms; }
template<class T> T constrain(T x,T a,T b){ return x<a?a:x>b?b:x; }
struct SerialStub {
  std::string in, out;
  void begin(int){}
  int available(){ return (int)in.size(); }
  int read(){ int c=(unsigned char)in[0]; in.erase(0,1); return c; }
  void printf(const char* f, ...){ char b[256]; va_list ap; va_start(ap,f); vsnprintf(b,sizeof b,f,ap); va_end(ap); out+=b; }
};
inline SerialStub Serial;
