"""Tests du moteur : anthropométrie, cinématique, évaluation, optimisation."""
import math

import pytest

import smart_jig
from smart_jig import Body, JigConfig, body_from_profile, load_reference_profiles, validate_body, DEFAULT_INITIAL
from ergonomics import arm_ik, evaluate, geometry_checks
from optimizer import optimise, check_weights


# ---------- Profils et validation
@pytest.mark.parametrize("pid", [p["id"] for p in load_reference_profiles()["profiles"]])
def test_reference_profiles_are_valid(pid):
    v = validate_body(body_from_profile(pid))
    assert v.ok, v.errors


def test_validation_rejects_out_of_bounds(p50):
    b = Body(**{**p50.dims(), "stature": 2.5})
    assert not validate_body(b).ok


def test_validation_rejects_anatomical_order(p50):
    b = Body(**{**p50.dims(), "shoulder_h": p50.eye_h + 0.01})
    v = validate_body(b)
    assert not v.ok and any("Incohérence" in e for e in v.errors)


def test_validation_rejects_arm_incoherence(p50):
    b = Body(**{**p50.dims(), "upper_arm": 0.39})
    assert not validate_body(b).ok


def test_validation_refuses_high_uncertainty(p50):
    b = Body(**p50.dims(), uncertainty_m=0.08)
    assert not validate_body(b).ok


def test_from_stature_compat_marks_proportions():
    b = Body.from_stature(1.60)
    assert b.origin["upper_arm"] == "winter" and validate_body(b).ok


# ---------- Cinématique
def test_ik_horizontal_full_reach_gives_90deg(p50):
    sh = (p50.shoulder_half, p50.shoulder_joint_h, 0.0)
    L = p50.upper_arm + p50.forearm_grip
    k = arm_ik(p50, (sh[0], sh[1], L * 0.9999), 1)
    assert abs(k["elev"] - 90) < 1.0 and k["flex"] < 3.0


def test_ik_segment_lengths_preserved(p50):
    k = arm_ik(p50, (0.25, 1.05, 0.30), 1)
    assert k["reachable"]
    assert math.dist(k["sh"], k["el"]) == pytest.approx(p50.upper_arm, abs=1e-6)
    assert math.dist(k["el"], k["ha"]) == pytest.approx(p50.forearm_grip, abs=1e-6)


def test_ik_unreachable_flagged(p50):
    assert not arm_ik(p50, (0.2, 1.3, 1.5), 1)["reachable"]


def test_evaluate_v1_signature_and_content(p50):
    r = evaluate(p50, 1.2, 10, 0.4)
    assert r["config"] == {"h": 1.2, "a": 10, "d": 0.4}
    assert len(r["points"]) == 35
    assert r["evaluations"]["rula_complet"]["status"] == "non_calculable"
    assert "PAS un score RULA" in r["evaluations"]["rula_items"]["note"]


def test_geometry_clearance_violation():
    c = JigConfig(1.2, 40, 0.30)       # bord bas qui entre dans l'opératrice
    assert not {k["id"]: k for k in geometry_checks(c)}["clearance"]["ok"]


# ---------- Optimisation
def test_optimise_deterministic_and_bounded(p50):
    r1, r2 = optimise(p50), optimise(p50)
    assert r1["optimal"]["config"] == r2["optimal"]["config"] and r1["optimal"]["J"] == r2["optimal"]["J"]
    c = r1["optimal"]["config"]
    for k, (lo, hi) in smart_jig.AXIS_LIMITS.items():
        assert lo - 1e-9 <= c[k] <= hi + 1e-9
    assert r1["status"] == "optimal" and r1["convergence"]["converged"]
    assert all(k["ok"] for k in r1["optimal"]["constraints"])
    assert r1["optimal"]["J"] < r1["initial"]["J"]


def test_initial_infeasible_is_reported():
    r = optimise(body_from_profile("P5F"))
    assert r["initial"]["feasible"] is False      # points hors d'atteinte avec le réglage initial supposé
    assert "viole" in r["message"]


def test_no_fictitious_improvement(p50):
    r = optimise(p50)
    r2 = optimise(p50, JigConfig.from_dict(r["optimal"]["config"]))
    assert r2["status"] == "deja_optimal"
    assert r2["optimal"]["config"] == r["optimal"]["config"]


def test_infeasible_when_axes_too_short(monkeypatch):
    monkeypatch.setitem(smart_jig.AXIS_LIMITS, "h", (1.40, 1.45))
    monkeypatch.setitem(smart_jig.AXIS_LIMITS, "d", (0.53, 0.55))
    r = optimise(body_from_profile("P5F"), JigConfig(1.42, 0, 0.54))
    assert r["status"] == "infaisable" and r["optimal"]["feasible"] is False


def test_invalid_body_refused(p50):
    r = optimise(Body(**{**p50.dims(), "elbow_h": 1.30}))
    assert r["status"] == "donnees_invalides" and r["optimal"] is None


def test_weights_validation():
    with pytest.raises(ValueError):
        check_weights({"epaule": -1})
    with pytest.raises(ValueError):
        check_weights({"inconnu": 1})
    with pytest.raises(ValueError):
        check_weights({"epaule": 0, "allonge": 0, "cou": 0})


def test_displacement_weight_reduces_move(p50):
    init = JigConfig(**DEFAULT_INITIAL)
    dist = lambda c: sum(abs(c[k] - getattr(init, k)) / (smart_jig.AXIS_LIMITS[k][1] - smart_jig.AXIS_LIMITS[k][0]) for k in "had")
    a = optimise(p50, init)["optimal"]["config"]
    b = optimise(p50, init, {"deplacement": 3.0})["optimal"]["config"]
    assert dist(b) <= dist(a) + 1e-9
