/* ErgoGuard AI – Smart Jig : jumeau numérique 3D (Three.js r128).
 *
 * Affichage uniquement : morphologie, postures des bras (positions articulaires calculées par
 * le moteur Python), carte de confort et réglages viennent de l'API. Aucune cinématique ici.
 *
 * Repère du moteur : x = droite de l'opératrice, y = haut, z = vers le gabarit.
 * Three.js regardant vers +z place +x à gauche de l'écran : on affiche donc X3 = −x pour que la
 * droite de l'opératrice reste à droite quand on la voit de dos (aucun effet sur les calculs).
 */
window.EG = window.EG || {};

EG.Scene = (function () {
  const S = {};
  let renderer, scene, camera, controls, host;
  let stations = {}, mode = 'overlay', hasResult = false;
  let toggles = { joints: true, map: true, work: true };
  let cur = null, target = null, speeds = { h: 0.03, a: 3, d: 0.025 }, speedup = 1, moveDone = null;
  let camAnim = null, viewName = 'iso';
  const onAxesCbs = [];

  const V = (p) => new THREE.Vector3(-p[0], p[1], p[2]);          // moteur -> Three.js
  const ZONE = (e) => (e > 45 ? 0xd14b4b : e > 20 ? 0xd99a1e : 0x2e9e5b);
  const ELB = (f) => (f >= 60 && f <= 100 ? 0x2e9e5b : 0xd99a1e);
  const C_INIT = 0xeb6834, C_OPT = 0x2a78d6;
  const BOARD_LEN = 0.70, BOARD_W = 1.70;

  function rng(seed) { // générateur déterministe (décor identique à chaque chargement)
    return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  function seg(m, a, b, r) {
    const d = b.clone().sub(a), len = Math.max(1e-4, d.length());
    m.position.copy(a).add(b).multiplyScalar(0.5); m.scale.set(r, len, r);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
  }
  function label(text, { bg = '#0b2545', fg = '#fff', size = 30, scale = 0.0016 } = {}) {
    const c = document.createElement('canvas'), g = c.getContext('2d');
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true }));
    spr.renderOrder = 20;
    spr.setText = (t) => {
      if (t === spr._t) return; spr._t = t;
      g.font = `600 ${size}px IBM Plex Sans, sans-serif`;
      const w = Math.ceil(g.measureText(t).width) + 28, h = size + 18;
      c.width = w; c.height = h; g.font = `600 ${size}px IBM Plex Sans, sans-serif`;
      g.fillStyle = bg; g.beginPath(); if (g.roundRect) g.roundRect(0, 0, w, h, 10); else g.rect(0, 0, w, h); g.fill();
      g.fillStyle = fg; g.textBaseline = 'middle'; g.fillText(t, 14, h / 2 + 1);
      spr.material.map.dispose(); spr.material.map = new THREE.CanvasTexture(c); spr.scale.set(w * scale, h * scale, 1);
    };
    spr.setText(text);
    return spr;
  }

  /* ------------------------------------------------------------------ Station */
  class Station {
    constructor({ ghost = false, accent = C_OPT, offset = 0, caption = '' }) {
      this.ghost = ghost; this.accent = accent;
      this.g = new THREE.Group(); this.g.position.x = offset; scene.add(this.g);
      this.cfg = null; this.body = null; this.post = null; this.points = null; this.handsAway = false;
      this.disp = null; this.seqI = 0; this.seqT = 0;
      this._buildFrame(); this._buildBoard(); this._buildMannequin(); this._buildJoints();
      if (caption) { this.caption = label(caption, { bg: ghost ? '#eb6834' : (accent === C_INIT ? '#eb6834' : '#13315c'), size: 34, scale: 0.0019 }); this.g.add(this.caption); }
    }
    M(color, o = {}) {
      if (this.ghost) return new THREE.MeshBasicMaterial({ color: C_INIT, transparent: true, opacity: 0.16, depthWrite: false });
      return new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.05, ...o });
    }
    mesh(geo, m, parent) { const o = new THREE.Mesh(geo, m); o.castShadow = !this.ghost; o.receiveShadow = !this.ghost; (parent || this.g).add(o); return o; }

    _buildFrame() {
      const steel = this.M(0x8c97a3, { metalness: 0.5, roughness: 0.4 }), dark = this.M(0x34404d, { metalness: 0.3 });
      this.rails = [];
      for (const x of [-0.95, 0.95]) { const r = this.mesh(new THREE.BoxGeometry(0.06, 0.04, 0.95), steel); r.position.set(x, 0.02, 0.62); }
      this.carriage = new THREE.Group(); this.g.add(this.carriage);
      this.colInner = [];
      for (const x of [-0.95, 0.95]) {
        this.mesh(new THREE.BoxGeometry(0.16, 0.05, 0.22), dark, this.carriage).position.set(x, 0.065, 0);
        this.mesh(new THREE.BoxGeometry(0.11, 0.70, 0.09), this.M(this.accent === C_INIT ? 0x8a5a44 : 0x1f4e8c, { metalness: 0.2 }), this.carriage).position.set(x, 0.44, 0);
        const inner = this.mesh(new THREE.BoxGeometry(0.08, 1, 0.065), steel, this.carriage); inner.position.x = x; this.colInner.push(inner);
      }
      this.beam = this.mesh(new THREE.BoxGeometry(1.98, 0.06, 0.06), steel, this.carriage);
      this.tilt = this.mesh(new THREE.CylinderGeometry(1, 1, 1, 12), dark, this.carriage);
    }
    _buildBoard() {
      const R = rng(42);
      this.board = new THREE.Group(); this.carriage.add(this.board);
      this.mesh(new THREE.BoxGeometry(BOARD_W, BOARD_LEN + 0.08, 0.025), this.M(0xf4f6f8), this.board);
      this.mesh(new THREE.BoxGeometry(BOARD_W + 0.04, BOARD_LEN + 0.12, 0.02), this.M(this.accent === C_INIT ? C_INIT : 0x5d6b79, { metalness: 0.4 }), this.board).position.z = 0.02;
      if (this.ghost) { const e = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(BOARD_W, BOARD_LEN + 0.08, 0.025)), new THREE.LineBasicMaterial({ color: C_INIT })); this.board.add(e); return; }
      for (let k = 0; k < 6; k++) this.mesh(new THREE.BoxGeometry(0.22, 0.1, 0.14), this.M(0x2457c5), this.board).position.set(-0.68 + k * 0.27, BOARD_LEN / 2 + 0.11, -0.05);
      const pegM = this.M(0x9aa5b1, { metalness: 0.6 }), pegG = new THREE.CylinderGeometry(0.006, 0.006, 0.07, 8);
      for (let i = 0; i < 34; i++) { const p = this.mesh(pegG, pegM, this.board); p.rotation.x = Math.PI / 2; p.position.set(-0.75 + R() * 1.5, -0.3 + R() * 0.6, -0.045); }
      const conM = this.M(0x1b1f24);
      [[-0.55, 0.2], [-0.2, -0.12], [0.15, 0.18], [0.45, -0.05], [0.62, 0.24], [-0.62, -0.22], [0.05, -0.25]].forEach(([l, s]) =>
        this.mesh(new THREE.BoxGeometry(0.07, 0.05, 0.04), conM, this.board).position.set(l, s, -0.035));
      const cols = [0xd23b3b, 0x2f6fd6, 0xe0b21c, 0x2a9a52, 0xf07c22, 0x222222, 0x8b4fc9, 0xe86aa6];
      for (let i = 0; i < 16; i++) {
        const pts = [], y0 = -0.28 + R() * 0.5;
        for (let k = 0; k < 5; k++) pts.push(new THREE.Vector3(-0.75 + k * 0.375, y0 + (R() - 0.5) * 0.18, -0.03 - R() * 0.01));
        this.mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.004, 6), this.M(cols[i % 8]), this.board);
      }
      this.map = new THREE.Group(); this.board.add(this.map); this.dots = [];
      this.zone = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.PlaneGeometry(0.78, BOARD_LEN + 0.04)), new THREE.LineBasicMaterial({ color: 0x13315c }));
      this.zone.position.z = -0.017; this.board.add(this.zone);
    }
    _buildMannequin() {
      const coat = this.M(0xf1f1ee), skin = this.M(0xc99a78), pants = this.M(0x2f3a48), shoe = this.M(0x1d232b), hair = this.M(0x3b2f2a);
      const cyl = new THREE.CylinderGeometry(1, 1, 1, 18), sph = new THREE.SphereGeometry(1, 22, 16), box = new THREE.BoxGeometry(1, 1, 1);
      const P = this.P = {};
      const mk = (name, geo, m) => { P[name] = this.mesh(geo, this.ghost ? m : m.clone()); };
      ['legL', 'legR', 'shinL', 'shinR'].forEach((n) => mk(n, cyl, pants));
      ['footL', 'footR'].forEach((n) => mk(n, box, shoe));
      mk('pelvis', cyl, pants); mk('skirt', new THREE.CylinderGeometry(1, 1.12, 1, 22), coat); mk('torso', cyl, coat);
      mk('neck', cyl, skin); mk('head', sph, skin); mk('hair', sph, hair); mk('nose', new THREE.ConeGeometry(1, 1, 10), skin);
      ['uaL', 'uaR', 'faL', 'faR'].forEach((n) => mk(n, cyl, coat));
      ['shL', 'shR', 'elL', 'elR'].forEach((n) => mk(n, sph, coat));
      ['hL', 'hR'].forEach((n) => mk(n, sph, skin));
    }
    _buildJoints() {
      this.jMarks = {};
      if (this.ghost) return;
      for (const n of ['shR', 'shL', 'elR', 'elL']) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), new THREE.MeshBasicMaterial({ color: 0x2e9e5b, transparent: true, opacity: 0.85, depthTest: false }));
        m.renderOrder = 15; this.g.add(m); this.jMarks[n] = m;
      }
      this.lblSh = label('Épaule —'); this.lblEl = label('Coude —'); this.g.add(this.lblSh, this.lblEl);
    }

    setVisible(v) { this.g.visible = v; }
    setBody(b) { this.body = b; this.disp = null; }
    setConfig(c) {
      this.cfg = { ...c };
      const hingeY = c.h;
      this.carriage.position.set(0, 0, c.d + 0.07);
      this.colInner.forEach((col) => { const bot = 0.55; col.scale.y = Math.max(0.05, hingeY - bot); col.position.y = (hingeY + bot) / 2; });
      this.beam.position.set(0, hingeY, 0);
      this.board.position.set(0, hingeY, -0.07); this.board.rotation.x = (c.a * Math.PI) / 180;
      const a = (c.a * Math.PI) / 180;
      seg(this.tilt, new THREE.Vector3(0.75, hingeY - 0.42, 0.02), new THREE.Vector3(0.75, hingeY - 0.25 * Math.cos(a), -0.07 - 0.25 * Math.sin(a) + 0.03), 0.014);
      if (this.caption) this.caption.position.set(0, hingeY + 0.62, c.d);
    }
    setPoints(points) {
      if (this.ghost || !this.map) return;
      if (this.dots.length !== points.length) {
        this.dots.forEach((d) => this.map.remove(d)); this.dots = [];
        for (const p of points) {
          const m = new THREE.Mesh(new THREE.CircleGeometry(0.028, 22), new THREE.MeshBasicMaterial({ color: 0x2e9e5b, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
          m.position.set(-p.l, p.s, -0.016); m.rotation.y = Math.PI; this.map.add(m); this.dots.push(m);
        }
      }
      points.forEach((p, i) => this.dots[i].material.color.setHex(ZONE(p.elev)));
    }
    setPostures(p) {
      this.post = p;
      // Parcours fixe des points centraux (zone d'encliquetage) : pas de hasard.
      const central = p.work.map((w, i) => ({ ...w, i })).filter((w) => Math.abs(w.s) <= 0.24 && Math.abs(w.l) <= 0.18);
      const rows = [...new Set(central.map((w) => w.s))].sort((a, b) => b - a);
      this.seq = [];
      rows.forEach((s, ri) => { const r = central.filter((w) => w.s === s).sort((a, b) => a.l - b.l); (ri % 2 ? r.reverse() : r).forEach((w) => this.seq.push(w.i)); });
      this.seqI = 0; this.seqT = 0;
    }
    _targetPose(dt) {
      if (!this.post) return null;
      if (this.handsAway || !this.post.work.length) return this.post.rest;
      if (!toggles.work) return this.post.work[this.seq[Math.floor(this.seq.length / 2)]];
      this.seqT += dt;
      const MOVE = 0.9, HOLD = 0.55;
      if (this.seqT > MOVE + HOLD) { this.seqT = 0; this.seqI = (this.seqI + 1) % this.seq.length; }
      const A = this.post.work[this.seq[this.seqI]], B = this.post.work[this.seq[(this.seqI + 1) % this.seq.length]];
      if (this.seqT < HOLD) return A;
      let k = (this.seqT - HOLD) / MOVE; k = k * k * (3 - 2 * k);
      const mix = (a, b) => a.map((x, i) => x + (b[i] - x) * k);
      const arm = (s) => ({ sh: A[s].sh, el: mix(A[s].el, B[s].el), ha: mix(A[s].ha, B[s].ha),
        elev: A[s].elev + (B[s].elev - A[s].elev) * k, flex: A[s].flex + (B[s].flex - A[s].flex) * k });
      return { R: arm('R'), L: arm('L') };
    }
    update(dt) {
      if (!this.body || !this.post) return;
      const b = this.body, H = b.stature, P = this.P;
      const tgt = this._targetPose(dt);
      // lissage des transitions (travail <-> repos)
      if (!this.disp) this.disp = JSON.parse(JSON.stringify(tgt));
      const k = Math.min(1, dt * 7);
      for (const s of ['R', 'L']) for (const key of ['el', 'ha']) this.disp[s][key] = this.disp[s][key].map((x, i) => x + (tgt[s][key][i] - x) * k);
      for (const s of ['R', 'L']) { this.disp[s].sh = tgt[s].sh; this.disp[s].elev += (tgt[s].elev - this.disp[s].elev) * k; this.disp[s].flex += (tgt[s].flex - this.disp[s].flex) * k; }

      // Proportions d'affichage (hypothèses Winter : hanche 0,530 H, genou 0,285 H, bassin 0,191 H)
      const hip = 0.53 * H, knee = 0.285 * H, legX = 0.0955 * H * 0.6;
      for (const [leg, shin, foot, x] of [[P.legL, P.shinL, P.footL, legX], [P.legR, P.shinR, P.footR, -legX]]) {
        seg(leg, new THREE.Vector3(x, hip, 0), new THREE.Vector3(x, knee, 0.005), 0.036 * H);
        seg(shin, new THREE.Vector3(x, knee, 0.005), new THREE.Vector3(x, 0.045 * H, 0), 0.028 * H);
        foot.position.set(x, 0.02 * H, 0.04 * H); foot.scale.set(0.055 * H, 0.04 * H, 0.152 * H);
      }
      const shJ = b.shoulder_h - 0.035, half = b.shoulder_width / 2;
      seg(P.pelvis, new THREE.Vector3(0, hip - 0.04 * H, 0), new THREE.Vector3(0, hip + 0.04 * H, 0), 0.1 * H); P.pelvis.scale.z = 0.06 * H;
      P.skirt.position.set(0, hip - 0.02 * H, 0); P.skirt.scale.set(half * 0.9, 0.16 * H, 0.075 * H); P.skirt.quaternion.identity();
      P.torso.position.set(0, (hip + 0.02 * H + shJ + 0.02) / 2, 0); P.torso.scale.set(half * 0.86, shJ + 0.02 - hip - 0.02 * H, 0.072 * H); P.torso.quaternion.identity();
      const headH = H - b.eye_h; const hr = 0.68 * headH + 0.04; const hc = new THREE.Vector3(0, H - hr * 1.05, 0.01);   // sommet du crâne = stature
      seg(P.neck, new THREE.Vector3(0, shJ, 0), new THREE.Vector3(0, hc.y - hr * 0.7, 0.005), 0.028 * H);
      P.head.position.copy(hc); P.head.scale.set(hr * 0.86, hr * 1.05, hr * 0.95);
      P.hair.position.copy(hc).add(new THREE.Vector3(0, hr * 0.12, -hr * 0.22)); P.hair.scale.set(hr * 0.9, hr * 1.0, hr * 0.85);
      P.nose.position.copy(hc).add(new THREE.Vector3(0, -hr * 0.1, hr * 0.95)); P.nose.scale.set(hr * 0.14, hr * 0.3, hr * 0.14); P.nose.rotation.x = Math.PI / 2;
      for (const s of ['R', 'L']) {
        const d = this.disp[s], Sx = V(d.sh), E = V(d.el), Hd = V(d.ha);
        seg(P['ua' + s], Sx, E, 0.026 * H); seg(P['fa' + s], E, Hd, 0.021 * H);
        P['sh' + s].position.copy(Sx); P['sh' + s].scale.setScalar(0.031 * H);
        P['el' + s].position.copy(E); P['el' + s].scale.setScalar(0.023 * H);
        P['h' + s].position.copy(Hd); P['h' + s].scale.setScalar(0.02 * H);
        if (!this.ghost) {
          const showJ = toggles.joints;
          const js = this.jMarks['sh' + s], je = this.jMarks['el' + s];
          js.visible = je.visible = showJ;
          js.position.copy(Sx); js.scale.setScalar(0.022 * H); js.material.color.setHex(ZONE(d.elev));
          je.position.copy(E); je.scale.setScalar(0.017 * H); je.material.color.setHex(ELB(d.flex));
          P['ua' + s].material.color.setHex(showJ ? ZONE(d.elev) : 0xf1f1ee);
        }
      }
      if (!this.ghost) {
        const d = this.disp.R;
        this.lblSh.visible = this.lblEl.visible = toggles.joints;
        this.lblSh.setText(`Épaule ${Math.round(d.elev)}°`); this.lblEl.setText(`Coude ${Math.round(d.flex)}°`);
        this.lblSh.position.copy(V(d.sh)).add(new THREE.Vector3(-0.2, 0.12, -0.05));
        this.lblEl.position.copy(V(d.el)).add(new THREE.Vector3(-0.2, -0.04, -0.05));
        if (this.map) this.map.visible = toggles.map; if (this.zone) this.zone.visible = toggles.map;
      }
    }
  }

  /* ------------------------------------------------------------------ Scène */
  S.init = function (container) {
    host = container;
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    host.appendChild(renderer.domElement);
    scene = new THREE.Scene(); scene.background = new THREE.Color(0xe6ecf2); scene.fog = new THREE.Fog(0xe6ecf2, 8, 18);
    camera = new THREE.PerspectiveCamera(38, 1, 0.05, 60);
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.maxPolarAngle = Math.PI * 0.495; controls.minDistance = 0.8; controls.maxDistance = 9;
    scene.add(new THREE.HemisphereLight(0xffffff, 0xb6c2cf, 0.78));
    const sun = new THREE.DirectionalLight(0xffffff, 0.72); sun.position.set(3, 5, -2.5); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -4, right: 4, top: 4, bottom: -4 }); scene.add(sun);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ color: 0xd5dde6 }));
    floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
    const grid = new THREE.GridHelper(40, 80, 0xc0cad5, 0xc8d1db); grid.position.y = 0.001; scene.add(grid);
    const mat = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.015, 0.7), new THREE.MeshStandardMaterial({ color: 0x2b3440 }));
    mat.position.set(0, 0.008, -0.05); mat.receiveShadow = true; scene.add(mat);
    // Caméra de mesure du poste (illustration de l'emplacement prévu)
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 2.2, 10), new THREE.MeshStandardMaterial({ color: 0x8c97a3, metalness: 0.5 }));
    mast.position.set(-1.3, 1.1, 1.05); mast.castShadow = true; scene.add(mast);
    const camHead = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.03, 0.03), new THREE.MeshStandardMaterial({ color: 0x23272d }));
    camHead.position.set(-1.3, 2.18, 1.05); camHead.lookAt(0, 1, 0); scene.add(camHead);

    stations.opt = new Station({ accent: C_OPT, caption: 'APRÈS · configuration optimisée' });
    stations.ghost = new Station({ ghost: true });
    stations.init = new Station({ accent: C_INIT, offset: 0, caption: 'AVANT · configuration initiale' });
    stations.opt.caption.visible = false;
    applyMode();
    S.setView('iso', true);
    new ResizeObserver(resize).observe(host); resize();
    let last = performance.now();
    (function loop(now) {
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      stepAxes(dt);
      Object.values(stations).forEach((s) => s.g.visible && s.update(dt));
      if (camAnim) {
        camAnim.k = Math.min(1, camAnim.k + dt * 1.8); const e = 1 - Math.pow(1 - camAnim.k, 3);
        camera.position.lerpVectors(camAnim.p0, camAnim.p1, e); controls.target.lerpVectors(camAnim.t0, camAnim.t1, e);
        if (camAnim.k >= 1) camAnim = null;
      }
      controls.update(); renderer.render(scene, camera); requestAnimationFrame(loop);
    })(last);
  };

  function resize() { const w = host.clientWidth, h = host.clientHeight; renderer.setSize(w, h); camera.aspect = w / h; camera.updateProjectionMatrix(); }

  function stepAxes(dt) {
    if (!cur || !target) return;
    let moving = false;
    for (const k of ['h', 'a', 'd']) {
      const diff = target[k] - cur[k], step = speeds[k] * speedup * dt;
      if (Math.abs(diff) > 1e-6) { moving = true; cur[k] += Math.sign(diff) * Math.min(Math.abs(diff), step); }
    }
    stations.opt.setConfig(cur);
    onAxesCbs.forEach((cb) => cb({ ...cur }, moving));
    if (!moving && moveDone) { const r = moveDone; moveDone = null; r(); }
  }

  function applyMode() {
    const side = mode === 'side' && hasResult;
    stations.opt.g.position.x = side ? -1.12 : 0;
    stations.init.g.position.x = 1.12;
    stations.init.setVisible(side);
    stations.ghost.setVisible(mode === 'overlay' && hasResult);
    stations.opt.caption.visible = side;
    S.setView(viewName);
  }

  /* ------------------------------------------------------------------ API publique */
  S.setSpeeds = (sp) => { speeds = sp; };
  S.setFast = (f) => { speedup = f ? 4 : 1; };
  S.onAxes = (cb) => onAxesCbs.push(cb);
  S.setToggles = (t) => { toggles = { ...toggles, ...t }; };
  S.setMode = (m) => { mode = m; applyMode(); };

  /** Morphologie + configuration initiale évaluée (avant optimisation). */
  S.showInitial = function (body, ev) {
    hasResult = false;
    for (const s of Object.values(stations)) s.setBody(body);
    cur = { ...ev.config }; target = { ...ev.config };
    stations.opt.setConfig(cur); stations.opt.setPostures(ev.postures); stations.opt.setPoints(ev.points);
    stations.opt.handsAway = false;
    applyMode();
  };

  /** Rejoue le résultat : mains hors zone, déplacement des 3 axes, reprise du travail. */
  S.playOptimization = async function (body, res) {
    const ini = res.initial.config, opt = res.optimal.config;
    for (const s of Object.values(stations)) s.setBody(body);
    stations.ghost.setConfig(ini); stations.ghost.setPostures(res.postures.initial);
    stations.init.setConfig(ini); stations.init.setPostures(res.postures.initial); stations.init.setPoints(res.initial.points);
    cur = { ...ini }; target = { ...ini };
    stations.opt.setConfig(cur); stations.opt.setPostures(res.postures.initial); stations.opt.setPoints(res.initial.points);
    hasResult = true; applyMode();
    stations.opt.handsAway = true;                                   // sécurité : mains hors du gabarit
    await new Promise((r) => setTimeout(r, 900));
    stations.opt.setPostures(res.postures.optimal);
    await new Promise((r) => { moveDone = r; target = { ...opt }; });
    stations.opt.setPoints(res.optimal.points);
    stations.opt.handsAway = false;
  };

  S.setView = function (name, instant) {
    viewName = name;
    const wide = mode === 'side' && hasResult ? 1.55 : 1;
    const T = new THREE.Vector3(0, 1.1, 0.3);
    const P = { iso: [2.35, 1.95, -2.05], side: [3.3, 1.3, 0.3], front: [0, 1.5, -2.9] }[name];
    const p1 = new THREE.Vector3(P[0] * wide, P[1] + (wide - 1) * 0.4, P[2] * wide);
    if (instant) { camera.position.copy(p1); controls.target.copy(T); return; }
    camAnim = { p0: camera.position.clone(), t0: controls.target.clone(), p1, t1: T, k: 0 };
  };
  S.zoom = function (f) {
    const v = camera.position.clone().sub(controls.target).multiplyScalar(f);
    camAnim = { p0: camera.position.clone(), t0: controls.target.clone(), p1: controls.target.clone().add(v), t1: controls.target.clone(), k: 0 };
  };
  return S;
})();
