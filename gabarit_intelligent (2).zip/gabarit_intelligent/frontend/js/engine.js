/* ErgoGuard AI – Smart Jig : accès au moteur de calcul Python.
 *
 * Aucun calcul ergonomique n'est fait en JavaScript. Deux transports pour le MÊME code Python :
 *   1. "api"     : serveur FastAPI (uvicorn backend.app:app) — mode normal, accès matériel possible ;
 *   2. "pyodide" : page autonome générée par tools/build_standalone.py, qui embarque les fichiers
 *                  backend/*.py et les exécute dans un Web Worker Pyodide (CPython compilé en WebAssembly).
 * Sans l'un ni l'autre, l'interface l'indique et désactive les calculs.
 */
window.EG = window.EG || {};

EG.EngineError = class extends Error {
  constructor(err, status) { super(err && err.message || 'Erreur du moteur'); this.code = err && err.code; this.details = err && err.details; this.status = status; }
};

EG.Engine = {
  mode: 'offline', base: '', health: null, worker: null, _id: 0, _pending: new Map(),

  async init() {
    const qs = new URLSearchParams(location.search);
    const api = qs.get('api') || '';
    if (api || location.protocol.startsWith('http')) {
      try {
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 2500);
        const r = await fetch(api + '/api/health', { signal: ctl.signal }); clearTimeout(t);
        if (r.ok) { this.mode = 'api'; this.base = api; this.health = await r.json(); return this.mode; }
      } catch (e) { /* pas de serveur : on tente le mode navigateur */ }
    }
    if (window.EG_PY_SOURCES) {
      try { await this._startPyodide(); this.mode = 'pyodide'; this.health = await this.call('health'); return this.mode; }
      catch (e) { this.error = e; }
    }
    this.mode = 'offline';
    return this.mode;
  },

  async call(name, payload) {
    if (this.mode === 'api') {
      const get = name === 'health' || name === 'profiles';
      let r;
      try {
        r = await fetch(`${this.base}/api/${name}`, get ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload || {}) });
      } catch (e) { throw new EG.EngineError({ code: 'serveur_injoignable', message: 'Serveur de calcul injoignable : vérifiez que uvicorn tourne.' }); }
      const j = await r.json().catch(() => ({ error: { code: 'reponse_invalide', message: `Réponse illisible (HTTP ${r.status})` } }));
      if (!r.ok) throw new EG.EngineError(j.error, r.status);
      return j;
    }
    if (this.mode === 'pyodide') {
      const m = await this._post({ type: 'call', name, payload });
      if (!m.ok) throw new EG.EngineError(m.error, m.status);
      return m.data;
    }
    throw new EG.EngineError({ code: 'moteur_absent', message: 'Moteur de calcul indisponible. Lancez le serveur local (voir README) : uvicorn backend.app:app' });
  },

  _post(msg) {
    return new Promise((res) => { const id = ++this._id; this._pending.set(id, res); this.worker.postMessage({ ...msg, id }); });
  },

  async _startPyodide() {
    const src = `
      importScripts('https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js');
      let py = null;
      onmessage = async (e) => {
        const m = e.data;
        if (m.type === 'init') {
          try {
            py = await loadPyodide();
            py.FS.mkdirTree('/ergo');
            for (const [n, s] of Object.entries(m.sources)) py.FS.writeFile('/ergo/' + n, s);
            py.runPython("import sys, json; sys.path.insert(0, '/ergo'); import service");
            postMessage({ id: m.id, ok: true });
          } catch (err) { postMessage({ id: m.id, ok: false, error: { code: 'pyodide', message: String(err) } }); }
          return;
        }
        try {
          py.globals.set('_name', m.name);
          py.globals.set('_payload', JSON.stringify(m.payload || {}));
          const out = py.runPython(\`
try:
    _f = getattr(service, _name)
    _r = _f() if _name in ('health', 'profiles') else _f(json.loads(_payload))
    _out = json.dumps({'ok': True, 'data': _r})
except service.ServiceError as _e:
    _out = json.dumps({'ok': False, 'status': _e.status, 'error': _e.to_dict()['error']})
_out\`);
          postMessage({ id: m.id, ...JSON.parse(out) });
        } catch (err) { postMessage({ id: m.id, ok: false, status: 500, error: { code: 'erreur_interne', message: String(err).slice(0, 400) } }); }
      };`;
    this.worker = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
    this.worker.onmessage = (e) => { const r = this._pending.get(e.data.id); if (r) { this._pending.delete(e.data.id); r(e.data); } };
    const r = await Promise.race([
      this._post({ type: 'init', sources: window.EG_PY_SOURCES }),
      new Promise((_, rej) => setTimeout(() => rej(new Error('Pyodide : délai dépassé')), 60000)),
    ]);
    if (!r.ok) throw new Error(r.error.message);
  },

  label() {
    return { api: 'Moteur Python · API locale', pyodide: 'Moteur Python · dans le navigateur', offline: 'Moteur hors ligne' }[this.mode];
  },
};
