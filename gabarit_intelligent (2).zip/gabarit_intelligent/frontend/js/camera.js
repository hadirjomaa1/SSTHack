/* ErgoGuard AI – Smart Jig : acquisition webcam (MediaPipe Pose Landmarker, dans le navigateur).
 *
 * - La vidéo ne quitte jamais le navigateur et n'est jamais enregistrée. Seules les coordonnées
 *   normalisées des 33 points (x, y, z, visibilité) sont gardées en mémoire pendant la capture,
 *   puis envoyées au moteur Python (POST /api/acquire, mode webcam_2d) qui fait tous les contrôles.
 * - Les angles affichés en direct sont des angles 2D PROJETÉS dans le plan de l'image : indicatifs.
 * - Nécessite une page servie en http(s)://localhost ou https (accès caméra), et l'accès réseau
 *   au modèle MediaPipe (jsDelivr + storage.googleapis.com).
 */
window.EG = window.EG || {};

EG.Camera = (function () {
  const C = {};
  const TASKS = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
  const MODEL = 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';
  const REQ = [2, 5, 11, 12, 13, 14, 15, 16, 23, 24, 29, 30];
  const CONN = [[11, 12], [11, 13], [13, 15], [12, 14], [14, 16], [11, 23], [12, 24], [23, 24], [23, 25], [25, 27], [27, 29], [29, 31],
    [24, 26], [26, 28], [28, 30], [30, 32], [2, 5]];
  let landmarker = null, stream = null, running = false, video, canvas, ctx, cb, cap = null, lastT = -1;

  const ang = (a, o, b) => { // angle (°) en o entre oa et ob, en pixels
    const v1 = [a[0] - o[0], a[1] - o[1]], v2 = [b[0] - o[0], b[1] - o[1]];
    const n = Math.hypot(...v1) * Math.hypot(...v2) || 1;
    return Math.acos(Math.max(-1, Math.min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / n))) * 180 / Math.PI;
  };

  C.start = async function (videoEl, canvasEl, onFrame) {
    video = videoEl; canvas = canvasEl; ctx = canvas.getContext('2d'); cb = onFrame;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia)
      throw new Error("Accès caméra indisponible ici (page non sécurisée ou aperçu hébergé). Ouvrez l'application via le serveur local : http://localhost:8000");
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 720 }, height: { ideal: 960 }, facingMode: 'user' }, audio: false }); }
    catch (e) { throw new Error(e.name === 'NotFoundError' ? 'Aucune webcam détectée sur cet ordinateur.' : e.name === 'NotAllowedError' ? "Accès à la caméra refusé (navigateur ou cadre de l'aperçu). Ouvrez l'application via le serveur local." : `Caméra indisponible : ${e.message}`); }
    video.srcObject = stream; await video.play();
    if (!landmarker) {
      let vision;
      try { vision = await import(`${TASKS}/vision_bundle.mjs`); }
      catch (e) { C.stop(); throw new Error('Impossible de charger MediaPipe (réseau ou politique de sécurité de la page).'); }
      const fs = await vision.FilesetResolver.forVisionTasks(`${TASKS}/wasm`);
      landmarker = await vision.PoseLandmarker.createFromOptions(fs, {
        baseOptions: { modelAssetPath: MODEL, delegate: 'GPU' }, runningMode: 'VIDEO', numPoses: 1 });
    }
    running = true; loop();
  };

  C.stop = function () {
    running = false; cap = null;
    if (stream) stream.getTracks().forEach((t) => t.stop());
    stream = null; if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  /** Capture `seconds` secondes de points (aucune image). */
  C.capture = function (seconds = 3) {
    return new Promise((res) => { cap = { frames: [], until: performance.now() + seconds * 1000, res }; });
  };

  function loop() {
    if (!running) return;
    if (video.readyState >= 2 && video.currentTime !== lastT) {
      lastT = video.currentTime;
      const W = video.videoWidth, H = video.videoHeight;
      if (canvas.width !== W) { canvas.width = W; canvas.height = H; }
      const r = landmarker.detectForVideo(video, performance.now());
      const lm = r.landmarks && r.landmarks[0];
      ctx.clearRect(0, 0, W, H);
      let info = { detected: false, confidence: 0, angles: null };
      if (lm) {
        const vis = (i) => (typeof lm[i].visibility === 'number' ? lm[i].visibility : 0);   // non fournie = non fiable
        const P = (i) => [lm[i].x * W, lm[i].y * H];
        ctx.lineWidth = Math.max(2, W / 240);
        for (const [a, b] of CONN) { ctx.strokeStyle = vis(a) > 0.6 && vis(b) > 0.6 ? '#5fd0ff' : '#ff7b7b'; ctx.beginPath(); ctx.moveTo(...P(a)); ctx.lineTo(...P(b)); ctx.stroke(); }
        for (const i of REQ) { ctx.fillStyle = vis(i) > 0.6 ? '#ffffff' : '#ff7b7b'; ctx.beginPath(); ctx.arc(...P(i), Math.max(3, W / 160), 0, Math.PI * 2); ctx.fill(); }
        const conf = REQ.reduce((s, i) => s + vis(i), 0) / REQ.length;
        const mid = (a, b) => [(P(a)[0] + P(b)[0]) / 2, (P(a)[1] + P(b)[1]) / 2];
        const sm = mid(11, 12), hm = mid(23, 24);
        info = {
          detected: true, confidence: conf,
          angles: {
            shL: ang(P(13), P(11), P(23)), shR: ang(P(14), P(12), P(24)),
            elL: 180 - ang(P(11), P(13), P(15)), elR: 180 - ang(P(12), P(14), P(16)),
            trunk: Math.atan2(Math.abs(sm[0] - hm[0]), Math.abs(hm[1] - sm[1])) * 180 / Math.PI,
          },
        };
        if (cap) cap.frames.push(lm.map((p) => [p.x, p.y, p.z, typeof p.visibility === 'number' ? p.visibility : 0]));
      } else if (cap) cap.frames.push(null);   // image sans personne : comptée dans le taux de détection
      if (cap && performance.now() >= cap.until) { const c = cap; cap = null; c.res({ frames: c.frames, image_w: W, image_h: H }); }
      cb && cb(info);
    }
    requestAnimationFrame(loop);
  }
  return C;
})();
