/* ErgoGuard AI – Smart Jig : graphiques comparatifs (SVG, sans bibliothèque).
 * Séries « Initial » (orange #eb6834) et « Optimisé » (bleu #2a78d6) : paire validée
 * (contraste et daltonismes). Zones d'élévation : couleurs d'état + libellés, jamais la couleur seule. */
window.EG = window.EG || {};

EG.Charts = (function () {
  const C = {}, NS = 'http://www.w3.org/2000/svg';
  const INIT = '#eb6834', OPT = '#2a78d6', INK = '#0e1b2b', MUTED = '#5b6b7c', GRID = '#e3e9f0';
  const tip = () => document.getElementById('tip');

  function el(tag, attrs = {}, parent) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    if (parent) parent.appendChild(e); return e;
  }
  function text(parent, x, y, s, a = {}) { const t = el('text', { x, y, fill: MUTED, 'font-size': 11, ...a }, parent); t.textContent = s; return t; }
  function hover(node, html) {
    node.addEventListener('mousemove', (e) => { const t = tip(); t.innerHTML = html; t.style.opacity = 1; t.style.left = e.clientX + 12 + 'px'; t.style.top = e.clientY - 34 + 'px'; });
    node.addEventListener('mouseleave', () => { tip().style.opacity = 0; });
  }
  function bar(parent, x, y, w, h, fill) { // extrémité de données arrondie (4 px), base droite
    const r = Math.min(4, h / 2, w);
    const d = w <= 0 ? '' : `M${x},${y} H${x + w - r} Q${x + w},${y} ${x + w},${y + r} V${y + h - r} Q${x + w},${y + h} ${x + w - r},${y + h} H${x} Z`;
    return el('path', { d, fill }, parent);
  }

  /** Barres groupées horizontales : angles moyens initial / optimisé (une seule unité : degrés). */
  C.angles = function (host, ini, opt) {
    const rows = [
      ['Élévation de l\'épaule — moyenne', ini.shoulder.mean, opt.shoulder.mean],
      ['Élévation de l\'épaule — maximum', ini.shoulder.max, opt.shoulder.max],
      ['Flexion du coude — moyenne', ini.elbow.mean, opt.elbow.mean],
      ['Regard vers le centre (sous l\'horizontale)', ini.gaze.centre, opt.gaze.centre],
    ];
    const W = 600, L = 8, top = 4, rowH = 46, bh = 12, H = top + rows.length * rowH + 18;
    const max = Math.ceil(Math.max(...rows.flatMap((r) => [r[1], r[2]]), 30) / 30) * 30;
    const plotW = W - L - 44, x = (v) => L + (Math.max(0, v) / max) * plotW;
    host.innerHTML = ''; const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Angles articulaires initial et optimisé' }, host);
    for (let t = 0; t <= max; t += 30) { el('line', { x1: x(t), x2: x(t), y1: top, y2: H - 16, stroke: GRID }, svg); text(svg, x(t), H - 3, `${t}°`, { 'text-anchor': 'middle' }); }
    rows.forEach(([lab, a, b], i) => {
      const y0 = top + i * rowH;
      text(svg, L, y0 + 11, lab, { fill: INK, 'font-size': 11.5 });
      [[a, INIT, 'Initial'], [b, OPT, 'Optimisé']].forEach(([v, col, name], j) => {
        const y = y0 + 16 + j * (bh + 2);
        const r = bar(svg, L, y, x(v) - L, bh, col);
        text(svg, x(v) + 5, y + bh - 2, `${v.toFixed(0)}°`, { fill: INK });
        const hit = el('rect', { x: L, y, width: plotW + 40, height: bh, fill: 'transparent' }, svg);
        hover(hit, `${lab}<br><b>${name}</b> : ${v.toFixed(1)}°`);
      });
    });
    el('line', { x1: L, x2: L, y1: top, y2: H - 16, stroke: '#9fb0c2' }, svg);
  };

  /** Barres empilées 100 % : répartition de l'élévation de l'épaule. */
  C.zones = function (host, ini, opt) {
    const Z = [['0-20', '≤ 20°', '#2e9e5b'], ['20-45', '20–45°', '#d99a1e'], ['45-90', '45–90°', '#d14b4b'], ['>90', '> 90°', '#8f2727']];
    const W = 600, L = 72, bh = 22, H = 2 * 34 + 30;
    host.innerHTML = ''; const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Répartition des zones d\'élévation' }, host);
    const plotW = W - L - 6;
    [['Initial', ini.shoulder.bins], ['Optimisé', opt.shoulder.bins]].forEach(([name, bins], i) => {
      const y = 6 + i * 34; let x0 = L;
      text(svg, 0, y + 15, name, { fill: INK, 'font-size': 12, 'font-weight': 600 });
      Z.forEach(([k, lab, col]) => {
        const w = (bins[k] / 100) * plotW; if (w <= 0) return;
        const r = el('rect', { x: x0, y, width: Math.max(0, w - 2), height: bh, rx: 3, fill: col }, svg);
        if (bins[k] >= 9) text(svg, x0 + 6, y + 15, `${bins[k].toFixed(0)} %`, { fill: '#fff', 'font-weight': 600 });
        hover(r, `<b>${name}</b> · épaule ${lab} : ${bins[k].toFixed(1)} % des points (pondérés)`);
        x0 += w;
      });
    });
    let lx = L; Z.forEach(([, lab, col]) => { el('rect', { x: lx, y: H - 14, width: 10, height: 10, rx: 2, fill: col }, svg); text(svg, lx + 14, H - 5, lab, { fill: INK }); lx += 80; });
  };

  /** Courbe de convergence (une série : pas de légende, le titre la nomme). */
  C.convergence = function (host, hist) {
    const W = 600, H = 170, L = 46, B = 22, T = 8, R = 8;
    host.innerHTML = ''; const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Convergence de J' }, host);
    const lo = Math.min(...hist), hi = Math.max(...hist), pad = (hi - lo) * 0.1 || 0.01;
    const y = (v) => T + (1 - (v - (lo - pad)) / (hi - lo + 2 * pad)) * (H - T - B);
    const x = (i) => L + (i / Math.max(1, hist.length - 1)) * (W - L - R);
    for (let k = 0; k <= 3; k++) { const v = lo - pad + (k / 3) * (hi - lo + 2 * pad); el('line', { x1: L, x2: W - R, y1: y(v), y2: y(v), stroke: GRID }, svg); text(svg, L - 6, y(v) + 4, v.toFixed(3), { 'text-anchor': 'end' }); }
    text(svg, L, H - 5, 'itération 0'); text(svg, W - R, H - 5, `${hist.length - 1}`, { 'text-anchor': 'end' });
    el('path', { d: hist.map((v, i) => `${i ? 'L' : 'M'}${x(i)},${y(v)}`).join(' '), fill: 'none', stroke: OPT, 'stroke-width': 2, 'stroke-linejoin': 'round' }, svg);
    const dot = el('circle', { r: 4, fill: OPT, stroke: '#fff', 'stroke-width': 2, opacity: 0 }, svg);
    const cross = el('line', { y1: T, y2: H - B, stroke: '#9fb0c2', opacity: 0 }, svg);
    const hit = el('rect', { x: L, y: T, width: W - L - R, height: H - T - B, fill: 'transparent' }, svg);
    hit.addEventListener('mousemove', (e) => {
      const r = svg.getBoundingClientRect(), px = ((e.clientX - r.left) / r.width) * W;
      const i = Math.max(0, Math.min(hist.length - 1, Math.round(((px - L) / (W - L - R)) * (hist.length - 1))));
      dot.setAttribute('cx', x(i)); dot.setAttribute('cy', y(hist[i])); dot.setAttribute('opacity', 1);
      cross.setAttribute('x1', x(i)); cross.setAttribute('x2', x(i)); cross.setAttribute('opacity', 1);
      const t = tip(); t.innerHTML = `Itération ${i}<br><b>J = ${hist[i].toFixed(4)}</b>`; t.style.opacity = 1; t.style.left = e.clientX + 12 + 'px'; t.style.top = e.clientY - 34 + 'px';
    });
    hit.addEventListener('mouseleave', () => { dot.setAttribute('opacity', 0); cross.setAttribute('opacity', 0); tip().style.opacity = 0; });
  };
  return C;
})();
