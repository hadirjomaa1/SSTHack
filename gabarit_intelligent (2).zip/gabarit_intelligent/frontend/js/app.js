/* ErgoGuard AI – Smart Jig : orchestration de l'interface (zones A à D).
 * Toute valeur ergonomique affichée provient du moteur Python (EG.Engine). */
(function () {
  const $ = (id) => document.getElementById(id);
  const E = EG.Engine;
  const st = { meta: null, profileId: 'P50F', base: null, body: null, initial: null, weights: null, result: null, busy: false };
  const fmt = { cm: (m) => `${(m * 100).toFixed(1)} cm`, deg: (d) => `${d.toFixed(1)}°` };

  function msg(host, kind, title, items = []) {
    $(host).innerHTML = `<div class="msg ${kind}">${title}${items.length ? '<ul>' + items.map((x) => `<li>${x}</li>`).join('') + '</ul>' : ''}</div>`;
  }
  function errMsg(host, e) { msg(host, 'bad', `<b>${e.message}</b>`, Array.isArray(e.details) ? e.details.map((d) => (typeof d === 'string' ? d : `${d.champ} : ${d.message}`)) : []); }

  /* ------------------------------------------------------------ Démarrage */
  async function boot() {
    EG.Scene.init($('view'));
    const mode = await E.init();
    const pill = $('pillEngine');
    pill.className = 'pill ' + (mode === 'offline' ? 'bad' : 'ok');
    pill.querySelector('span').textContent = E.label();
    if (mode === 'offline') {
      const why = E.error ? ` (${E.error.message})` : '';
      msg('bodyMsg', 'bad', `<b>Moteur de calcul indisponible${why}.</b> Lancez le serveur : <code>uvicorn backend.app:app</code> puis ouvrez http://localhost:8000.`);
      msg('optMsg', 'bad', 'Optimisation impossible sans moteur de calcul.');
      $('applyBody').disabled = true;
      return;
    }
    if (mode === 'pyodide') $('repDl').hidden = true;   // page hébergée : téléchargement non autorisé, la copie reste possible
    st.meta = await E.call('profiles');
    EG.Scene.setSpeeds(st.meta.axis_speed);
    st.initial = { ...st.meta.default_initial };
    st.weights = { ...st.meta.default_weights };
    buildProfiles(); buildInitial(); buildWeights(); resetSteps();
    $('sourcesNote').innerHTML = `<b>Sources.</b> ${Object.values(st.meta.sources).join(' ')}<br><b>Attention.</b> ${st.meta.warning}`;
    selectProfile('P50F');
    await applyBody();
  }

  /* ------------------------------------------------------------ Zone A : simulation */
  function buildProfiles() {
    const chips = st.meta.profiles.map((p) => `<button class="chip" data-p="${p.id}" title="${p.label}">${p.id.replace('F', ' F').replace('H', ' H')}</button>`).join('')
      + '<button class="chip" data-p="CUSTOM">Personnalisé</button>';
    $('profileChips').innerHTML = chips;
    $('profileChips').querySelectorAll('.chip').forEach((c) => (c.onclick = () => { selectProfile(c.dataset.p); applyBody(); }));
    $('dimsForm').innerHTML = st.meta.dimensions.map((k) => `<label for="dim_${k}">${st.meta.dimension_labels[k]}<small id="org_${k}"></small></label>
      <div class="num" id="box_${k}"><input id="dim_${k}" type="number" step="0.1" min="10" max="250"><span>cm</span></div>`).join('');
    st.meta.dimensions.forEach((k) => ($(`dim_${k}`).oninput = () => {
      const changed = st.base && Math.abs(+$(`dim_${k}`).value / 100 - st.base.dims[k]) > 1e-4;
      $(`box_${k}`).classList.toggle('changed', !!changed);
      $(`org_${k}`).textContent = changed ? st.meta.origins.saisie : (st.base ? st.meta.origins[st.base.origin[k]] || '' : '');
      if (changed) markChips('CUSTOM');
    }));
  }
  function markChips(id) { st.profileId = id; $('profileChips').querySelectorAll('.chip').forEach((c) => c.classList.toggle('on', c.dataset.p === id)); }
  function selectProfile(id) {
    markChips(id);
    const p = st.meta.profiles.find((x) => x.id === id);
    if (p) { st.base = { id, dims: p.dimensions, origin: p.origin }; $('profileNote').textContent = p.label; }
    else { $('profileNote').textContent = 'Profil personnalisé : saisissez des dimensions mesurées (toise, mètre ruban).'; }
    if (st.base) fillDims(st.base.dims, st.base.origin);
  }
  function fillDims(dims, origin) {
    st.meta.dimensions.forEach((k) => {
      $(`dim_${k}`).value = (dims[k] * 100).toFixed(1);
      $(`box_${k}`).classList.remove('changed');
      $(`org_${k}`).textContent = st.meta.origins[origin[k]] || origin[k] || '';
    });
  }
  async function applyBody() {
    const dims = {}, origin = {};
    let changed = false;
    for (const k of st.meta.dimensions) {
      const v = parseFloat($(`dim_${k}`).value);
      dims[k] = Number.isFinite(v) ? v / 100 : null;
      const same = st.base && dims[k] !== null && Math.abs(dims[k] - st.base.dims[k]) < 1e-4;
      origin[k] = same ? st.base.origin[k] : 'saisie';
      changed = changed || !same;
    }
    const req = !changed && st.profileId !== 'CUSTOM' ? { mode: 'simulation', profile_id: st.profileId }
      : { mode: 'personnalise', dimensions: dims, origin, label: 'Profil personnalisé' };
    try { await useAcquisition(await E.call('acquire', req), 'bodyMsg'); }
    catch (e) { st.body = null; errMsg('bodyMsg', e); refreshButtons(); }
  }

  async function useAcquisition(r, host) {
    const kind = { simulation: '', personnalise: '', webcam_2d: 'est', aruco_2d: 'est', realsense_3d: 'meas' };
    if (!r.ok) {
      st.body = null; refreshButtons();
      setHud('Morphologie refusée : la 3D montre la dernière morphologie valide', 'move');
      msg(host, 'bad', '<b>Mesures refusées : optimisation impossible.</b>', r.errors);
      return false;
    }
    st.body = r.body;
    const q = r.quality ? ` · ${r.quality.frames_valid}/${r.quality.frames_total} images exploitables` : '';
    const unc = r.body.uncertainty_m ? ` · incertitude ±${(r.body.uncertainty_m * 100).toFixed(1)} cm` : '';
    msg(host, r.warnings.length ? 'warn' : 'ok', `<span class="srcbadge ${kind[r.body.source] || ''}">${r.body.source_label}</span><br>Morphologie validée${q}${unc}.`, r.warnings);
    if (host !== 'bodyMsg') { st.base = { id: 'CAM', dims: r.body, origin: r.body.origin }; markChips('CUSTOM'); fillDims(r.body, r.body.origin); }
    await evaluateInitial();
    return true;
  }

  /* ------------------------------------------------------------ Zone A : caméra */
  function camUI(on) { $('camStart').disabled = on || !$('camConsent').checked; $('camStop').disabled = !on; $('camCapture').disabled = !on; $('camReset').disabled = !on; $('camPh').hidden = on; }
  $('camConsent').onchange = () => { camUI(false); if (!$('camConsent').checked) { EG.Camera.stop(); camUI(false); } };
  $('camStart').onclick = async () => {
    $('camStart').disabled = true; msg('camMsg', 'info', 'Démarrage de la caméra et chargement du modèle MediaPipe…');
    try {
      await EG.Camera.start($('camVideo'), $('camCanvas'), onCamFrame);
      camUI(true); msg('camMsg', 'info', 'Placez-vous en entier dans le cadre, bras le long du corps, puis « Capturer ».');
    } catch (e) { camUI(false); msg('camMsg', 'bad', `<b>${e.message}</b>`); }
  };
  $('camStop').onclick = () => { EG.Camera.stop(); camUI(false); };
  $('camReset').onclick = () => { st.body = null; refreshButtons(); msg('camMsg', 'info', 'Acquisition réinitialisée. Reprenez la posture de référence puis « Capturer ».'); };
  function onCamFrame(f) {
    const c = Math.round(f.confidence * 100);
    $('camConfV').textContent = f.detected ? `${c} %` : 'aucune personne';
    $('camConf').style.width = `${c}%`;
    $('camConf').style.background = c >= 80 ? 'var(--ok)' : c >= 60 ? 'var(--warn)' : 'var(--bad)';
    const a = f.angles, s = (v) => (a ? `${v.toFixed(0)}°` : '—');
    $('angShL').textContent = s(a && a.shL); $('angShR').textContent = s(a && a.shR);
    $('angElL').textContent = s(a && a.elL); $('angElR').textContent = s(a && a.elR); $('angTr').textContent = s(a && a.trunk);
  }
  $('camCapture').onclick = async () => {
    const s = parseFloat($('declStature').value);
    if (!(s >= 135 && s <= 210)) { msg('camMsg', 'bad', '<b>Saisissez la stature mesurée à la toise (135–210 cm).</b> Une webcam 2D ne peut pas mesurer les distances : sans elle, aucune dimension ne serait fiable.'); return; }
    $('camCapture').disabled = true; msg('camMsg', 'info', 'Capture en cours (3 s) : restez immobile…');
    const cap = await EG.Camera.capture(3);
    try { await useAcquisition(await E.call('acquire', { mode: 'webcam_2d', declared_stature: s / 100, ...cap }), 'camMsg'); }
    catch (e) { errMsg('camMsg', e); }
    $('camCapture').disabled = false;
  };
  async function serverCam(mode) {
    msg('hwMsg', 'info', `Acquisition ${mode} sur le serveur…`);
    const s = parseFloat($('declStature').value);
    try { await useAcquisition(await E.call('acquire', { mode, declared_stature: s >= 135 ? s / 100 : undefined }), 'hwMsg'); }
    catch (e) { errMsg('hwMsg', e); }
  }
  $('rsBtn').onclick = () => serverCam('realsense');
  $('arucoBtn').onclick = () => serverCam('aruco');
  document.querySelectorAll('.tabs button').forEach((b) => (b.onclick = () => {
    document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
    $('tabSim').hidden = b.dataset.tab !== 'sim'; $('tabCam').hidden = b.dataset.tab !== 'cam';
  }));

  /* ------------------------------------------------------------ Zone C : réglages */
  function buildInitial() {
    const set = () => { $('iniHin').value = (st.initial.h * 100).toFixed(1); $('iniAin').value = st.initial.a.toFixed(1); $('iniDin').value = (st.initial.d * 100).toFixed(1); };
    set();
    let t;
    ['iniHin', 'iniAin', 'iniDin'].forEach((id) => ($(id).oninput = () => {
      clearTimeout(t);
      t = setTimeout(() => {
        const h = parseFloat($('iniHin').value) / 100, a = parseFloat($('iniAin').value), d = parseFloat($('iniDin').value) / 100;
        if (![h, a, d].every(Number.isFinite)) return;
        st.initial = { h, a, d }; evaluateInitial();
      }, 400);
    }));
  }
  function buildWeights() {
    const lab = { epaule: 'w1 · épaule', allonge: 'w2 · allonge', cou: 'w3 · cou', deplacement: 'w4 · déplacement' };
    $('weights').innerHTML = Object.keys(lab).map((k) => `<div class="slider"><label for="w_${k}">${lab[k]}</label><output id="o_${k}">${st.weights[k].toFixed(2)}</output>
      <input type="range" id="w_${k}" min="0" max="${k === 'deplacement' ? 1 : 2}" step="0.05" value="${st.weights[k]}"></div>`).join('');
    Object.keys(lab).forEach((k) => ($(`w_${k}`).oninput = (e) => { st.weights[k] = +e.target.value; $(`o_${k}`).textContent = st.weights[k].toFixed(2); markOutdated(); }));
  }
  function refreshButtons() { $('optBtn').disabled = !st.body || st.busy; $('reportBtn').disabled = !st.result || st.busy; }
  function markOutdated() { if (st.result) { st.result = null; $('dSub').textContent = 'Résultat périmé : relancez l\'analyse'; refreshButtons(); } }

  async function evaluateInitial() {
    refreshButtons();
    if (!st.body) return;
    try {
      const ev = await E.call('evaluate', { body: st.body, config: st.initial, with_postures: true });
      st.result = null; st.initialEval = ev;
      EG.Scene.showInitial(st.body, ev);
      setMarkers(st.initial, null);
      setHud(ev.feasible ? 'Configuration initiale (non optimisée)' : 'Configuration initiale : contrainte(s) non respectée(s)', ev.feasible ? '' : 'move');
      renderDashboard(ev, null); resetSteps();
      $('optMsg').innerHTML = ''; $('dSub').textContent = 'Configuration initiale évaluée';
    } catch (e) { errMsg('optMsg', e); }
    refreshButtons();
  }

  /* ------------------------------------------------------------ Zone C : pipeline */
  const STEPS = ['Vérifier les données anthropométriques', 'Indicateurs ergonomiques initiaux', 'Algorithme d\'optimisation', 'Réglages optimaux H, A, D',
    'Contraintes mécaniques', 'Déplacement simulé du gabarit', 'Nouveaux indicateurs', 'Comparaison avant / après'];
  function resetSteps() { $('steps').innerHTML = STEPS.map((s, i) => `<li id="st${i}"><b>${s}</b><span class="d" id="sd${i}"></span></li>`).join(''); }
  function step(i, cls, detail) { $(`st${i}`).className = cls; if (detail !== undefined) $(`sd${i}`).textContent = detail; }
  const pause = (ms) => new Promise((r) => setTimeout(r, ms));    // rythme d'affichage uniquement

  $('optBtn').onclick = async () => {
    if (!st.body || st.busy) return;
    st.busy = true; refreshButtons(); resetSteps(); $('optMsg').innerHTML = '';
    step(0, 'run');
    let res;
    try { res = await E.call('optimize', { body: st.body, initial: st.initial, weights: st.weights }); }
    catch (e) { step(0, 'fail', e.message); errMsg('optMsg', e); st.busy = false; refreshButtons(); return; }
    const v = res.validation;
    step(0, 'done', v.warnings.length ? `valide · ${v.warnings.length} avertissement(s)` : 'valide'); await pause(250);
    step(1, 'done', `J = ${res.initial.J.toFixed(3)} · épaule moy. ${res.initial.indicators.shoulder.mean}°${res.initial.feasible ? '' : ' · contrainte violée'}`); await pause(250);
    if (res.status === 'infaisable') {
      step(2, 'fail', 'aucune solution conforme'); msg('optMsg', 'bad', `<b>${res.message}</b>`);
      renderDashboard(res.initial, res.optimal, res); st.busy = false; refreshButtons(); return;
    }
    const cv = res.convergence;
    step(2, 'done', `${cv.evaluations} évaluations · ${cv.starts} départs · ${cv.converged ? 'convergé' : 'NON convergé'} · ${res.compute_ms.toFixed(0)} ms`); await pause(250);
    const o = res.optimal.config;
    step(3, 'done', `H ${fmt.cm(o.h)} · A ${fmt.deg(o.a)} · D ${fmt.cm(o.d)}`); await pause(250);
    const cons = res.optimal.constraints, okN = cons.filter((c) => c.ok).length;
    step(4, okN === cons.length ? 'done' : 'fail', `${okN}/${cons.length} respectées`); await pause(250);
    st.result = res;
    setMarkers(res.initial.config, o);
    if (res.status === 'optimal') {
      step(5, 'run', `≈ ${res.move_time_s.toFixed(1)} s en temps réel${$('tFast').checked ? ' (affiché ×4)' : ''}`);
      setHud('Mains hors zone · déplacement simulé des vérins', 'move');
      replayConsole(res.controller);
      await EG.Scene.playOptimization(st.body, res);
      step(5, 'done');
    } else { step(5, 'done', 'aucun déplacement nécessaire'); }
    setHud(res.status === 'optimal' ? 'Position optimale atteinte (simulation)' : 'Configuration initiale conservée', 'lock');
    step(6, 'done', `J = ${res.optimal.J.toFixed(3)} · épaule moy. ${res.optimal.indicators.shoulder.mean}°`); await pause(200);
    const dJ = res.initial.J - res.optimal.J;
    step(7, 'done', res.status === 'optimal' ? `J −${(100 * dJ / res.initial.J).toFixed(0)} %` : 'aucune amélioration possible');
    msg('optMsg', res.status === 'optimal' ? 'ok' : 'info', res.message);
    renderDashboard(res.initial, res.optimal, res);
    $('dSub').textContent = 'Initial → optimisé';
    st.busy = false; refreshButtons();
  };

  function replayConsole(ctrl) {
    const con = $('console');
    con.innerHTML = `<span class="sys">${ctrl.note}</span>\n`;
    const k = $('tFast').checked ? 4 : 1;
    ctrl.events.forEach((ev) => setTimeout(() => {
      con.innerHTML += `<span class="${ev.dir}">[${ev.t.toFixed(2).padStart(6)} s] ${ev.dir === 'tx' ? '→' : '←'} ${ev.line}</span>\n`;
      con.scrollTop = con.scrollHeight;
    }, 900 + (ev.t * 1000) / k));
  }

  /* ------------------------------------------------------------ Zone B : HUD */
  const lim = () => st.meta.axis_limits;
  const pct = (v, k) => `${(100 * (v - lim()[k][0]) / (lim()[k][1] - lim()[k][0])).toFixed(1)}%`;
  function setMarkers(ini, opt) {
    for (const k of ['h', 'a', 'd']) {
      const K = k.toUpperCase();
      $(`ini${K}`).style.left = pct(ini[k], k);
      $(`opt${K}`).hidden = !opt; if (opt) $(`opt${K}`).style.left = pct(opt[k], k);
    }
  }
  function setHud(t, cls) { $('hudState').textContent = t; $('hudState').className = cls || ''; }
  EG.Scene.onAxes((c) => {
    if (!st.meta) return;
    $('axH').textContent = fmt.cm(c.h); $('axA').textContent = fmt.deg(c.a); $('axD').textContent = fmt.cm(c.d);
    $('barH').style.width = pct(c.h, 'h'); $('barA').style.width = pct(c.a, 'a'); $('barD').style.width = pct(c.d, 'd');
  });
  document.querySelectorAll('#hudViews [data-view]').forEach((b) => (b.onclick = () => {
    document.querySelectorAll('#hudViews [data-view]').forEach((x) => x.classList.toggle('on', x === b)); EG.Scene.setView(b.dataset.view);
  }));
  document.querySelectorAll('#hudViews [data-zoom]').forEach((b) => (b.onclick = () => EG.Scene.zoom(b.dataset.zoom === 'in' ? 0.82 : 1.2)));
  document.querySelectorAll('#hudMode [data-mode]').forEach((b) => (b.onclick = () => {
    document.querySelectorAll('#hudMode [data-mode]').forEach((x) => x.classList.toggle('on', x === b)); EG.Scene.setMode(b.dataset.mode);
  }));
  $('tJoints').onchange = (e) => EG.Scene.setToggles({ joints: e.target.checked });
  $('tMap').onchange = (e) => EG.Scene.setToggles({ map: e.target.checked });
  $('tWork').onchange = (e) => EG.Scene.setToggles({ work: e.target.checked });
  $('tFast').onchange = (e) => EG.Scene.setFast(e.target.checked);

  /* ------------------------------------------------------------ Zone D : tableau de bord */
  function kpi(label, a, b, { fmtV, better, check, wide } = {}) {
    const f = fmtV || ((x) => x);
    let dl = '';
    if (b !== null && b !== undefined && better) {
      const rel = (b - a) / (Math.abs(a) || 1);
      if (Math.abs(rel) < 0.005) dl = '<span class="dl neu">=</span>';
      else dl = `<span class="dl ${rel * better > 0 ? 'good' : 'bad'}">${rel > 0 ? '+' : ''}${(rel * 100).toFixed(0)} %</span>`;
    } else if (check) { const ok = check(b ?? a); dl = `<span class="dl ${ok[0] ? 'good' : 'bad'}">${ok[1]}</span>`; }
    const after = b === null || b === undefined ? '' : `<span class="arrow">→</span><span class="b">${f(b)}</span>`;
    return `<div class="kpi${wide ? ' wide' : ''}"><div class="l">${label}</div><div class="v">${after ? `<span class="a">${f(a)}</span>${after}` : `<span class="b">${f(a)}</span>`}${dl}</div></div>`;
  }
  function renderDashboard(ini, opt, res) {
    const I = ini.indicators, O = opt ? opt.indicators : null, g = (o, p) => (O ? p(O) : null);
    const ci = ini.config, co = opt ? opt.config : null;
    const cards = [
      kpi('H · hauteur', ci.h, co && co.h, { fmtV: fmt.cm }),
      kpi('A · inclinaison', ci.a, co && co.a, { fmtV: fmt.deg }),
      kpi('D · distance', ci.d, co && co.d, { fmtV: fmt.cm }),
      kpi('Faisabilité du réglage', '', null, { fmtV: () => (opt ? (res.status === 'infaisable' ? 'Infaisable' : 'Conforme') : (ini.feasible ? 'Conforme' : 'Non conforme')),
        check: () => { const f = opt ? res.status !== 'infaisable' : ini.feasible; return [f, f ? 'toutes contraintes' : 'voir contraintes']; } }),
      kpi('Épaule · élévation moyenne', I.shoulder.mean, g(O, (x) => x.shoulder.mean), { fmtV: (x) => `${x.toFixed(0)}°`, better: -1 }),
      kpi('Épaule · élévation max', I.shoulder.max, g(O, (x) => x.shoulder.max), { fmtV: (x) => `${x.toFixed(0)}°`, better: -1 }),
      kpi('Points avec épaule > 45°', I.shoulder.share_above_45, g(O, (x) => x.shoulder.share_above_45), { fmtV: (x) => `${x.toFixed(0)} %`, better: -1 }),
      kpi('Coude · flexion moyenne', I.elbow.mean, g(O, (x) => x.elbow.mean), { fmtV: (x) => `${x.toFixed(0)}°`, check: (v) => [v >= 60 && v <= 100, v >= 60 && v <= 100 ? 'zone 60–100°' : 'hors 60–100°'] }),
      kpi('Regard vers le centre', I.gaze.centre, g(O, (x) => x.gaze.centre), { fmtV: (x) => `${x.toFixed(0)}°`, check: (v) => [v >= 15 && v <= 35, v >= 15 && v <= 35 ? 'zone 15–35°' : 'hors 15–35°'] }),
      kpi('Allonge maximale', I.reach.max_ratio, g(O, (x) => x.reach.max_ratio), { fmtV: (x) => `${(x * 100).toFixed(0)} %`, check: (v) => [v <= 1, v <= 1 ? 'atteignable' : 'hors d\'atteinte'] }),
      kpi('Fonction objectif J', opt ? res.initial.J : NaN, opt ? res.optimal.J : null, { fmtV: (x) => (Number.isFinite(x) ? x.toFixed(3) : '—'), better: -1 }),
      kpi('Temps de calcul', res ? res.compute_ms : NaN, null, { fmtV: (x) => (Number.isFinite(x) ? `${x.toFixed(0)} ms` : '—') }),
    ];
    $('kpis').innerHTML = cards.join('');
    const cons = (opt || ini).constraints;
    $('constraints').innerHTML = cons.map((c) => `<li><span class="st ${c.ok ? 'ok' : 'ko'}">${c.ok ? 'OK' : 'NON'}</span><span>${c.label}${c.value !== undefined ? ` <span class="mono">(${c.value} ; ${c.limit})</span>` : ''}</span></li>`).join('');
    const evO = (opt || ini).evaluations, evI = ini.evaluations;
    const badge = { partiel: ['part', 'partiel'], non_calculable: ['na', 'non calculable'], non_implemente: ['na', 'à venir'] };
    $('evals').innerHTML = Object.entries(evO).map(([k, e]) => {
      const vals = e.values ? '<br><span class="mono">' + Object.entries(e.values).map(([n, v]) => `${n} : ${opt ? `${evI[k].values[n]} → ` : ''}${v}`).join(' · ') + '</span>' : '';
      return `<li><span class="st ${badge[e.status][0]}">${badge[e.status][1]}</span><span><b>${e.name}</b>${vals}<br><span class="note">${e.note}${e.missing ? ' Manque : ' + e.missing.join(', ') + '.' : ''}</span></span></li>`;
    }).join('');
    $('limits').innerHTML = res ? res.limits.map((l) => `<li>${l}</li>`).join('') : '<li class="note">Affichées après l\'analyse.</li>';
    if (opt) {
      EG.Charts.angles($('chAngles'), I, O);
      EG.Charts.zones($('chZones'), I, O);
      if (res.convergence) EG.Charts.convergence($('chConv'), res.convergence.history); else $('chConv').innerHTML = '<div class="empty">Pas de recherche locale (problème infaisable).</div>';
    } else {
      $('chAngles').innerHTML = '<div class="empty">Lancez l\'analyse pour comparer.</div>';
      $('chZones').innerHTML = '<div class="empty">—</div>'; $('chConv').innerHTML = '<div class="empty">—</div>';
    }
  }

  /* ------------------------------------------------------------ Rapport */
  $('reportBtn').onclick = async () => {
    $('reportBtn').disabled = true;
    try { const r = await E.call('report', { body: st.body, initial: st.initial, weights: st.weights }); EG.Report.open(r.markdown); }
    catch (e) { errMsg('optMsg', e); }
    refreshButtons();
  };
  $('repClose').onclick = EG.Report.close;
  $('repCopy').onclick = (e) => EG.Report.copy(e.target);
  $('repDl').onclick = (e) => EG.Report.download(e.target);
  $('reportModal').onclick = (e) => { if (e.target.id === 'reportModal') EG.Report.close(); };
  $('applyBody').onclick = applyBody;

  boot().catch((e) => msg('bodyMsg', 'bad', `<b>Erreur au démarrage : ${e.message}</b>`));
})();
