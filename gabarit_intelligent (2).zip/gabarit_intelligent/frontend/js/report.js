/* ErgoGuard AI – Smart Jig : affichage du rapport automatique.
 * Le contenu est produit par le moteur Python (POST /api/report) ; ici, simple rendu Markdown. */
window.EG = window.EG || {};

EG.Report = (function () {
  const R = {};
  let md = '';
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const inline = (s) => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/_([^_]+)_/g, '<i>$1</i>');

  R.toHtml = function (text) {
    const out = [], lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (/^# /.test(l)) out.push(`<h1>${inline(l.slice(2))}</h1>`);
      else if (/^## /.test(l)) out.push(`<h2>${inline(l.slice(3))}</h2>`);
      else if (/^> /.test(l)) out.push(`<blockquote>${inline(l.slice(2))}</blockquote>`);
      else if (/^\|/.test(l)) {
        const rows = []; while (i < lines.length && /^\|/.test(lines[i])) rows.push(lines[i++]); i--;
        const cells = (r) => r.split('|').slice(1, -1).map((c) => c.trim());
        out.push('<table><thead><tr>' + cells(rows[0]).map((c) => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>' +
          rows.slice(2).map((r) => '<tr>' + cells(r).map((c) => `<td>${inline(c)}</td>`).join('') + '</tr>').join('') + '</tbody></table>');
      } else if (/^- /.test(l)) {
        const items = []; while (i < lines.length && /^(- |  )/.test(lines[i])) items.push(lines[i++]); i--;
        out.push('<ul>' + items.map((x) => (x.startsWith('- ') ? `<li>${inline(x.slice(2))}` : `<br><small>${inline(x.trim())}</small>`)).join('') + '</ul>');
      } else if (l.trim()) out.push(`<p>${inline(l)}</p>`);
    }
    return out.join('\n');
  };

  R.open = function (markdown) {
    md = markdown;
    document.getElementById('reportDoc').innerHTML = R.toHtml(md);
    document.getElementById('reportModal').classList.add('on');
  };
  R.close = () => document.getElementById('reportModal').classList.remove('on');
  R.copy = async function (btn) {
    try { await navigator.clipboard.writeText(md); btn.textContent = 'Copié ✓'; }
    catch (e) { btn.textContent = 'Copie refusée'; }
    setTimeout(() => (btn.textContent = 'Copier (Markdown)'), 1800);
  };
  R.download = function (btn) {
    try {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([md], { type: 'text/markdown' }));
      a.download = `rapport_gabarit_${new Date().toISOString().slice(0, 10)}.md`;
      document.body.appendChild(a); a.click(); a.remove();
    } catch (e) { btn.textContent = 'Téléchargement bloqué : utilisez Copier'; }
  };
  return R;
})();
