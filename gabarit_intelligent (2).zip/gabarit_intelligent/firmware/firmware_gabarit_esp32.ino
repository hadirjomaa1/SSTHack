/*
 * ErgoGuard AI – Gabarit intelligent : firmware ESP32 v2 (3 axes)
 * ================================================================
 * STATUT : firmware destiné à un FUTUR banc physique. Il n'est relié à aucun vérin dans la
 * démonstration actuelle : le jumeau numérique simule ses réponses (backend/firmware_protocol.py).
 *
 * Axes et unités (entiers dans la trame, mêmes unités en interne) :
 *   H : hauteur du centre, mm      [850, 1450]  — 2 colonnes élévatrices, 2 recopies (H1, H2)
 *   A : inclinaison, 0,1 °         [0, 400]
 *   D : distance de préhension, mm [300, 550]
 *
 * Protocole (115200 bauds, '\n') — somme de contrôle XOR (2 hex) sur tout ce qui précède '*' :
 *   MOVE H=<int> A=<int> D=<int> ID=<1..65535>*XX     STOP*XX   STATUS*XX   RESET*XX   HB*XX
 * Réponses (avec somme de contrôle) :
 *   OK ID=n · DONE H= A= D= ID=n · STATE <état> H= A= D= · ERR <code> · FAULT <code> <axe>
 *
 * SÉCURITÉ — IMPORTANT
 *   Un arrêt logiciel N'EST PAS une fonction de sécurité suffisante pour une machine réelle.
 *   Sur un banc réel : arrêt d'urgence et barrière immatérielle câblés dans une chaîne de sécurité
 *   (relais ou automate de sécurité) qui coupe la puissance des ponts en H, indépendamment de
 *   l'ESP32, avec un niveau de performance (PL) déterminé selon ISO 13849-1 après analyse de
 *   risques (ISO 12100). Le firmware lit seulement l'état de cette chaîne (SAFETY_OK) et refuse
 *   tout mouvement si elle est ouverte ; il ajoute des surveillances (pincement, calage, capteurs,
 *   synchronisme, battement de cœur) qui réduisent les risques mais ne remplacent pas la chaîne câblée.
 *
 * Machine d'états non bloquante (boucle de 10 ms, aucun delay()) :
 *   IDLE -> MOVING -> IDLE (DONE)
 *   MOVING -> BACKOFF (surintensité : recul bref) -> FAULT
 *   toute anomalie -> FAULT (verrouillé) ; RESET ne la lève que si la cause a disparu.
 *
 * Cœur Arduino-ESP32 2.x (ledcSetup / ledcAttachPin, esp_task_wdt_init(s, panic)).
 * En 3.x : ledcAttach(pin, freq, bits) et esp_task_wdt_init(&config).
 */
#include <Arduino.h>
#include <esp_task_wdt.h>

// ------------------------------------------------------------------ configuration
struct Axis {
  const char* name;
  uint8_t pinR, pinL, pinPot, pinCur;  // pont en H (RPWM/LPWM), recopie, courant (IS)
  uint8_t chR, chL;                    // canaux LEDC
  int minU, maxU;                      // course autorisée (unités de la trame)
  int adcMin, adcMax;                  // calibration de la recopie
  float pinchAmp;                      // seuil de surintensité (A)
  float deadband;                      // tolérance d'arrivée (unités)
  float target, pos, lastPos;
  bool active;
  int pwm;
  uint32_t lastProgressMs;
};

Axis axes[3] = {
  {"H", 25, 26, 34, 35, 0, 1,  850, 1450, 310, 3790, 6.0f, 2.0f, 0, 0, 0, false, 0, 0},
  {"A", 27, 14, 32, 33, 2, 3,    0,  400, 280, 3820, 3.0f, 3.0f, 0, 0, 0, false, 0, 0},
  {"D", 18, 19, 36, 39, 4, 5,  300,  550, 300, 3800, 3.0f, 2.0f, 0, 0, 0, false, 0, 0},
};
const uint8_t PIN_H2_POT    = 13;  // recopie de la 2e colonne (synchronisme) — ADC2 : utilisable car Wi-Fi désactivé
const uint8_t PIN_SAFETY_OK = 4;   // retour de la chaîne de sécurité câblée : HIGH = puissance autorisée
const uint8_t PIN_ZONE      = 16;  // barrière immatérielle : LOW = main détectée dans la zone
const uint8_t PIN_LED       = 2;   // voyant « mouvement »
const uint8_t PIN_FAULT_LED = 17;  // voyant « défaut »

const int      PWM_MAX = 200, PWM_MIN = 70, RAMP_STEP = 6;
const uint32_t TICK_MS = 10;
const uint32_t TIMEOUT_MS = 45000;      // durée max d'un mouvement
const uint32_t HB_TIMEOUT_MS = 1500;    // l'hôte doit envoyer HB au moins toutes les 1,5 s pendant un mouvement
const uint32_t STALL_MS = 1500;         // moteur alimenté sans progression
const float    STALL_MIN_PROGRESS = 1.0f;
const uint32_t INRUSH_IGNORE_MS = 300;  // pic d'appel au démarrage
const uint32_t BACKOFF_MS = 400;
const int      ADC_FAULT_LO = 40, ADC_FAULT_HI = 4055;  // recopie coupée / en court-circuit
const float    SYNC_MAX_MM = 5.0f;

enum State { IDLE, MOVING, BACKOFF, FAULT };
State state = IDLE;
char faultCode[24] = "";
char faultAxis[4] = "";
uint32_t moveStart = 0, lastHb = 0, backoffStart = 0, lastTick = 0;
uint16_t cmdId = 0;
int backoffAxis = -1;
char rx[96]; uint8_t rxLen = 0; bool rxOverflow = false;

// ------------------------------------------------------------------ utilitaires
uint8_t xorSum(const char* s, size_t n) { uint8_t x = 0; for (size_t i = 0; i < n; i++) x ^= (uint8_t)s[i]; return x; }

void reply(const char* fmt, ...) {          // ajoute la somme de contrôle
  char buf[112]; va_list ap; va_start(ap, fmt); int n = vsnprintf(buf, sizeof(buf) - 4, fmt, ap); va_end(ap);
  if (n < 0) return;
  Serial.printf("%s*%02X\n", buf, xorSum(buf, strlen(buf)));
}

int readAdcAvg(uint8_t pin) { long s = 0; for (int i = 0; i < 8; i++) s += analogRead(pin); return (int)(s / 8); }
float adcToUnits(const Axis& a, int adc) { return a.minU + (adc - a.adcMin) * float(a.maxU - a.minU) / float(a.adcMax - a.adcMin); }
float readAmp(const Axis& a) { return analogRead(a.pinCur) * 3.3f / 4095.0f * 8.5f; }  // BTS7960, IS sur 1 kΩ

void drive(Axis& a, int pwm) { ledcWrite(a.chR, pwm > 0 ? pwm : 0); ledcWrite(a.chL, pwm < 0 ? -pwm : 0); }
void stopMotors() { for (auto& a : axes) { drive(a, 0); a.active = false; a.pwm = 0; } digitalWrite(PIN_LED, LOW); }

void enterFault(const char* code, const char* axis) {
  stopMotors();
  state = FAULT;
  strncpy(faultCode, code, sizeof(faultCode) - 1); strncpy(faultAxis, axis, sizeof(faultAxis) - 1);
  digitalWrite(PIN_FAULT_LED, HIGH);
  reply("FAULT %s %s", faultCode, faultAxis);
}

const char* stateName() { switch (state) { case IDLE: return "IDLE"; case MOVING: return "MOVING"; case BACKOFF: return "BACKOFF"; default: return "FAULT"; } }

// Entier strict : signe optionnel puis chiffres uniquement, borné.
bool parseIntStrict(const char* s, long lo, long hi, long* out) {
  if (!s || !*s) return false;
  char* end; long v = strtol(s, &end, 10);
  if (*end != '\0' || end == s || v < lo || v > hi) return false;
  *out = v; return true;
}

// ------------------------------------------------------------------ commandes
void handleMove(char* args) {
  // Exactement 4 champs dans l'ordre H= A= D= ID=
  const char* keys[4] = {"H=", "A=", "D=", "ID="};
  long val[4];
  char* tok = strtok(args, " ");
  for (int i = 0; i < 4; i++) {
    if (!tok || strncmp(tok, keys[i], strlen(keys[i])) != 0) { reply("ERR SYNTAX"); return; }
    long lo = i < 3 ? axes[i].minU : 1, hi = i < 3 ? axes[i].maxU : 65535;
    if (!parseIntStrict(tok + strlen(keys[i]), lo, hi, &val[i])) { reply("ERR RANGE %s", i < 3 ? axes[i].name : "ID"); return; }
    tok = strtok(nullptr, " ");
  }
  if (tok) { reply("ERR SYNTAX"); return; }
  if (state == FAULT) { reply("ERR LOCKED %s", faultCode); return; }
  if (state != IDLE)  { reply("ERR BUSY"); return; }
  if (digitalRead(PIN_SAFETY_OK) != HIGH) { reply("ERR SAFETY_OPEN"); return; }
  if (digitalRead(PIN_ZONE) == LOW) { reply("ERR ZONE_OCCUPIED"); return; }
  uint32_t now = millis();
  for (int i = 0; i < 3; i++) { Axis& a = axes[i]; a.target = val[i]; a.active = true; a.pwm = 0; a.lastPos = a.pos; a.lastProgressMs = now; }
  cmdId = (uint16_t)val[3]; moveStart = now; lastHb = now; state = MOVING;
  digitalWrite(PIN_LED, HIGH);
  reply("OK ID=%u", cmdId);
}

void handleLine(char* line) {
  char* star = strrchr(line, '*');
  if (!star || strlen(star + 1) != 2) { reply("ERR CHECKSUM_MISSING"); return; }
  long cs; char hex[3] = {star[1], star[2], 0}; char* end; cs = strtol(hex, &end, 16);
  if (*end != '\0' || cs != xorSum(line, star - line)) { reply("ERR CHECKSUM"); return; }
  *star = '\0';
  if (strncmp(line, "MOVE ", 5) == 0) handleMove(line + 5);
  else if (strcmp(line, "HB") == 0) lastHb = millis();
  else if (strcmp(line, "STOP") == 0) { if (state == MOVING || state == BACKOFF) { stopMotors(); state = IDLE; } reply("STATE %s H=%.0f A=%.0f D=%.0f", stateName(), axes[0].pos, axes[1].pos, axes[2].pos); }
  else if (strcmp(line, "STATUS") == 0) {
    if (state == FAULT) reply("STATE FAULT %s %s H=%.0f A=%.0f D=%.0f", faultCode, faultAxis, axes[0].pos, axes[1].pos, axes[2].pos);
    else reply("STATE %s H=%.0f A=%.0f D=%.0f", stateName(), axes[0].pos, axes[1].pos, axes[2].pos);
  }
  else if (strcmp(line, "RESET") == 0) {
    if (state != FAULT) { reply("STATE %s", stateName()); return; }
    if (digitalRead(PIN_SAFETY_OK) != HIGH) { reply("ERR SAFETY_OPEN"); return; }
    if (digitalRead(PIN_ZONE) == LOW) { reply("ERR ZONE_OCCUPIED"); return; }
    state = IDLE; faultCode[0] = faultAxis[0] = '\0'; digitalWrite(PIN_FAULT_LED, LOW);
    reply("STATE IDLE");
  }
  else reply("ERR UNKNOWN");
}

void pollSerial() {
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      if (rxOverflow) reply("ERR TOO_LONG");
      else if (rxLen) { rx[rxLen] = '\0'; handleLine(rx); }
      rxLen = 0; rxOverflow = false;
    } else if (rxLen < sizeof(rx) - 1) rx[rxLen++] = c;
    else rxOverflow = true;
  }
}

// ------------------------------------------------------------------ surveillance + régulation (10 ms)
void tick() {
  uint32_t now = millis();
  // Capteurs : lecture et détection de recopie défaillante (dans tous les états)
  for (auto& a : axes) {
    int adc = readAdcAvg(a.pinPot);
    if ((adc < ADC_FAULT_LO || adc > ADC_FAULT_HI) && state != FAULT) { enterFault("SENSOR", a.name); return; }
    a.pos = adcToUnits(a, adc);
  }
  int adc2 = readAdcAvg(PIN_H2_POT);
  float h2 = adcToUnits(axes[0], adc2);
  if (state != FAULT && (adc2 < ADC_FAULT_LO || adc2 > ADC_FAULT_HI)) { enterFault("SENSOR", "H2"); return; }
  if (state != FAULT && fabsf(h2 - axes[0].pos) > SYNC_MAX_MM) { enterFault("SYNC", "H"); return; }

  // La chaîne de sécurité câblée coupe déjà la puissance ; ici on mémorise le défaut.
  if ((state == MOVING || state == BACKOFF) && digitalRead(PIN_SAFETY_OK) != HIGH) { enterFault("SAFETY_OPEN", "-"); return; }

  if (state == BACKOFF) {
    if (now - backoffStart >= BACKOFF_MS) enterFault("PINCH", axes[backoffAxis].name);
    return;
  }
  if (state != MOVING) return;

  if (digitalRead(PIN_ZONE) == LOW)         { enterFault("ZONE", "-"); return; }
  if (now - lastHb > HB_TIMEOUT_MS)         { enterFault("HOST_TIMEOUT", "-"); return; }
  if (now - moveStart > TIMEOUT_MS)         { enterFault("TIMEOUT", "-"); return; }

  bool any = false;
  for (int i = 0; i < 3; i++) {
    Axis& a = axes[i];
    if (!a.active) continue;
    float err = a.target - a.pos;
    if (fabsf(err) <= a.deadband) { drive(a, 0); a.active = false; a.pwm = 0; continue; }
    any = true;
    if (now - moveStart > INRUSH_IGNORE_MS && readAmp(a) > a.pinchAmp) {   // anti-pincement : recul non bloquant
      for (auto& b : axes) { drive(b, 0); b.active = false; b.pwm = 0; }
      drive(a, err > 0 ? -PWM_MIN : PWM_MIN);
      backoffAxis = i; backoffStart = now; state = BACKOFF;
      return;
    }
    if (fabsf(a.pos - a.lastPos) >= STALL_MIN_PROGRESS) { a.lastPos = a.pos; a.lastProgressMs = now; }
    else if (a.pwm >= PWM_MIN && now - a.lastProgressMs > STALL_MS) { enterFault("STALL", a.name); return; }
    int want = constrain((int)(fabsf(err) * 4), PWM_MIN, PWM_MAX);       // ralentissement à l'approche
    a.pwm = min(want, a.pwm + RAMP_STEP);                                // rampe d'accélération
    drive(a, err > 0 ? a.pwm : -a.pwm);
  }
  if (!any) {
    stopMotors(); state = IDLE;
    reply("DONE H=%.0f A=%.0f D=%.0f ID=%u", axes[0].pos, axes[1].pos, axes[2].pos, cmdId);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_SAFETY_OK, INPUT_PULLDOWN);   // absence de signal = chaîne ouverte
  pinMode(PIN_ZONE, INPUT_PULLDOWN);        // absence de signal = zone considérée occupée
  pinMode(PIN_LED, OUTPUT); pinMode(PIN_FAULT_LED, OUTPUT);
  analogReadResolution(12);
  for (auto& a : axes) {
    ledcSetup(a.chR, 20000, 8); ledcAttachPin(a.pinR, a.chR);
    ledcSetup(a.chL, 20000, 8); ledcAttachPin(a.pinL, a.chL);
    drive(a, 0);
  }
  esp_task_wdt_init(2, true);   // chien de garde : redémarrage (moteurs à l'arrêt) si la boucle se bloque > 2 s
  esp_task_wdt_add(NULL);
  reply("STATE IDLE FW=2.0");
}

void loop() {
  esp_task_wdt_reset();
  pollSerial();
  uint32_t now = millis();
  if (now - lastTick >= TICK_MS) { lastTick = now; tick(); }
}
