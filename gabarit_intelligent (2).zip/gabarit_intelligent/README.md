# ErgoGuard AI — Smart Jig, jumeau numérique du gabarit intelligent

Poste 3.2 Montage faisceaux (LEONI) · SSTHack 2026 · moteur v2.0.0

Le gabarit intelligent mesure la morphologie de l'opératrice, calcule le réglage de ses trois axes
(**H** hauteur, **A** inclinaison, **D** distance de préhension) qui réduit les contraintes sur les
épaules, et simule le déplacement des vérins dans un jumeau numérique 3D.

> **Statut : simulation numérique.** Il n'existe pas de prototype physique. Les vérins et l'ESP32
> sont simulés ; aucune mesure n'est inventée et aucune amélioration n'est affichée si le calcul
> n'en trouve pas.

## Lancement

```bash
cd gabarit_intelligent
pip install -r backend/requirements.txt
uvicorn backend.app:app --port 8000
```

Ouvrir **http://localhost:8000**. Le serveur sert l'interface et l'API ; l'accès à la webcam
n'est autorisé par le navigateur que sur `localhost` ou en https.

Autres commandes :

```bash
python -m pytest tests -q                    # 47 tests (moteur, acquisition, protocole, API, firmware)
python tools/build_standalone.py             # page autonome dist/gabarit_3d_standalone.html (Pyodide)
cd backend && python smart_jig.py --compare  # CLI historique : tableau des profils de référence
```

Documentation de l'API générée automatiquement : http://localhost:8000/docs

## Arborescence

```
gabarit_intelligent/
├── backend/                  moteur Python = seule source de vérité des calculs
│   ├── app.py                API FastAPI (+ service du frontend)
│   ├── service.py            logique des endpoints (partagée par l'API et Pyodide)
│   ├── smart_jig.py          Body, validation, limites des axes, profils, CLI
│   ├── ergonomics.py         modèle biomécanique, indicateurs, évaluations normatives
│   ├── optimizer.py          fonction objectif, contraintes, recherche, convergence
│   ├── camera_measure.py     traitement webcam 2D, CameraMeasure (RealSense, ArUco)
│   ├── firmware_protocol.py  trames ESP32, contrôleur simulé, contrôleur série
│   ├── profiles.json         profils P5 / P50 / P95 documentés
│   └── requirements.txt
├── frontend/                 affichage uniquement (aucun calcul ergonomique en JS)
│   ├── gabarit_3d.html
│   ├── css/style.css
│   └── js/  engine.js · scene.js · camera.js · charts.js · report.js · app.js
├── firmware/firmware_gabarit_esp32.ino
├── tests/                    pytest + banc de test C++ du firmware (tests/firmware_host/)
├── tools/build_standalone.py
├── docs/AUDIT.md             audit de la v1 et architecture ; docs/v1_originaux/ = fichiers v1
└── dist/                     page autonome générée
```

## API

| Méthode | Route | Rôle |
|---|---|---|
| GET | `/api/health` | état du serveur, bibliothèques matérielles présentes |
| GET | `/api/profiles` | profils documentés, libellés, limites et vitesses des axes, poids par défaut |
| POST | `/api/acquire` | `mode` = `simulation` (profile_id) · `personnalise` (dimensions en m) · `webcam_2d` (frames de points + `declared_stature`) · `realsense` · `aruco` |
| POST | `/api/evaluate` | indicateurs, évaluations, contraintes et postures 3D d'une configuration |
| POST | `/api/optimize` | réglage optimal, J avant/après, convergence, commande ESP32 simulée |
| POST | `/api/report` | rapport automatique en Markdown |

Erreurs toujours au format `{"error": {"code", "message", "details"}}` : 422 (données invalides),
404 (profil inconnu), 503 (`materiel_requis`), 500 (erreur interne).

## Méthode de calcul

**Morphologie.** Sept dimensions en mètres : stature, hauteurs des yeux, des épaules et des coudes,
bras, avant-bras, largeur biacromiale. Chacune porte son origine (table, proportion, saisie,
estimation 2D, mesure 3D). `validate_body()` refuse les valeurs hors bornes, l'ordre anatomique
incohérent, les rapports à la stature aberrants, l'écart entre (épaules − coudes) et la longueur du
bras, et une incertitude supérieure à ±5 cm.

**Profils de référence** (`profiles.json`) : hauteurs d'après Pheasant & Haslegrave, *Bodyspace*,
3e éd. (adultes britanniques 19–65 ans) ; longueurs de segments d'après Winter (2009), en proportion
de la stature. La largeur biacromiale est à revérifier dans l'ouvrage. Pour LEONI Tunisie, ces
valeurs sont à remplacer par une campagne de mesures locale.

**Modèle biomécanique.** Deux segments par bras, coude placé au plus bas, tronc vertical. Le
gabarit est décrit par 35 points de travail pondérés par une hypothèse de répartition des tâches
(gaussienne centrée, σ = 25 cm). Calculés pour chaque point : élévation de l'épaule, flexion du
coude, allonge ; et, pour l'ensemble, la ligne de regard.

**Fonction objectif.** J = w1·J_épaule + w2·J_allonge + w3·J_cou + w4·J_déplacement.

| Poids | Valeur | Justification |
|---|---|---|
| w1 épaule | 1,0 | zone de TMS déclarée au poste (épaules douloureuses, sus-épineux) |
| w2 allonge | 0,8 | la sur-extension ajoute flexion du tronc et charge de l'épaule |
| w3 cou | 0,5 | contrôle visuel des codes couleur, pas de TMS déclaré |
| w4 déplacement | 0,05 | départage des solutions équivalentes, sans pouvoir dégrader l'ergonomie |

**Contraintes dures** : course des trois vérins, dégagement du gabarit d'au moins 20 cm devant les
épaules, bord bas au-dessus du bâti, bord haut sous le bâti, tous les points atteignables. La durée
du réglage est comparée au takt time (276 s).

**Optimisation** : grille de 702 réglages, puis recherche par motifs depuis les 3 meilleurs
départs, avec réduction du pas jusqu'à la résolution des vérins (1 mm, 0,25°). Elle est
déterministe et contrôle la convergence. Elle répond `infaisable` si aucun réglage ne respecte les
contraintes, et `deja_optimal` si la configuration initiale est déjà la meilleure.

**Évaluations** : les items « bras » et « avant-bras » de la grille RULA sont **isolés et ne
forment pas un score RULA**. ISO 11226 n'est appliquée qu'à l'étape 1 de l'élévation du bras. Le
RULA complet est déclaré non calculable, avec la liste des données manquantes, et REBA est prévu.
Le registre `EVALUATORS` permet d'en ajouter.

## Résultats (simulation, configuration initiale supposée H 130 cm · A 15° · D 45 cm)

| Profil | Réglage optimal (H · A · D) | J initial → optimal | Points avec épaule > 45° |
|---|---|---|---|
| P5 femme (150,5 cm) | 106,5 cm · 13,8° · 34,2 cm | 3,245 → 1,139 | 85 % → 17 % |
| P50 femme (161 cm) | 115,7 cm · 7,0° · 37,8 cm | 1,861 → 1,022 | 63 % → 15 % |
| P95 femme (171 cm) | 126,0 cm · 0,0° · 39,5 cm | 1,102 → 0,938 | 37 % → 15 % |
| P95 homme (185,5 cm) | 139,2 cm · 0,0° · 42,0 cm | 0,886 → 0,824 | 15 % → 15 % |

Ces pourcentages sont des parts pondérées des points du gabarit, pas des temps mesurés. Les 15 %
résiduels correspondent à la rangée du haut du gabarit (70 cm de haut), toujours au-dessus des
épaules : il faut y placer les connecteurs les moins utilisés. Pour P5 et P50, la configuration
initiale supposée laisse des points hors d'atteinte : elle viole une contrainte. Pour P50, le
regard passe de 30° à 50° sous l'horizontale : c'est le prix de l'abaissement du gabarit, et il est
signalé.

## Ce qui est réel, simulé ou futur

| Fonctionnalité | Statut |
|---|---|
| Moteur de calcul (validation, évaluation, optimisation, rapport) | **opérationnel**, testé |
| API FastAPI et gestion des erreurs | **opérationnelle**, testée |
| Exécution du même moteur dans le navigateur (Pyodide) | **opérationnelle**, testée hors ligne |
| Profils P5 / P50 / P95 et profil personnalisé | **opérationnels** (valeurs de référence britanniques) |
| Webcam + MediaPipe dans le navigateur, squelette et angles 2D en direct | **implémenté** ; traitement serveur testé sur des points synthétiques, pas encore sur une vraie webcam |
| Mesures webcam | **estimation 2D non calibrée** : échelle par la stature déclarée, sommet du crâne estimé |
| RealSense 3D et ArUco (côté serveur) | **implémentés, non testés** : matériel requis, sinon réponse 503 explicite |
| Gabarit, vérins, déplacements | **simulés** (vitesses limites réalistes) |
| Commandes ESP32 | **simulées** (trames exactes, réponses datées) |
| Firmware ESP32 v2 | **logique testée sur PC** (17 cas) ; jamais exécuté sur carte |
| Sécurité machine | **future** : chaîne de sécurité câblée (ISO 13849-1) à concevoir ; le firmware n'en est pas une |
| RULA complet, REBA, EN 1005-4 | **futurs** (données de posture complète, force, fréquence nécessaires) |

## Limites techniques restantes

- Le tronc est vertical et immobile, et le bras utilisé est le plus proche du point : le travail
  bimanuel réel et la flexion du tronc ne sont pas modélisés.
- La répartition des tâches sur le gabarit est une hypothèse ; elle doit venir de la carte
  d'activité mesurée par le module vision ErgoGuard.
- La configuration initiale (130 cm, 15°, 45 cm) est une hypothèse à relever sur le poste.
- Webcam : erreur typique de ±2 à 4 cm, sensible à la perspective (caméra à hauteur de taille, à
  2,5–3 m, opératrice de face). Elle convient au tri, pas à une mesure de référence.
- MediaPipe ≥ 0.10.30 (côté serveur) n'a plus l'API `solutions` : il faut fournir le modèle
  `pose_landmarker_*.task` dans la variable d'environnement `ERGO_POSE_MODEL`.
- Page autonome : nécessite le réseau pour charger Pyodide (jsDelivr). L'accès à la caméra y est
  bloqué par le cadre d'aperçu : utilisez le serveur local pour la webcam.
- Le firmware est écrit pour le cœur Arduino-ESP32 2.x (adapter `ledc*` et `esp_task_wdt_init` en 3.x).

## Confidentialité

Aucune image n'est enregistrée ni transmise. La caméra ne démarre qu'après un consentement
explicite. Seules les coordonnées des points articulaires sont envoyées au moteur, puis oubliées
après le calcul.
