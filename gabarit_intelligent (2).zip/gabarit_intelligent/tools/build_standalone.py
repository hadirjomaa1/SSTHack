"""
Génère une page autonome (un seul fichier HTML) du jumeau numérique :
  - CSS et JS du dossier frontend/ insérés dans la page ;
  - fichiers Python du moteur (backend/*.py + profiles.json) embarqués TELS QUELS et exécutés
    dans le navigateur par Pyodide quand aucun serveur n'est disponible.
Aucun algorithme n'est réécrit : c'est le même code Python que l'API.

Usage : python tools/build_standalone.py   ->  dist/gabarit_3d_standalone.html
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FRONT, BACK, DIST = ROOT / "frontend", ROOT / "backend", ROOT / "dist"
PY_FILES = ["smart_jig.py", "ergonomics.py", "optimizer.py", "camera_measure.py", "firmware_protocol.py", "service.py", "profiles.json"]


def main():
    html = (FRONT / "gabarit_3d.html").read_text(encoding="utf-8")
    css = (FRONT / "css/style.css").read_text(encoding="utf-8")
    html = html.replace('<link rel="stylesheet" href="css/style.css">', f"<style>\n{css}\n</style>")
    sources = {n: (BACK / n).read_text(encoding="utf-8") for n in PY_FILES}
    payload = json.dumps(sources, ensure_ascii=False).replace("</", "<\\/")
    inject = f"<script>window.EG_PY_SOURCES = {payload};</script>\n"

    def inline_js(m):
        js = (FRONT / m.group(1)).read_text(encoding="utf-8").replace("</script", "<\\/script")
        return f"<script>\n{js}\n</script>"

    html = html.replace('<script src="js/engine.js"></script>', inject + '<script src="js/engine.js"></script>', 1)
    html = re.sub(r'<script src="(js/[a-z_]+\.js)"></script>', inline_js, html)
    DIST.mkdir(exist_ok=True)
    out = DIST / "gabarit_3d_standalone.html"
    out.write_text(html, encoding="utf-8")
    print(f"{out} ({out.stat().st_size // 1024} Ko)")


if __name__ == "__main__":
    main()
