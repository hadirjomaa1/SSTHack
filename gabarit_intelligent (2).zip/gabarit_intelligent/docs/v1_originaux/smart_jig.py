"""
ErgoGuard AI – Gabarit intelligent auto-réglable (poste 3.2 Montage faisceaux, LEONI)
====================================================================================

Chaîne complète :
  1. MESURE   : caméra (MediaPipe Pose) -> stature, hauteur yeux / épaule / coude,
                longueurs bras et avant-bras de l'opératrice, en mètres.
                - mode "realsense" : caméra de profondeur Intel RealSense D435 (précis, ±1 cm)
                - mode "aruco"     : webcam + marqueur ArUco de 15 cm posé au plan de l'opératrice
                - mode "simulate"  : sans caméra, à partir d'une stature saisie (tables
                                     anthropométriques de Drillis & Contini)
  2. OPTIMISATION : recherche de la position 3D du gabarit (hauteur du centre, inclinaison,
                distance) qui minimise l'élévation des épaules, la sur-extension des bras et la
                flexion du cou sur toute la zone de travail du gabarit.
  3. COMMANDE : envoi de la consigne à l'automate ESP32 (3 vérins) par liaison série,
                uniquement quand les mains sont hors du gabarit (sécurité).
  4. PROFIL   : la position optimale est mémorisée par matricule (OP-014…) : au prochain
                badge, le gabarit se règle sans nouveau scan.

Usage :
  python smart_jig.py --simulate 158            # calcul pour une opératrice de 158 cm
  python smart_jig.py --compare                 # tableau P5 / P50 / P95 vs gabarit fixe
  python smart_jig.py --mode aruco --op OP-014 --port /dev/ttyUSB0
  python smart_jig.py --mode realsense --op OP-014 --port COM4

Dépendances : numpy ; pour la caméra : opencv-contrib-python, mediapipe ;
              pour la profondeur : pyrealsense2 ; pour la commande : pyserial.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path

import numpy as np

# --------------------------------------------------------------------------------------
# 0. Paramètres du poste et des actionneurs
# --------------------------------------------------------------------------------------
BOARD_SLOPE_LEN = 0.70      # m, hauteur utile du gabarit le long de la pente
WORK_HALF_WIDTH = 0.35      # m, demi-largeur de la zone couverte par l'opératrice
LIMITS = {
    "h": (0.85, 1.45),      # m, hauteur du centre du gabarit (2 colonnes élévatrices, course 600 mm)
    "a": (0.0, 40.0),       # °, inclinaison par rapport à la verticale (vérin d'inclinaison)
    "d": (0.30, 0.55),      # m, distance horizontale épaule -> centre du gabarit (rail, course 250 mm)
}
SPEED = {"h": 0.030, "a": 3.0, "d": 0.025}   # m/s, °/s, m/s : vitesses limitées (sécurité)
# Gabarit fixe actuel (référence "avant") : réglé une fois pour toute la ligne
FIXED = {"h": 1.30, "a": 15.0, "d": 0.45}   # calé sur la mesure terrain : bras > 45° ≈ 55 % du temps (158 cm)

PROFILES_FILE = Path(__file__).with_name("profils_gabarit.json")


# --------------------------------------------------------------------------------------
# 1. Anthropométrie
# --------------------------------------------------------------------------------------
@dataclass
class Body:
    stature: float          # m
    eye_h: float            # hauteur des yeux (debout)
    shoulder_h: float       # hauteur acromion
    elbow_h: float          # hauteur coude, bras le long du corps
    upper_arm: float        # épaule -> coude
    forearm_grip: float     # coude -> centre de préhension
    shoulder_half: float    # demi-largeur d'épaules
    source: str = "ratios"

    @staticmethod
    def from_stature(h: float, source: str = "ratios") -> "Body":
        # Coefficients segmentaires de Drillis & Contini (1966)
        return Body(
            stature=h, eye_h=0.936 * h, shoulder_h=0.818 * h, elbow_h=0.630 * h,
            upper_arm=0.186 * h, forearm_grip=0.146 * h + 0.054 * h,
            shoulder_half=0.129 * h, source=source,
        )


# --------------------------------------------------------------------------------------
# 2. Modèle biomécanique et fonction de coût
# --------------------------------------------------------------------------------------
def _work_points(h: float, a_deg: float, d: float, ns: int = 7, nl: int = 5):
    """Points de la zone de travail du gabarit (repère : x latéral, y vertical, z avant)
    avec un poids gaussien : l'encliquetage se concentre au centre."""
    a = math.radians(a_deg)
    s = np.linspace(-BOARD_SLOPE_LEN / 2, BOARD_SLOPE_LEN / 2, ns)
    l = np.linspace(-WORK_HALF_WIDTH, WORK_HALF_WIDTH, nl)
    S, L = np.meshgrid(s, l, indexing="ij")
    pts = np.stack([L, h + S * math.cos(a), d + S * math.sin(a)], axis=-1).reshape(-1, 3)
    w = np.exp(-(S / 0.25) ** 2 - (L / 0.25) ** 2).reshape(-1)
    return pts, w / w.sum()


def arm_ik(body: Body, target: np.ndarray, side: int = 1):
    """IK 2 segments, coude au plus bas. Retourne (élévation épaule en °, ratio d'allonge)."""
    sh = np.array([side * body.shoulder_half, body.shoulder_h, 0.0])
    v = target - sh
    r = float(np.linalg.norm(v))
    lu, lf = body.upper_arm, body.forearm_grip
    u = v / r
    reach_ratio = r / (lu + lf)
    if r >= lu + lf:                         # hors d'atteinte : bras tendu
        upper = u
    else:
        r_ = max(r, abs(lu - lf) + 1e-3)
        beta = math.acos(np.clip((lu**2 + r_**2 - lf**2) / (2 * lu * r_), -1, 1))
        down = np.array([0.0, -1.0, 0.0])
        perp = down - np.dot(down, u) * u
        n = np.linalg.norm(perp)
        perp = perp / n if n > 1e-6 else np.array([0.0, 0.0, -1.0])
        upper = math.cos(beta) * u + math.sin(beta) * perp
    elev = math.degrees(math.acos(np.clip(-upper[1], -1, 1)))
    return elev, reach_ratio


def evaluate(body: Body, h: float, a: float, d: float) -> dict:
    pts, w = _work_points(h, a, d)
    elevs, costs, reaches = [], [], []
    for p, wi in zip(pts, w):
        side = 1 if p[0] >= 0 else -1                 # bras le plus proche
        e, rr = arm_ik(body, p, side)
        c = 0.0
        if e > 20: c += (min(e, 45) - 20) / 25         # RULA bras 2
        if e > 45: c += 1 + 2 * (min(e, 90) - 45) / 45 # RULA bras 3
        if e > 90: c += 3 + (e - 90) / 30              # RULA bras 4
        if rr > 0.85: c += 2 * (rr - 0.85) / 0.15      # sur-extension -> buste penché
        if rr < 0.45: c += 1.5 * (0.45 - rr) / 0.45    # trop près -> coudes écartés, poignets cassés
        elevs.append(e); costs.append(c); reaches.append(rr)
    elevs = np.array(elevs)
    # Regard vers le centre du gabarit (idéal 15–35° sous l'horizontale)
    gaze = math.degrees(math.atan2(body.eye_h - h, d + 0.08))
    neck = 0.0
    if gaze < 15: neck = (15 - gaze) / 15
    if gaze > 35: neck = (gaze - 35) / 15
    cost = float(np.dot(w, costs)) + 0.5 * neck
    rula = np.where(elevs > 90, 4, np.where(elevs > 45, 3, np.where(elevs > 20, 2, 1)))
    return {
        "cost": round(cost, 4),
        "elev_moy": round(float(np.dot(w, elevs)), 1),
        "elev_max": round(float(elevs.max()), 1),
        "pct_bras_sup45": round(100 * float(np.dot(w, elevs > 45)), 1),
        "rula_bras_moy": round(float(np.dot(w, rula)), 2),
        "allonge_max": round(float(max(reaches)), 2),
        "regard": round(gaze, 1),
    }


def optimise(body: Body) -> dict:
    """Recherche grossière puis fine sur les 3 axes motorisés."""
    def grid(hr, ar, dr):
        best = None
        for h in hr:
            for a in ar:
                for d in dr:
                    r = evaluate(body, h, a, d)
                    if best is None or r["cost"] < best[1]["cost"]:
                        best = ((h, a, d), r)
        return best

    (h, a, d), _ = grid(np.arange(*LIMITS["h"], 0.05), np.arange(0, 41, 5), np.arange(0.30, 0.56, 0.05))
    clip = lambda x, lo, hi: np.clip(x, lo, hi)
    (h, a, d), res = grid(
        clip(np.arange(h - 0.05, h + 0.051, 0.01), *LIMITS["h"]),
        clip(np.arange(a - 5, a + 5.1, 1), *LIMITS["a"]),
        clip(np.arange(d - 0.05, d + 0.051, 0.01), *LIMITS["d"]),
    )
    return {"h": round(float(h), 3), "a": round(float(a), 1), "d": round(float(d), 3), **res}


def move_time(src: dict, dst: dict) -> float:
    return max(abs(dst[k] - src[k]) / SPEED[k] for k in ("h", "a", "d"))


# --------------------------------------------------------------------------------------
# 3. Mesure par caméra
# --------------------------------------------------------------------------------------
class CameraMeasure:
    """Mesure l'opératrice debout, bras le long du corps, face caméra, pendant ~3 s.
    Médiane sur les images valides -> robuste aux occultations par le faisceau."""

    LM = dict(nose=0, l_eye=2, r_eye=5, l_sh=11, r_sh=12, l_el=13, r_el=14,
              l_wr=15, r_wr=16, l_heel=29, r_heel=30)

    def __init__(self, mode: str = "aruco", marker_m: float = 0.15, cam_index: int = 0):
        import cv2, mediapipe as mp  # noqa: import tardif (inutile en simulation)
        self.cv2, self.mode, self.marker_m = cv2, mode, marker_m
        self.pose = mp.solutions.pose.Pose(model_complexity=2, min_detection_confidence=0.6)
        if mode == "realsense":
            import pyrealsense2 as rs
            self.rs = rs
            self.pipe = rs.pipeline()
            cfg = rs.config()
            cfg.enable_stream(rs.stream.color, 1280, 720, rs.format.bgr8, 30)
            cfg.enable_stream(rs.stream.depth, 1280, 720, rs.format.z16, 30)
            prof = self.pipe.start(cfg)
            self.align = rs.align(rs.stream.color)
            self.intr = prof.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
        else:
            self.cap = cv2.VideoCapture(cam_index)
            self.dico = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
            self.det = cv2.aruco.ArucoDetector(self.dico)

    # -- une image -> points 3D (m) des repères utiles
    def _frame_points(self):
        cv2 = self.cv2
        if self.mode == "realsense":
            fr = self.align.process(self.pipe.wait_for_frames())
            color, depth = fr.get_color_frame(), fr.get_depth_frame()
            img = np.asanyarray(color.get_data())
        else:
            ok, img = self.cap.read()
            if not ok:
                return None
        hgt, wid = img.shape[:2]
        res = self.pose.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        if not res.pose_landmarks:
            return None
        lms = res.pose_landmarks.landmark
        if min(lms[i].visibility for i in self.LM.values()) < 0.5:
            return None
        px = {k: (lms[i].x * wid, lms[i].y * hgt) for k, i in self.LM.items()}
        if self.mode == "realsense":
            pts = {}
            for k, (u, v) in px.items():
                u, v = int(np.clip(u, 0, wid - 1)), int(np.clip(v, 0, hgt - 1))
                z = depth.get_distance(u, v)
                if z <= 0:
                    return None
                x, y, zz = self.rs.rs2_deproject_pixel_to_point(self.intr, [u, v], z)
                pts[k] = np.array([x, -y, zz])           # y vers le haut
            return pts
        # ArUco : échelle m/pixel donnée par le marqueur posé au plan de l'opératrice
        corners, ids, _ = self.det.detectMarkers(img)
        if ids is None:
            return None
        side_px = np.mean([np.linalg.norm(corners[0][0][i] - corners[0][0][(i + 1) % 4]) for i in range(4)])
        k = self.marker_m / side_px
        return {n: np.array([u * k, -v * k, 0.0]) for n, (u, v) in px.items()}

    def measure(self, seconds: float = 3.0) -> Body:
        samples, t0 = [], time.time()
        while time.time() - t0 < seconds:
            p = self._frame_points()
            if p is None:
                continue
            floor = (p["l_heel"][1] + p["r_heel"][1]) / 2 - 0.02   # talon ≈ 2 cm au-dessus du sol
            eye = (p["l_eye"][1] + p["r_eye"][1]) / 2 - floor
            sh = (p["l_sh"][1] + p["r_sh"][1]) / 2 - floor
            el = (p["l_el"][1] + p["r_el"][1]) / 2 - floor
            ua = np.mean([np.linalg.norm(p["l_sh"] - p["l_el"]), np.linalg.norm(p["r_sh"] - p["r_el"])])
            fa = np.mean([np.linalg.norm(p["l_el"] - p["l_wr"]), np.linalg.norm(p["r_el"] - p["r_wr"])])
            half = np.linalg.norm(p["l_sh"] - p["r_sh"]) / 2
            samples.append([eye / 0.936, eye, sh, el, ua, fa + 0.054 * eye / 0.936, half])
        if len(samples) < 10:
            raise RuntimeError("Mesure impossible : opératrice non visible en entier (pieds à tête).")
        m = np.median(np.array(samples), axis=0)
        return Body(*[round(float(x), 3) for x in m], source=self.mode)


# --------------------------------------------------------------------------------------
# 4. Commande des actionneurs (ESP32, protocole texte)
# --------------------------------------------------------------------------------------
class JigController:
    def __init__(self, port: str | None):
        self.ser = None
        if port:
            import serial
            self.ser = serial.Serial(port, 115200, timeout=1)
            time.sleep(2)

    def move(self, target: dict, timeout: float = 60) -> bool:
        cmd = f"MOVE H={int(target['h']*1000)} A={int(target['a']*10)} D={int(target['d']*1000)}\n"
        if not self.ser:
            print(f"[simulation] -> ESP32 : {cmd.strip()}")
            return True
        self.ser.write(cmd.encode())
        t0 = time.time()
        while time.time() - t0 < timeout:
            line = self.ser.readline().decode(errors="ignore").strip()
            if line.startswith("DONE"):
                return True
            if line.startswith(("FAULT", "ESTOP", "PINCH", "ZONE", "ERR")):
                print(f"Arrêt sécurité : {line}")
                return False
        return False


# --------------------------------------------------------------------------------------
# 5. Profils par opératrice
# --------------------------------------------------------------------------------------
def load_profiles() -> dict:
    try:
        return json.loads(PROFILES_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}


def save_profile(op: str, body: Body, best: dict):
    prof = load_profiles()
    prof[op] = {"body": asdict(body), "reglage": {k: best[k] for k in ("h", "a", "d")},
                "date": time.strftime("%Y-%m-%d %H:%M")}
    PROFILES_FILE.write_text(json.dumps(prof, indent=2, ensure_ascii=False), encoding="utf-8")


# --------------------------------------------------------------------------------------
# 6. Programme principal
# --------------------------------------------------------------------------------------
def report(body: Body, best: dict):
    fixed = evaluate(body, **FIXED)
    print(f"\nOpératrice : {body.stature*100:.0f} cm (source : {body.source})  "
          f"épaule {body.shoulder_h*100:.0f} cm · coude {body.elbow_h*100:.0f} cm · yeux {body.eye_h*100:.0f} cm")
    print(f"Réglage optimal : centre {best['h']*100:.0f} cm · inclinaison {best['a']:.0f}° · distance {best['d']*100:.0f} cm"
          f"  (déplacement {move_time(FIXED, best):.0f} s)")
    print(f"{'':24}{'gabarit fixe':>14}{'gabarit auto':>14}")
    for k, lab in [("pct_bras_sup45", "% temps bras > 45°"), ("elev_moy", "élévation épaule moy."),
                   ("elev_max", "élévation épaule max"), ("rula_bras_moy", "score RULA bras"),
                   ("allonge_max", "allonge max (ratio)"), ("regard", "angle du regard °")]:
        print(f"{lab:24}{fixed[k]:>14}{best[k]:>14}")


def main():
    ap = argparse.ArgumentParser(description="Gabarit intelligent ErgoGuard AI")
    ap.add_argument("--mode", choices=["simulate", "aruco", "realsense"], default="simulate")
    ap.add_argument("--simulate", type=float, help="stature en cm (mode simulation)")
    ap.add_argument("--op", default="OP-014", help="matricule de l'opératrice")
    ap.add_argument("--port", help="port série de l'ESP32 (ex. /dev/ttyUSB0, COM4)")
    ap.add_argument("--rescan", action="store_true", help="ignorer le profil mémorisé")
    ap.add_argument("--compare", action="store_true", help="tableau P5 / P50 / P95")
    a = ap.parse_args()

    if a.compare:
        print(f"{'stature':>8}{'h cm':>7}{'incl.':>7}{'d cm':>7}{'>45° fixe':>11}{'>45° auto':>11}{'RULA fixe':>11}{'RULA auto':>11}")
        for s in (150, 155, 158, 162, 168, 175, 185):
            b = Body.from_stature(s / 100)
            o, f = optimise(b), evaluate(b, **FIXED)
            print(f"{s:>8}{o['h']*100:>7.0f}{o['a']:>7.0f}{o['d']*100:>7.0f}"
                  f"{f['pct_bras_sup45']:>10.0f}%{o['pct_bras_sup45']:>10.0f}%{f['rula_bras_moy']:>11}{o['rula_bras_moy']:>11}")
        return

    prof = load_profiles()
    ctrl = JigController(a.port)
    if a.op in prof and not a.rescan and a.mode != "simulate":
        best = prof[a.op]["reglage"]
        print(f"Profil {a.op} trouvé ({prof[a.op]['date']}) : réglage immédiat.")
        ctrl.move(best)
        return

    if a.mode == "simulate":
        body = Body.from_stature((a.simulate or 158) / 100)
    else:
        print("Placez-vous face à la caméra, bras le long du corps… (3 s)")
        body = CameraMeasure(a.mode).measure()
    best = optimise(body)
    report(body, best)
    if a.mode != "simulate":
        save_profile(a.op, body, best)
    if ctrl.move(best):
        print("Gabarit réglé et verrouillé.")


if __name__ == "__main__":
    main()
