/*
 * ErgoGuard AI – Gabarit intelligent : firmware ESP32 (3 axes)
 * ------------------------------------------------------------
 * Axe H : 2 colonnes élévatrices synchronisées (hauteur du centre, 850–1450 mm)
 * Axe A : vérin d'inclinaison (0–40°)
 * Axe D : vérin sur rail (distance épaule–gabarit, 300–550 mm)
 *
 * Matériel par axe : vérin 24 V à potentiomètre de recopie, pont en H BTS7960
 * (RPWM / LPWM + sortie IS de mesure de courant).
 * Sécurité : arrêt d'urgence NC (câblé aussi en coupure de puissance), barrière
 * immatérielle « mains hors zone », anti-pincement par surintensité, timeout,
 * fins de course logiciels, vitesse limitée, rampe.
 *
 * Protocole série 115200 bauds (envoyé par smart_jig.py) :
 *   MOVE H=1210 A=20 D=300   -> hauteur mm, angle en dixièmes de degré, distance mm
 *   STOP | STATUS
 * Réponses : OK, DONE H=.. A=.. D=.., PINCH <axe>, ESTOP, ZONE (mains dans la zone),
 *            FAULT <axe> TIMEOUT, ERR <message>
 */

#include <Arduino.h>   // cœur ESP32 Arduino 2.x (ledcSetup). En 3.x : ledcAttach(pin, freq, bits).

struct Axis {
  const char* name;
  uint8_t pinR, pinL, pinPot, pinCur;     // pont en H + recopie + courant
  uint8_t chR, chL;                       // canaux LEDC (PWM)
  float minU, maxU;                       // course en unités (mm ou 0,1°)
  int adcMin, adcMax;                     // calibration du potentiomètre
  float pinchAmp;                         // seuil anti-pincement (A)
  float target, pos;
  bool active;
  int pwm;                                // PWM courante (rampe)
};

// ---- Brochage (à adapter au câblage réel) ---------------------------------------
Axis axes[3] = {
  {"H", 25, 26, 34, 35, 0, 1,  850, 1450, 310, 3790, 6.0, 0, 0, false, 0},
  {"A", 27, 14, 32, 33, 2, 3,    0,  400, 280, 3820, 3.0, 0, 0, false, 0},
  {"D", 18, 19, 36, 39, 4, 5,  300,  550, 300, 3800, 3.0, 0, 0, false, 0},
};
const uint8_t PIN_ESTOP = 4;      // NC vers GND : HIGH = arrêt d'urgence enclenché
const uint8_t PIN_ZONE  = 16;     // barrière immatérielle : LOW = main détectée dans la zone
const uint8_t PIN_LED   = 2;      // voyant « mouvement en cours »

const int   PWM_MAX     = 200;    // ~78 % : vitesse volontairement limitée
const int   PWM_MIN     = 70;
const int   RAMP_STEP   = 6;      // par cycle de 10 ms
const float DEADBAND[3] = {2.0, 3.0, 2.0};    // mm, 0,1°, mm
const uint32_t TIMEOUT_MS = 45000;

uint32_t moveStart = 0;
bool moving = false;
String rx;

// ---- Utilitaires -------------------------------------------------------------------
float readPos(Axis& a) {
  long s = 0;
  for (int i = 0; i < 8; i++) s += analogRead(a.pinPot);
  float adc = s / 8.0;
  return a.minU + (adc - a.adcMin) * (a.maxU - a.minU) / float(a.adcMax - a.adcMin);
}
float readAmp(Axis& a) {
  // BTS7960 : IS ≈ I / 8500 sur une résistance de 1 kΩ -> V = I * 1000 / 8500
  float v = analogRead(a.pinCur) * 3.3 / 4095.0;
  return v * 8.5;
}
void drive(Axis& a, int pwm) {   // pwm signé
  ledcWrite(a.chR, pwm > 0 ? pwm : 0);
  ledcWrite(a.chL, pwm < 0 ? -pwm : 0);
}
void stopAll() {
  for (auto& a : axes) { drive(a, 0); a.active = false; a.pwm = 0; }
  moving = false;
  digitalWrite(PIN_LED, LOW);
}
void report(const char* head) {
  Serial.printf("%s H=%.0f A=%.0f D=%.0f\n", head, axes[0].pos, axes[1].pos, axes[2].pos);
}

// ---- Commandes ---------------------------------------------------------------------
void startMove(float h, float a, float d) {
  float t[3] = {h, a, d};
  for (int i = 0; i < 3; i++) {
    if (t[i] < axes[i].minU || t[i] > axes[i].maxU) {
      Serial.printf("ERR %s hors course\n", axes[i].name); return;
    }
  }
  if (digitalRead(PIN_ESTOP) == HIGH) { Serial.println("ESTOP"); return; }
  if (digitalRead(PIN_ZONE) == LOW)   { Serial.println("ZONE");  return; }
  for (int i = 0; i < 3; i++) { axes[i].target = t[i]; axes[i].active = true; axes[i].pwm = 0; }
  moving = true; moveStart = millis();
  digitalWrite(PIN_LED, HIGH);
  Serial.println("OK");
}

void parse(const String& line) {
  if (line.startsWith("MOVE")) {
    float h = NAN, a = NAN, d = NAN;
    int ih = line.indexOf("H="), ia = line.indexOf("A="), id = line.indexOf("D=");
    if (ih > 0) h = line.substring(ih + 2).toFloat();
    if (ia > 0) a = line.substring(ia + 2).toFloat();
    if (id > 0) d = line.substring(id + 2).toFloat();
    if (isnan(h) || isnan(a) || isnan(d)) { Serial.println("ERR syntaxe"); return; }
    startMove(h, a, d);
  } else if (line == "STOP") { stopAll(); report("STOPPED"); }
  else if (line == "STATUS") { report(moving ? "MOVING" : "IDLE"); }
  else Serial.println("ERR commande inconnue");
}

// ---- Boucle de régulation (10 ms) --------------------------------------------------
void control() {
  for (auto& a : axes) a.pos = readPos(a);
  if (!moving) return;

  if (digitalRead(PIN_ESTOP) == HIGH) { stopAll(); Serial.println("ESTOP"); return; }
  if (digitalRead(PIN_ZONE) == LOW)   { stopAll(); Serial.println("ZONE");  return; }
  if (millis() - moveStart > TIMEOUT_MS) {
    for (auto& a : axes) if (a.active) { stopAll(); Serial.printf("FAULT %s TIMEOUT\n", a.name); return; }
  }

  bool any = false;
  for (int i = 0; i < 3; i++) {
    Axis& a = axes[i];
    if (!a.active) continue;
    float err = a.target - a.pos;
    if (fabs(err) <= DEADBAND[i]) { drive(a, 0); a.active = false; a.pwm = 0; continue; }
    any = true;
    // anti-pincement : surintensité après la phase de démarrage (pic d'appel ignoré 300 ms)
    if (millis() - moveStart > 300 && readAmp(a) > a.pinchAmp) {
      int back = err > 0 ? -PWM_MIN : PWM_MIN;       // recul bref pour libérer
      drive(a, back); delay(400);
      stopAll(); Serial.printf("PINCH %s\n", a.name); return;
    }
    // rampe + ralentissement à l'approche de la consigne
    int want = constrain(int(fabs(err) * 4), PWM_MIN, PWM_MAX);
    a.pwm = min(want, abs(a.pwm) + RAMP_STEP);
    drive(a, err > 0 ? a.pwm : -a.pwm);
  }
  if (!any) { stopAll(); report("DONE"); }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_ESTOP, INPUT_PULLUP);
  pinMode(PIN_ZONE, INPUT_PULLUP);
  pinMode(PIN_LED, OUTPUT);
  analogReadResolution(12);
  for (auto& a : axes) {
    ledcSetup(a.chR, 20000, 8); ledcAttachPin(a.pinR, a.chR);
    ledcSetup(a.chL, 20000, 8); ledcAttachPin(a.pinL, a.chL);
    drive(a, 0);
  }
  Serial.println("ErgoGuard gabarit pret");
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { rx.trim(); if (rx.length()) parse(rx); rx = ""; }
    else if (rx.length() < 64) rx += c;
  }
  static uint32_t t = 0;
  if (millis() - t >= 10) { t = millis(); control(); }
}
