# Audit du module Smart Jig v1 (phase 1) et architecture cible (phase 2)

Fichiers audités (copie intégrale conservée dans `docs/v1_originaux/`) :
`smart_jig.py` (365 lignes), `gabarit_3d.html` (≈ 640 lignes), `firmware_gabarit_esp32.ino` (165 lignes).

## 1. Défauts identifiés

Gravité : **C** = critique (fausse information ou risque), **M** = majeur (résultat discutable), **m** = mineur.

### gabarit_3d.html

| # | Gravité | Défaut | Correction v2 |
|---|---|---|---|
| H1 | C | Le « scan caméra » fabrique des mesures avec `Math.random()` (bruit ±0,4 cm) et les affiche comme provenant d'une « RealSense D435 ». Ce sont des valeurs inventées présentées comme des mesures. | Plus aucune mesure simulée n'est présentée comme une mesure réelle. Le mode simulation affiche « profil de référence », la webcam affiche « estimation 2D ». |
| H2 | C | Le profil « OP-014 · Mme H.A. 158 cm » invente une stature : le cahier des charges ne donne pas la taille de Mme H.A. | Profil supprimé. Seuls restent des profils documentés (Bodyspace) et un profil personnalisé. |
| H3 | M | L'algorithme d'optimisation est dupliqué en JavaScript : deux sources de vérité qui divergent déjà (inclinaison 2° en JS et 0° en Python pour 158 cm, à cause d'égalités départagées différemment). | Tout calcul (évaluation, optimisation, postures des bras, acquisition) est fait en Python. Le JavaScript ne fait qu'afficher. |
| H4 | M | Le libellé « Score RULA bras (1–4) » laisse croire à un score RULA ; il s'agit du seul item « bras » de la grille. | Renommé « item bras de la grille RULA (isolé) ». Le RULA complet est déclaré non calculable, avec la liste des données manquantes. |
| H5 | M | « Temps bras > 45° » : c'est une part pondérée de points du gabarit (hypothèse de répartition des tâches), pas un temps mesuré. | Renommé « part pondérée des points de travail ». L'hypothèse est affichée. |
| H6 | M | Allonge affichée à 110 % sans alerte : des points du gabarit fixe sont hors d'atteinte. | Contrainte « tous les points atteignables » vérifiée et signalée. |
| H7 | m | Pas de vue de face, pas de zoom par boutons, pas d'angle du coude, pas de comparaison des deux mannequins. | Ajoutés. |
| H8 | m | Décor (clous, fils) et mouvements des mains tirés au hasard à chaque chargement. | Décor déterministe (générateur à graine fixe) ; séquence de travail fixe. |

### smart_jig.py

| # | Gravité | Défaut | Correction v2 |
|---|---|---|---|
| P1 | C | `CameraMeasure.measure()` calcule la stature par `eye / 0.936` et l'allonge de main par `0.054 × stature` : des dimensions déduites de ratios sont mélangées aux mesures sans le signaler. | Chaque dimension porte son origine (`mesurée`, `estimée`, `hypothèse`). L'hypothèse tête (vertex) est documentée et chiffrée. |
| P2 | C | Aucune validation des mesures : une détection partielle ou incohérente passe directement à l'optimisation. | `validate_body()` : bornes, ordre anatomique, ratios, cohérence épaule-coude ; `process_frames()` : taux de détection, visibilité, posture de référence, symétrie, stabilité, valeurs aberrantes (MAD). Optimisation refusée si erreur. |
| P3 | M | Mode ArUco : les longueurs sont 2D (z = 0), l'échelle n'est valable qu'au plan du marqueur ; rien ne le signale. | Source `aruco_2d` distincte, avertissement d'incertitude ; RealSense seule source `mesure_3d_calibree`. |
| P4 | M | Optimisation : grille fixe sans critère de convergence, sans contrainte géométrique (bord bas du gabarit qui entre dans le corps, points hors d'atteinte), poids non configurables, aucun terme de déplacement. | `optimizer.py` : fonction J = w1·Jépaule + w2·Jallonge + w3·Jcou + w4·Jdéplacement, poids configurables, contraintes mécaniques et géométriques, recherche par motifs multi-départs avec convergence, gestion de l'infaisable, comparaison avec la configuration initiale. |
| P5 | M | `FIXED` (gabarit « actuel ») est une hypothèse calée a posteriori, présentée comme une donnée. | Devient « configuration initiale », modifiable dans l'interface et dans l'API, marquée « à relever sur le poste ». |
| P6 | m | Angle du coude non calculé. Regard calculé avec un décalage œil fixe non documenté. | Angle du coude calculé ; décalage œil-épaule documenté comme hypothèse. |
| P7 | m | Dépendance numpy pour des calculs scalaires : empêche l'exécution du même code dans le navigateur (Pyodide). | Cœur de calcul en Python pur (module `math`) ; numpy n'est utilisé que pour la caméra. |

### firmware_gabarit_esp32.ino

| # | Gravité | Défaut | Correction v2 |
|---|---|---|---|
| F1 | C | `toFloat()` renvoie 0 sur une valeur illisible : `MOVE H=1200 A=abc D=400` donne A = 0 (valeur dans la course) et le mouvement part. | Analyse stricte (entiers uniquement, champs obligatoires, aucun caractère en trop), identifiant de commande et somme de contrôle. |
| F2 | C | La sécurité repose sur des arrêts logiciels. Un arrêt logiciel ne suffit pas pour une machine réelle. | Documenté : arrêt d'urgence et barrière en chaîne de sécurité câblée (relais de sécurité, coupure de puissance, niveau de performance à déterminer selon ISO 13849-1). Le firmware ne fait que surveiller et signaler. |
| F3 | M | `delay(400)` dans la gestion du pincement bloque la boucle (lecture série et arrêt d'urgence non surveillés pendant 400 ms). | Machine d'états non bloquante (IDLE, MOVING, BACKOFF, FAULT). |
| F4 | M | Un défaut n'est pas mémorisé : une nouvelle commande repart aussitôt après un pincement. | État FAULT verrouillé ; seule la commande `RESET` (hors défaut matériel actif) le lève. |
| F5 | M | Pas de détection de capteur défaillant (potentiomètre coupé ou en court-circuit), pas de détection de blocage (moteur alimenté sans déplacement), pas de surveillance de l'hôte. | Ajoutés : contrôle de plage ADC, détection de calage, battement de cœur de l'hôte, chien de garde matériel. |
| F6 | m | Deux colonnes de hauteur pilotées comme un seul axe sans contrôle de synchronisme. | Recopie de la 2ᵉ colonne et défaut `SYNC` si l'écart dépasse 5 mm. |

## 2. Architecture cible et compatibilité

```
gabarit_intelligent/
├── backend/            moteur Python = source de vérité
│   ├── smart_jig.py        Body, validation, profils, CLI (conservée et étendue)
│   ├── ergonomics.py       modèle biomécanique, indicateurs, évaluateurs (RULA/REBA/ISO 11226 extensibles)
│   ├── optimizer.py        fonction objectif, contraintes, recherche, convergence
│   ├── camera_measure.py   CameraMeasure (RealSense, ArUco) + traitement des points webcam
│   ├── firmware_protocol.py commandes ESP32, contrôleur simulé, contrôleur série
│   ├── service.py          logique des endpoints, partagée par l'API et par le mode navigateur
│   ├── app.py              API FastAPI (+ service du frontend)
│   ├── profiles.json       profils anthropométriques documentés
│   └── requirements.txt
├── frontend/           affichage uniquement (aucun calcul ergonomique)
│   ├── gabarit_3d.html
│   ├── css/style.css
│   └── js/  engine.js · scene.js · camera.js · charts.js · report.js · app.js
├── firmware/firmware_gabarit_esp32.ino
├── tests/              pytest (moteur, acquisition, protocole, API)
├── tools/              build_standalone.py (page autonome Pyodide), check_firmware.sh
├── docs/               AUDIT.md, v1_originaux/
└── README.md
```

Compatibilité :
- La CLI `python smart_jig.py --compare / --simulate / --mode …` est conservée.
- `Body`, `CameraMeasure`, `measure()`, `evaluate()`, `optimise()` gardent leur nom ; `evaluate()` et `optimise()` restent appelables avec les mêmes arguments qu'en v1.
- Le protocole série reste lisible (`MOVE H=… A=… D=…`) avec les mêmes unités (mm, dixièmes de degré, mm) ; s'y ajoutent l'identifiant et la somme de contrôle.
- Le frontend utilise l'API quand elle tourne. Pour la page hébergée sans serveur, `tools/build_standalone.py` embarque les **mêmes fichiers Python** et les exécute dans le navigateur avec Pyodide : aucun algorithme n'est réécrit en JavaScript.
