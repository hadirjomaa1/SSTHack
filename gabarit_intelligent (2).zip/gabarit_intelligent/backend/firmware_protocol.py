"""
ErgoGuard AI – Smart Jig : protocole série ESP32 (v2) et contrôleurs
===================================================================

Trame (ASCII, fin de ligne \\n), somme de contrôle XOR façon NMEA sur tout ce qui précède '*' :
    MOVE H=<mm> A=<dixièmes de degré> D=<mm> ID=<1..65535>*<XX>
    STOP*<XX> · STATUS*<XX> · RESET*<XX> · HB*<XX> (battement de cœur de l'hôte, ≥ 1 / s en mouvement)
Réponses (avec somme de contrôle) : OK ID=n · DONE H= A= D= ID=n · ERR <code> · FAULT <code> <axe> · STATE <état> ...
Défauts verrouillés (RESET) : SENSOR, SYNC, STALL, PINCH, ZONE, HOST_TIMEOUT, TIMEOUT, SAFETY_OPEN.

Unités entières côté firmware (pas de flottants dans la trame) :
    H en mm (850–1450) · A en 0,1° (0–400) · D en mm (300–550).

DÉMONSTRATION ACTUELLE : aucun ESP32 ni vérin n'est connecté. `SimulatedController` produit la
trame exacte qui serait envoyée et une chronologie de réponses SIMULÉES (durées calculées
avec les vitesses limites des axes). `SerialJigController` est prêt pour un banc réel.
"""
from __future__ import annotations

import time

from smart_jig import AXIS_LIMITS, AXIS_SPEED, JigConfig, move_time

FW_LIMITS = {"H": (int(AXIS_LIMITS["h"][0] * 1000), int(AXIS_LIMITS["h"][1] * 1000)),
             "A": (int(AXIS_LIMITS["a"][0] * 10), int(AXIS_LIMITS["a"][1] * 10)),
             "D": (int(AXIS_LIMITS["d"][0] * 1000), int(AXIS_LIMITS["d"][1] * 1000))}


def checksum(body: str) -> str:
    x = 0
    for ch in body:
        x ^= ord(ch)
    return f"{x:02X}"


def frame(body: str) -> str:
    return f"{body}*{checksum(body)}"


def to_units(c: JigConfig) -> dict:
    return {"H": int(round(c.h * 1000)), "A": int(round(c.a * 10)), "D": int(round(c.d * 1000))}


def build_move(c: JigConfig, cmd_id: int) -> str:
    u = to_units(c)
    for k, (lo, hi) in FW_LIMITS.items():
        if not lo <= u[k] <= hi:
            raise ValueError(f"{k}={u[k]} hors limites firmware [{lo}, {hi}]")
    if not 1 <= cmd_id <= 65535:
        raise ValueError("ID de commande hors [1, 65535]")
    return frame(f"MOVE H={u['H']} A={u['A']} D={u['D']} ID={cmd_id}")


def parse_frame(line: str) -> tuple[str, bool]:
    """Vérifie la somme de contrôle d'une trame. Retourne (corps, valide)."""
    if "*" not in line:
        return line, False
    body, cs = line.rsplit("*", 1)
    return body, cs.strip().upper() == checksum(body)


class SimulatedController:
    """Jumeau du firmware : mêmes contrôles de limites, réponses simulées et datées.
    Ne pilote aucun matériel."""
    simulated = True

    def __init__(self):
        self._id = 0

    def plan_move(self, src: JigConfig, dst: JigConfig) -> dict:
        self._id = self._id % 65535 + 1
        cmd = build_move(dst, self._id)
        durations = {k: round(abs(getattr(dst, k) - getattr(src, k)) / AXIS_SPEED[k], 2) for k in "had"}
        total = move_time(src, dst)
        u = to_units(dst)
        events = [{"t": 0.0, "dir": "tx", "line": cmd},
                  {"t": 0.02, "dir": "rx", "line": frame(f"OK ID={self._id}")}]
        t = 1.0
        while t < total:
            events.append({"t": round(t, 2), "dir": "tx", "line": frame("HB")})
            t += 1.0
        events.append({"t": round(total + 0.05, 2), "dir": "rx",
                       "line": frame(f"DONE H={u['H']} A={u['A']} D={u['D']} ID={self._id}")})
        return {"simulated": True, "command": cmd, "units": u, "axis_durations_s": durations,
                "total_s": round(total, 2), "events": events,
                "note": "SIMULATION — aucun ESP32 ni vérin connecté. Durées calculées avec les vitesses limites "
                        f"H {AXIS_SPEED['h']*1000:.0f} mm/s, A {AXIS_SPEED['a']:.0f} °/s, D {AXIS_SPEED['d']*1000:.0f} mm/s."}


class SerialJigController:
    """Contrôleur réel (banc futur) : ESP32 sur port série. Matériel requis."""
    simulated = False

    def __init__(self, port: str, baud: int = 115200):
        try:
            import serial
        except ImportError as e:
            from camera_measure import HardwareUnavailable
            raise HardwareUnavailable("pyserial absent : pip install pyserial") from e
        self.ser = serial.Serial(port, baud, timeout=0.2)
        time.sleep(2)
        self._id = 0

    def _send(self, body: str):
        self.ser.write((frame(body) + "\n").encode())

    def move(self, c: JigConfig, timeout: float = 120) -> bool:
        self._id = self._id % 65535 + 1
        self.ser.write((build_move(c, self._id) + "\n").encode())
        t0, last_hb = time.time(), 0.0
        while time.time() - t0 < timeout:
            if time.time() - last_hb > 0.5:
                self._send("HB"); last_hb = time.time()
            line = self.ser.readline().decode(errors="ignore").strip()
            if line.startswith("DONE") and f"ID={self._id}" in line:
                return True
            if line.startswith(("FAULT", "ERR")):
                print(f"Arrêt : {line}")
                return False
        self._send("STOP")
        return False
