"""
ErgoGuard AI – Smart Jig : noyau anthropométrique et paramètres du poste
=======================================================================

Poste 3.2 Montage faisceaux (LEONI). Ce module contient :
  * `Body`          : morphologie de l'opératrice, chaque dimension avec son origine ;
  * `validate_body` : contrôle des bornes, de l'ordre anatomique et de la cohérence ;
  * `JigConfig`     : réglage des trois axes H (hauteur), A (inclinaison), D (distance) ;
  * les limites mécaniques des axes et la géométrie du gabarit ;
  * le chargement des profils documentés (profiles.json) ;
  * la CLI historique (v1) : --compare, --simulate, --mode aruco|realsense.

Repère utilisé dans tout le moteur (mètres, degrés) :
  x latéral (droite de l'opératrice > 0), y vertical (sol = 0), z vers l'avant
  (vers le gabarit). Origine au sol, à l'aplomb du milieu des articulations des épaules.

Python pur (module math uniquement) : le même code tourne sous CPython (API FastAPI)
et dans le navigateur (Pyodide) — une seule source de vérité pour les calculs.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field, asdict
from pathlib import Path

VERSION = "2.0.0"

# ----------------------------------------------------------------------------------------
# 1. Géométrie du gabarit et limites mécaniques des axes (hypothèses de conception)
# ----------------------------------------------------------------------------------------
BOARD_SLOPE_LEN = 0.70     # m, hauteur utile du gabarit mesurée le long de la pente
BOARD_WIDTH = 1.70         # m, largeur totale de la planche
WORK_HALF_WIDTH = 0.35     # m, demi-largeur de la zone couverte par une opératrice sans se déplacer

AXIS_LIMITS = {            # course des vérins (conception, à confirmer avec le fournisseur)
    "h": (0.85, 1.45),     # m, hauteur du centre du gabarit (colonnes élévatrices, course 600 mm)
    "a": (0.0, 40.0),      # °, inclinaison du haut du gabarit vers l'arrière, depuis la verticale
    "d": (0.30, 0.55),     # m, distance horizontale épaules -> centre du gabarit (rail, course 250 mm)
}
AXIS_SPEED = {"h": 0.030, "a": 3.0, "d": 0.025}   # m/s, °/s, m/s — vitesses limitées volontairement
AXIS_RESOLUTION = {"h": 0.001, "a": 0.1, "d": 0.001}  # résolution de consigne envoyée à l'ESP32

# Contraintes géométriques (hypothèses documentées)
MIN_BODY_CLEARANCE = 0.20  # m : le bord du gabarit le plus proche doit rester à ≥ 20 cm du plan des épaules
                           #     (profondeur thoracique ≈ 12–15 cm + 5 cm de marge)
MIN_BOTTOM_EDGE_H = 0.55   # m : bord bas au-dessus de la traverse du bâti
MAX_TOP_EDGE_H = 2.00      # m : bord haut sous le plafond du bâti / éclairage
TAKT_TIME_S = 276.0        # s : takt time du poste (cahier des charges) ; le réglage doit tenir dedans

# Hypothèses anthropométriques utilisées par le modèle (affichées dans les rapports)
HAND_GRIP_RATIO = 0.054    # poignet -> centre de préhension = 1/2 longueur de main (0,108 H, Winter 2009)
ACROMION_TO_JOINT = 0.035  # m : centre articulaire de l'épaule ≈ 3,5 cm en dedans de l'acromion
EYE_FORWARD = 0.09         # m : les yeux sont ≈ 9 cm en avant du plan des centres articulaires des épaules

# Configuration initiale par défaut : réglage fixe supposé du poste actuel.
# À RELEVER SUR LE POSTE RÉEL : cette valeur est une hypothèse de démonstration.
DEFAULT_INITIAL = {"h": 1.30, "a": 15.0, "d": 0.45}


# ----------------------------------------------------------------------------------------
# 2. Morphologie
# ----------------------------------------------------------------------------------------
DIMENSIONS = ("stature", "eye_h", "shoulder_h", "elbow_h", "upper_arm", "forearm", "shoulder_width")
DIM_LABELS = {
    "stature": "Stature", "eye_h": "Hauteur des yeux", "shoulder_h": "Hauteur des épaules (acromion)",
    "elbow_h": "Hauteur des coudes", "upper_arm": "Longueur du bras (épaule → coude)",
    "forearm": "Longueur de l'avant-bras (coude → poignet)", "shoulder_width": "Largeur des épaules (biacromiale)",
}
# Origines possibles d'une dimension
ORIGINS = {
    "bodyspace": "table anthropométrique (Bodyspace)",
    "bodyspace_biacromial": "table anthropométrique (Bodyspace, à revérifier)",
    "winter": "proportion de la stature (Winter 2009)",
    "saisie": "saisie manuelle",
    "estimee_2d": "estimation webcam 2D (échelle par stature déclarée)",
    "aruco_2d": "mesure 2D mise à l'échelle par marqueur ArUco",
    "mesure_3d": "mesure 3D caméra de profondeur (RealSense)",
    "declaree": "valeur déclarée (mesurée à la toise)",
}
SOURCE_KINDS = {
    "simulation": "Profil simulé (référence anthropométrique)",
    "personnalise": "Profil personnalisé (saisie manuelle)",
    "webcam_2d": "Estimation webcam 2D — non calibrée",
    "aruco_2d": "Webcam + ArUco — 2D mise à l'échelle",
    "realsense_3d": "Caméra de profondeur — mesure 3D calibrée",
}


@dataclass
class Body:
    """Morphologie en mètres. `origin` indique d'où vient chaque dimension."""
    stature: float
    eye_h: float
    shoulder_h: float
    elbow_h: float
    upper_arm: float
    forearm: float
    shoulder_width: float
    source: str = "simulation"
    label: str = ""
    origin: dict = field(default_factory=dict)
    uncertainty_m: float | None = None      # incertitude estimée (None = non quantifiée)

    # -- grandeurs dérivées (hypothèses documentées ci-dessus) --
    @property
    def forearm_grip(self) -> float:
        """Coude -> centre de préhension."""
        return self.forearm + HAND_GRIP_RATIO * self.stature

    @property
    def shoulder_half(self) -> float:
        """Demi-écart entre centres articulaires des épaules."""
        return self.shoulder_width / 2 - ACROMION_TO_JOINT

    @property
    def shoulder_joint_h(self) -> float:
        """Hauteur du centre articulaire de l'épaule (≈ 3,5 cm sous l'acromion)."""
        return self.shoulder_h - ACROMION_TO_JOINT

    def dims(self) -> dict:
        return {k: getattr(self, k) for k in DIMENSIONS}

    def to_dict(self) -> dict:
        d = asdict(self)
        d["derived"] = {"forearm_grip": round(self.forearm_grip, 4), "shoulder_half": round(self.shoulder_half, 4),
                        "shoulder_joint_h": round(self.shoulder_joint_h, 4)}
        d["source_label"] = SOURCE_KINDS.get(self.source, self.source)
        return d

    @staticmethod
    def from_dict(d: dict) -> "Body":
        missing = [k for k in DIMENSIONS if d.get(k) is None]
        if missing:
            raise ValueError("Dimensions manquantes : " + ", ".join(DIM_LABELS[k] for k in missing))
        return Body(**{k: float(d[k]) for k in DIMENSIONS}, source=d.get("source", "personnalise"),
                    label=d.get("label", ""), origin=dict(d.get("origin") or {k: "saisie" for k in DIMENSIONS}),
                    uncertainty_m=d.get("uncertainty_m"))

    @staticmethod
    def from_stature(h: float, source: str = "simulation") -> "Body":
        """Compatibilité v1 : profil proportionnel (Drillis & Contini / Winter).
        Toutes les dimensions sont marquées comme proportions, jamais comme mesures."""
        return Body(stature=h, eye_h=0.936 * h, shoulder_h=0.818 * h, elbow_h=0.630 * h,
                    upper_arm=0.186 * h, forearm=0.146 * h, shoulder_width=0.220 * h,
                    source=source, label=f"Proportions pour {h*100:.0f} cm",
                    origin={k: "winter" for k in DIMENSIONS} | {"stature": "saisie"})


# ----------------------------------------------------------------------------------------
# 3. Validation
# ----------------------------------------------------------------------------------------
# Bornes absolues (m) : en dehors, la valeur est physiquement improbable pour un adulte.
ABS_BOUNDS = {"stature": (1.35, 2.10), "eye_h": (1.25, 2.00), "shoulder_h": (1.05, 1.75),
              "elbow_h": (0.80, 1.35), "upper_arm": (0.22, 0.40), "forearm": (0.17, 0.34),
              "shoulder_width": (0.27, 0.50)}
# Rapports à la stature : [erreur_min, alerte_min, alerte_max, erreur_max]
# (bandes établies à partir des tables Bodyspace et Winter, ±3 à 4 écarts-types)
RATIO_BANDS = {"eye_h": (0.905, 0.920, 0.950, 0.960), "shoulder_h": (0.775, 0.795, 0.840, 0.855),
               "elbow_h": (0.580, 0.600, 0.650, 0.670), "upper_arm": (0.155, 0.170, 0.200, 0.215),
               "forearm": (0.120, 0.135, 0.160, 0.175), "shoulder_width": (0.180, 0.195, 0.255, 0.275)}


@dataclass
class Validation:
    ok: bool
    errors: list
    warnings: list

    def to_dict(self):
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings}


def validate_body(b: Body) -> Validation:
    errors, warns = [], []
    for k in DIMENSIONS:
        v = getattr(b, k)
        if not isinstance(v, (int, float)) or math.isnan(v):
            errors.append(f"{DIM_LABELS[k]} : valeur absente ou non numérique.")
            continue
        lo, hi = ABS_BOUNDS[k]
        if not lo <= v <= hi:
            errors.append(f"{DIM_LABELS[k]} = {v*100:.1f} cm hors des bornes plausibles ({lo*100:.0f}–{hi*100:.0f} cm).")
    if errors:
        return Validation(False, errors, warns)
    # Ordre anatomique : stature > yeux > épaules > coudes, avec marges minimales
    for hi_k, lo_k, gap in (("stature", "eye_h", 0.05), ("eye_h", "shoulder_h", 0.12), ("shoulder_h", "elbow_h", 0.20)):
        if getattr(b, hi_k) - getattr(b, lo_k) < gap:
            errors.append(f"Incohérence : {DIM_LABELS[hi_k]} doit dépasser {DIM_LABELS[lo_k]} d'au moins {gap*100:.0f} cm.")
    # Rapports à la stature
    for k, (e_lo, w_lo, w_hi, e_hi) in RATIO_BANDS.items():
        r = getattr(b, k) / b.stature
        if r < e_lo or r > e_hi:
            errors.append(f"{DIM_LABELS[k]} : rapport à la stature {r:.3f} incohérent (attendu {e_lo:.3f}–{e_hi:.3f}).")
        elif r < w_lo or r > w_hi:
            warns.append(f"{DIM_LABELS[k]} : rapport à la stature {r:.3f} inhabituel (courant {w_lo:.3f}–{w_hi:.3f}).")
    # Cohérence bras pendant : (hauteur épaule − hauteur coude) ≈ longueur du bras
    diff = (b.shoulder_h - b.elbow_h) - b.upper_arm
    if abs(diff) > 0.08:
        errors.append(f"Incohérence : hauteur épaules − hauteur coudes = {(b.shoulder_h-b.elbow_h)*100:.1f} cm "
                      f"mais bras = {b.upper_arm*100:.1f} cm (écart {diff*100:+.1f} cm > 8 cm).")
    elif abs(diff) > 0.04:
        warns.append(f"Écart de {diff*100:+.1f} cm entre (épaules − coudes) et la longueur du bras.")
    if b.uncertainty_m and b.uncertainty_m > 0.05:
        errors.append(f"Incertitude de mesure ±{b.uncertainty_m*100:.1f} cm trop élevée (max ±5 cm) : refaites l'acquisition.")
    elif b.uncertainty_m and b.uncertainty_m > 0.025:
        warns.append(f"Incertitude de mesure estimée ±{b.uncertainty_m*100:.1f} cm : résultats indicatifs.")
    return Validation(not errors, errors, warns)


# ----------------------------------------------------------------------------------------
# 4. Configuration du gabarit
# ----------------------------------------------------------------------------------------
@dataclass
class JigConfig:
    h: float   # m
    a: float   # °
    d: float   # m

    def as_dict(self):
        return {"h": round(self.h, 4), "a": round(self.a, 2), "d": round(self.d, 4)}

    def quantized(self) -> "JigConfig":
        q = lambda v, r: round(round(v / r) * r, 4)
        return JigConfig(q(self.h, AXIS_RESOLUTION["h"]), q(self.a, AXIS_RESOLUTION["a"]), q(self.d, AXIS_RESOLUTION["d"]))

    @staticmethod
    def from_dict(d: dict) -> "JigConfig":
        try:
            return JigConfig(float(d["h"]), float(d["a"]), float(d["d"]))
        except (KeyError, TypeError, ValueError):
            raise ValueError("Configuration invalide : attendu {h (m), a (°), d (m)}.")


def config_limit_errors(c: JigConfig) -> list:
    errs = []
    for k, unit, scale in (("h", "cm", 100), ("a", "°", 1), ("d", "cm", 100)):
        lo, hi = AXIS_LIMITS[k]
        v = getattr(c, k)
        if v < lo - 1e-9 or v > hi + 1e-9:
            errs.append(f"Axe {k.upper()} = {v*scale:.1f} {unit} hors course ({lo*scale:.0f}–{hi*scale:.0f} {unit}).")
    return errs


def move_time(src: JigConfig | dict, dst: JigConfig | dict) -> float:
    """Durée de déplacement (s) : axes simultanés, chacun à sa vitesse limite."""
    g = lambda c, k: c[k] if isinstance(c, dict) else getattr(c, k)
    return max(abs(g(dst, k) - g(src, k)) / AXIS_SPEED[k] for k in ("h", "a", "d"))


# ----------------------------------------------------------------------------------------
# 5. Profils
# ----------------------------------------------------------------------------------------
PROFILES_PATH = Path(__file__).with_name("profiles.json")


def load_reference_profiles(path: Path | None = None) -> dict:
    return json.loads((path or PROFILES_PATH).read_text(encoding="utf-8"))


def body_from_profile(pid: str, data: dict | None = None) -> Body:
    data = data or load_reference_profiles()
    for p in data["profiles"]:
        if p["id"] == pid:
            return Body(**p["dimensions"], source="simulation", label=p["label"], origin=dict(p["origin"]))
    raise KeyError(f"Profil inconnu : {pid}")


# ----------------------------------------------------------------------------------------
# 6. CLI (conservée depuis la v1, étendue)
# ----------------------------------------------------------------------------------------
def _cli():
    import argparse
    # Exécuté comme script, ce fichier est « __main__ » : on réimporte le module « smart_jig »
    # pour que les classes soient les mêmes que celles utilisées par optimizer / ergonomics.
    from smart_jig import Body, JigConfig, body_from_profile, load_reference_profiles, validate_body, DEFAULT_INITIAL
    from optimizer import optimise

    ap = argparse.ArgumentParser(description="ErgoGuard AI – gabarit intelligent (moteur de calcul)")
    ap.add_argument("--mode", choices=["simulate", "aruco", "realsense"], default="simulate")
    ap.add_argument("--profile", default="P50F", help="profil de référence (P5F, P50F, P95F, P95H)")
    ap.add_argument("--simulate", type=float, help="stature en cm : profil proportionnel (compatibilité v1)")
    ap.add_argument("--stature", type=float, help="stature mesurée à la toise, en cm (mode aruco)")
    ap.add_argument("--port", help="port série de l'ESP32 (matériel requis)")
    ap.add_argument("--compare", action="store_true", help="tableau comparatif des profils de référence")
    a = ap.parse_args()

    init = JigConfig(**DEFAULT_INITIAL)
    if a.compare:
        print(f"{'profil':<7}{'H cm':>6}{'A °':>6}{'D cm':>6}{'J init':>8}{'J opt':>8}"
              f"{'>45° init':>11}{'>45° opt':>10}{'statut':>12}")
        for p in load_reference_profiles()["profiles"]:
            b = body_from_profile(p["id"])
            r = optimise(b, init)
            o, bi, ba = r["optimal"]["config"], r["initial"]["indicators"], r["optimal"]["indicators"]
            print(f"{p['id']:<7}{o['h']*100:>6.1f}{o['a']:>6.1f}{o['d']*100:>6.1f}{r['initial']['J']:>8.3f}{r['optimal']['J']:>8.3f}"
                  f"{bi['shoulder']['share_above_45']:>10.0f}%{ba['shoulder']['share_above_45']:>9.0f}%{r['status']:>12}")
        return

    if a.mode == "simulate":
        body = Body.from_stature(a.simulate / 100) if a.simulate else body_from_profile(a.profile)
    else:
        from camera_measure import CameraMeasure
        body = CameraMeasure(a.mode, declared_stature=(a.stature / 100 if a.stature else None)).measure()
    v = validate_body(body)
    if not v.ok:
        print("Mesures refusées :\n  - " + "\n  - ".join(v.errors))
        return
    r = optimise(body, init)
    print(json.dumps({k: r[k] for k in ("status", "message", "initial", "optimal")}, indent=1, ensure_ascii=False)[:3000])
    if a.port and r["status"] == "optimal":
        from firmware_protocol import SerialJigController
        SerialJigController(a.port).move(JigConfig(**r["optimal"]["config"]))


if __name__ == "__main__":
    _cli()
