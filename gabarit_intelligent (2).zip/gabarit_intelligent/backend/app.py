"""
ErgoGuard AI – Smart Jig : API FastAPI
=====================================

Lancement (depuis le dossier gabarit_intelligent) :
    uvicorn backend.app:app --reload --port 8000
puis ouvrir http://localhost:8000 (le frontend est servi par la même application, ce qui
autorise aussi l'accès à la webcam du navigateur sur localhost).

Endpoints (JSON) :
    GET  /api/health    état du serveur et des bibliothèques matérielles
    GET  /api/profiles  profils anthropométriques documentés, limites des axes, poids par défaut
    POST /api/acquire   acquisition : simulation | personnalise | webcam_2d | realsense | aruco
    POST /api/evaluate  évaluation ergonomique d'une configuration (+ postures pour la 3D)
    POST /api/optimize  calcul des réglages optimaux H, A, D (+ commande ESP32 simulée)
    POST /api/report    rapport automatique (Markdown)
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Literal, Optional

sys.path.insert(0, str(Path(__file__).parent))

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import service
from service import ServiceError

app = FastAPI(title="ErgoGuard AI – Smart Jig", version=service.VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ---- Modèles d'entrée (validation de forme ; la validation anthropométrique est dans le moteur)
class Config(BaseModel):
    h: float = Field(..., description="hauteur du centre (m)", ge=0, le=3)
    a: float = Field(..., description="inclinaison (°)", ge=-90, le=90)
    d: float = Field(..., description="distance (m)", ge=0, le=2)


class Weights(BaseModel):
    epaule: Optional[float] = None
    allonge: Optional[float] = None
    cou: Optional[float] = None
    deplacement: Optional[float] = None


class AcquireRequest(BaseModel):
    mode: Literal["simulation", "personnalise", "webcam_2d", "realsense", "aruco"]
    profile_id: Optional[str] = None
    dimensions: Optional[dict[str, Optional[float]]] = None
    label: Optional[str] = Field(None, max_length=80)
    frames: Optional[list] = None
    image_w: Optional[int] = Field(None, ge=1, le=10000)
    image_h: Optional[int] = Field(None, ge=1, le=10000)
    declared_stature: Optional[float] = Field(None, gt=0, le=3, description="stature mesurée à la toise (m)")
    marker_m: Optional[float] = Field(None, gt=0, le=1)
    seconds: Optional[float] = Field(None, gt=0, le=10)


class EvaluateRequest(BaseModel):
    body: dict
    config: Optional[Config] = None
    with_postures: bool = True


class OptimizeRequest(BaseModel):
    body: dict
    initial: Optional[Config] = None
    weights: Optional[Weights] = None


def _dump(m):
    return m.model_dump(exclude_none=True) if m is not None else None


# ---- Gestion des erreurs : toujours {"error": {code, message, details}}
@app.exception_handler(ServiceError)
async def _service_error(_: Request, e: ServiceError):
    return JSONResponse(status_code=e.status, content=e.to_dict())


@app.exception_handler(RequestValidationError)
async def _validation_error(_: Request, e: RequestValidationError):
    details = [{"champ": ".".join(str(x) for x in err["loc"][1:]), "message": err["msg"]} for err in e.errors()]
    return JSONResponse(status_code=422, content={"error": {"code": "requete_invalide",
                        "message": "Requête invalide : vérifiez les champs signalés.", "details": details}})


@app.exception_handler(Exception)
async def _unexpected(_: Request, e: Exception):
    return JSONResponse(status_code=500, content={"error": {"code": "erreur_interne",
                        "message": f"Erreur interne du moteur : {type(e).__name__}", "details": str(e)}})


# ---- Endpoints
@app.get("/api/health")
def health():
    return service.health()


@app.get("/api/profiles")
def profiles():
    return service.profiles()


@app.post("/api/acquire")
def acquire(req: AcquireRequest):
    return service.acquire(req.model_dump(exclude_none=True))


@app.post("/api/evaluate")
def evaluate(req: EvaluateRequest):
    return service.evaluate({"body": req.body, "config": _dump(req.config), "with_postures": req.with_postures})


@app.post("/api/optimize")
def optimize(req: OptimizeRequest):
    return service.optimize({"body": req.body, "initial": _dump(req.initial), "weights": _dump(req.weights)})


@app.post("/api/report")
def report(req: OptimizeRequest):
    return service.report({"body": req.body, "initial": _dump(req.initial), "weights": _dump(req.weights)})


# ---- Frontend (servi en dernier pour ne pas masquer /api)
FRONTEND = Path(__file__).resolve().parent.parent / "frontend"


@app.get("/", include_in_schema=False)
def root():
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/gabarit_3d.html")


if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
