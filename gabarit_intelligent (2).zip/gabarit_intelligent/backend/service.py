"""
ErgoGuard AI – Smart Jig : couche de service (logique des endpoints)
===================================================================

Fonctions « dict -> dict » sans dépendance web. Elles sont appelées :
  * par l'API FastAPI (app.py) quand le serveur tourne ;
  * directement dans le navigateur par Pyodide (page autonome), avec les mêmes fichiers.
Ainsi l'algorithme n'existe qu'en un seul exemplaire, en Python.
"""
from __future__ import annotations

import datetime as _dt
import sys

from smart_jig import (AXIS_LIMITS, AXIS_SPEED, DEFAULT_INITIAL, DIM_LABELS, DIMENSIONS, ORIGINS, SOURCE_KINDS, VERSION,
                       Body, JigConfig, TAKT_TIME_S, body_from_profile, load_reference_profiles, validate_body)
from ergonomics import display_postures, evaluate as _evaluate
from optimizer import DEFAULT_WEIGHTS, check_weights, optimise
from camera_measure import AcquisitionRefused, CameraMeasure, HardwareUnavailable, hardware_status, process_webcam_frames
from firmware_protocol import SimulatedController

IN_BROWSER = sys.platform == "emscripten"


class ServiceError(Exception):
    def __init__(self, status: int, code: str, message: str, details=None):
        super().__init__(message)
        self.status, self.code, self.message, self.details = status, code, message, details

    def to_dict(self):
        return {"error": {"code": self.code, "message": self.message, "details": self.details}}


def _body(d) -> Body:
    if not isinstance(d, dict):
        raise ServiceError(422, "body_absent", "Morphologie absente : lancez d'abord une acquisition.")
    try:
        return Body.from_dict(d)
    except (ValueError, TypeError) as e:
        raise ServiceError(422, "body_invalide", str(e))


def _config(d, default=None) -> JigConfig:
    if d is None and default is not None:
        return JigConfig(**default)
    try:
        return JigConfig.from_dict(d)
    except ValueError as e:
        raise ServiceError(422, "config_invalide", str(e))


# ----------------------------------------------------------------------------------------
def health() -> dict:
    hw = {"opencv": False, "mediapipe": False, "pyrealsense2": False, "pyserial": False} if IN_BROWSER else hardware_status()
    return {"status": "ok", "version": VERSION, "engine": "python",
            "runtime": "pyodide (navigateur)" if IN_BROWSER else f"cpython {sys.version.split()[0]}",
            "hardware_libraries": hw,
            "capabilities": {"simulation": True, "webcam_2d_processing": True,
                             "realsense_3d": hw["pyrealsense2"] and hw["mediapipe"],
                             "aruco_2d": hw["opencv"] and hw["mediapipe"],
                             "esp32_serial": hw["pyserial"], "esp32_connected": False,
                             "actuators": "simulés"}}


def profiles() -> dict:
    data = load_reference_profiles()
    out = []
    for p in data["profiles"]:
        b = body_from_profile(p["id"], data)
        out.append({**p, "validation": validate_body(b).to_dict(), "body": b.to_dict()})
    return {"profiles": out, "sources": data["_doc"]["sources"], "warning": data["_doc"]["avertissement"],
            "dimension_labels": DIM_LABELS, "dimensions": list(DIMENSIONS), "units": "m",
            "origins": ORIGINS, "source_kinds": SOURCE_KINDS,
            "axis_limits": AXIS_LIMITS, "axis_speed": AXIS_SPEED, "takt_time_s": TAKT_TIME_S,
            "default_initial": DEFAULT_INITIAL, "default_weights": DEFAULT_WEIGHTS}


def acquire(req: dict) -> dict:
    mode = (req or {}).get("mode")
    if mode == "simulation":
        try:
            b = body_from_profile(req.get("profile_id", ""))
        except KeyError as e:
            raise ServiceError(404, "profil_inconnu", str(e).strip("'"))
        v = validate_body(b)
        return {"ok": v.ok, "body": b.to_dict(), "errors": v.errors, "warnings": v.warnings, "quality": None}
    if mode == "personnalise":
        dims = req.get("dimensions") or {}
        missing = [DIM_LABELS[k] for k in DIMENSIONS if dims.get(k) is None]
        if missing:
            raise ServiceError(422, "dimensions_manquantes", "Dimensions manquantes : " + ", ".join(missing))
        try:
            b = Body(**{k: float(dims[k]) for k in DIMENSIONS}, source="personnalise", label=req.get("label") or "Profil personnalisé",
                     origin={k: (req.get("origin") or {}).get(k, "saisie") for k in DIMENSIONS})
        except (TypeError, ValueError):
            raise ServiceError(422, "dimensions_non_numeriques", "Toutes les dimensions doivent être des nombres (mètres).")
        v = validate_body(b)
        return {"ok": v.ok, "body": b.to_dict(), "errors": v.errors, "warnings": v.warnings, "quality": None}
    if mode == "webcam_2d":
        frames = req.get("frames")
        if not isinstance(frames, list) or not frames:
            raise ServiceError(422, "frames_absentes", "Aucune image de points articulaires reçue.")
        if len(frames) > 600:
            raise ServiceError(413, "trop_d_images", "Maximum 600 images par acquisition.")
        r = process_webcam_frames(frames, int(req.get("image_w") or 0) or 1, int(req.get("image_h") or 0) or 1,
                                  req.get("declared_stature"))
        return r
    if mode in ("realsense", "aruco"):
        if IN_BROWSER:
            raise ServiceError(503, "materiel_requis", "Acquisition RealSense/ArUco impossible dans le navigateur : "
                               "lancez le serveur local avec la caméra branchée.")
        try:
            cam = CameraMeasure(mode, declared_stature=req.get("declared_stature"), marker_m=float(req.get("marker_m") or 0.15))
            return cam.measure_report(float(req.get("seconds") or 3.0))
        except HardwareUnavailable as e:
            raise ServiceError(503, "materiel_requis", f"Matériel requis pour le mode {mode} : {e}")
        except AcquisitionRefused as e:
            return {"ok": False, "body": None, "errors": e.errors, "warnings": [], "quality": e.quality}
    raise ServiceError(422, "mode_inconnu", "Mode attendu : simulation, personnalise, webcam_2d, realsense ou aruco.")


def evaluate(req: dict) -> dict:
    b = _body((req or {}).get("body"))
    v = validate_body(b)
    if not v.ok:
        raise ServiceError(422, "mesures_invalides", "Évaluation refusée : mesures anthropométriques invalides.", v.errors)
    c = _config(req.get("config"), DEFAULT_INITIAL)
    out = _evaluate(b, c, with_postures=bool(req.get("with_postures", True)))
    out["validation"] = v.to_dict()
    return out


def optimize(req: dict) -> dict:
    req = req or {}
    b = _body(req.get("body"))
    init = _config(req.get("initial"), DEFAULT_INITIAL)
    try:
        w = check_weights(req.get("weights"))
    except ValueError as e:
        raise ServiceError(422, "poids_invalides", str(e))
    r = optimise(b, init, w)
    if r["status"] == "donnees_invalides":
        raise ServiceError(422, "mesures_invalides", r["message"], r["validation"]["errors"])
    r["postures"] = {"initial": display_postures(b, init),
                     "optimal": display_postures(b, JigConfig.from_dict(r["optimal"]["config"]))}
    r["controller"] = (SimulatedController().plan_move(init, JigConfig.from_dict(r["optimal"]["config"]))
                       if r["status"] == "optimal" else None)
    return r


# ----------------------------------------------------------------------------------------
# Rapport automatique (Markdown)
# ----------------------------------------------------------------------------------------
def _f(v, unit="", nd=1):
    return "—" if v is None else f"{v:.{nd}f}{unit}"


def report(req: dict) -> dict:
    r = optimize(req)
    b = r["body"]
    now = _dt.datetime.now().strftime("%d/%m/%Y %H:%M")
    L = []
    L += [f"# Rapport — gabarit intelligent ErgoGuard AI", "",
          f"Poste 3.2 Montage faisceaux (LEONI) · généré le {now} · moteur v{VERSION}", "",
          "> Jumeau numérique : le gabarit et ses vérins sont **simulés**. Aucun déplacement physique n'a été réalisé.", ""]
    L += ["## 1. Profil anthropométrique", "",
          f"**Source des mesures :** {b['source_label']}" + (f" — {b['label']}" if b.get("label") else ""), ""]
    if b.get("uncertainty_m"):
        L += [f"Incertitude estimée : ±{b['uncertainty_m']*100:.1f} cm.", ""]
    L += ["| Dimension | Valeur | Origine |", "|---|---|---|"]
    for k in DIMENSIONS:
        L.append(f"| {DIM_LABELS[k]} | {b[k]*100:.1f} cm | {ORIGINS.get(b['origin'].get(k, ''), b['origin'].get(k, ''))} |")
    if r["validation"]["warnings"]:
        L += ["", "Avertissements de validation : " + " ".join(r["validation"]["warnings"])]
    i, o = r["initial"], r["optimal"]
    ci, co = i["config"], o["config"]
    L += ["", "## 2. Réglages", "", "| Axe | Initial | Optimal |", "|---|---|---|",
          f"| H — hauteur du centre | {ci['h']*100:.1f} cm | {co['h']*100:.1f} cm |",
          f"| A — inclinaison | {ci['a']:.1f}° | {co['a']:.1f}° |",
          f"| D — distance de préhension | {ci['d']*100:.1f} cm | {co['d']*100:.1f} cm |", "",
          f"**Statut :** {r['status']} — {r['message']}", ""]
    if r.get("move_time_s") is not None:
        L += [f"Durée de réglage estimée : {r['move_time_s']:.1f} s (takt time {TAKT_TIME_S:.0f} s).", ""]
    ii, io = i["indicators"], o["indicators"]
    L += ["## 3. Indicateurs avant / après", "", "| Indicateur | Initial | Optimal |", "|---|---|---|",
          f"| Élévation moyenne de l'épaule | {_f(ii['shoulder']['mean'], '°')} | {_f(io['shoulder']['mean'], '°')} |",
          f"| Élévation maximale de l'épaule | {_f(ii['shoulder']['max'], '°')} | {_f(io['shoulder']['max'], '°')} |",
          f"| Part pondérée des points avec épaule > 45° | {_f(ii['shoulder']['share_above_45'], ' %', 0)} | {_f(io['shoulder']['share_above_45'], ' %', 0)} |",
          f"| Flexion moyenne du coude | {_f(ii['elbow']['mean'], '°')} | {_f(io['elbow']['mean'], '°')} |",
          f"| Allonge maximale (part de l'allonge du membre) | {_f(ii['reach']['max_ratio']*100, ' %', 0)} | {_f(io['reach']['max_ratio']*100, ' %', 0)} |",
          f"| Points hors d'atteinte | {ii['reach']['unreachable_points']} | {io['reach']['unreachable_points']} |",
          f"| Regard vers le centre (sous l'horizontale) | {_f(ii['gaze']['centre'], '°')} | {_f(io['gaze']['centre'], '°')} |",
          f"| Fonction objectif J | {i['J']:.3f} | {o['J']:.3f} |", "",
          f"_{ii['weighting']}_", ""]
    L += ["## 4. Évaluations normatives", ""]
    for k, ev in o["evaluations"].items():
        ev_i = i["evaluations"][k]
        line = f"- **{ev['name']}** ({ev['status'].replace('_', ' ')})"
        if "values" in ev:
            line += " : " + "; ".join(f"{kk} {ev_i['values'][kk]} → {vv}" for kk, vv in ev["values"].items())
        if "missing" in ev:
            line += " — données manquantes : " + ", ".join(ev["missing"])
        L += [line, f"  {ev['note']}"]
    L += ["", "## 5. Contraintes (configuration optimale)", ""]
    for k in o["constraints"]:
        val = f" — {k['value']} ({k['limit']})" if "value" in k else f" — {k.get('detail', '')}"
        L.append(f"- {'✅' if k['ok'] else '❌'} {k['label']}{val}")
    if r.get("convergence"):
        cv = r["convergence"]
        L += ["", "## 6. Optimisation", "",
              f"Poids : épaule {r['weights']['epaule']}, allonge {r['weights']['allonge']}, cou {r['weights']['cou']}, "
              f"déplacement {r['weights']['deplacement']}. Convergence : {'oui' if cv['converged'] else 'non'} · "
              f"{cv['evaluations']} évaluations · {cv['starts']} départs · écart entre optimums locaux ΔJ = {cv['spread_J']}. "
              f"Temps de calcul : {r['compute_ms']:.0f} ms."]
    if r.get("controller"):
        L += ["", "## 7. Commande ESP32 (simulée)", "", f"`{r['controller']['command']}`", "", r["controller"]["note"]]
    L += ["", "## 8. Limites de l'analyse", ""] + [f"- {x}" for x in r["limits"]]
    return {"markdown": "\n".join(L), "result": {k: r[k] for k in ("status", "message", "move_time_s", "compute_ms")}}
