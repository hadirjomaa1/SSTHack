"""
ErgoGuard AI – Smart Jig : acquisition anthropométrique par caméra
=================================================================

Trois sources, clairement distinguées (champ `source` du Body) :

  webcam_2d     Points MediaPipe Pose envoyés par le navigateur (coordonnées image normalisées).
                Une webcam ne mesure PAS de distances : l'échelle vient de la stature déclarée
                (mesurée à la toise), et la position du sommet du crâne (absent de MediaPipe)
                est estimée par une hypothèse anthropométrique documentée (VERTEX_RATIO).
                => estimation 2D non calibrée, incertitude typique ±2 à 4 cm.
  aruco_2d      Webcam + marqueur ArUco de taille connue dans le plan de l'opératrice : échelle
                mesurée, mais valable seulement dans ce plan ; mesures 2D.  (matériel : marqueur imprimé)
  realsense_3d  Caméra de profondeur Intel RealSense : points articulaires déprojetés en 3D (m).
                (matériel requis : RealSense D4xx + pyrealsense2)

Le traitement (contrôles de qualité + agrégation) est commun aux trois sources et ne dépend
que de la bibliothèque standard : il tourne aussi dans le navigateur (Pyodide).
Aucune image n'est stockée : seules les coordonnées des points articulaires sont traitées.

Posture de référence exigée : debout, face caméra, pieds visibles, bras le long du corps.
"""
from __future__ import annotations

import math
import statistics as st
import time

from smart_jig import ACROMION_TO_JOINT, Body, DIMENSIONS, validate_body

# Indices MediaPipe Pose (33 points)
LM = {"l_eye": 2, "r_eye": 5, "l_sh": 11, "r_sh": 12, "l_el": 13, "r_el": 14, "l_wr": 15, "r_wr": 16,
      "l_hip": 23, "r_hip": 24, "l_heel": 29, "r_heel": 30, "l_toe": 31, "r_toe": 32}
REQUIRED = ("l_eye", "r_eye", "l_sh", "r_sh", "l_el", "r_el", "l_wr", "r_wr", "l_hip", "r_hip", "l_heel", "r_heel")

MIN_VISIBILITY = 0.6        # seuil de confiance MediaPipe par point
MIN_DETECTION_RATE = 0.6    # part minimale d'images exploitables
MIN_VALID_FRAMES = 15
MAX_ARM_TILT = 25.0         # ° : bras et avant-bras quasi verticaux (bras le long du corps)
MAX_TRUNK_TILT = 10.0       # ° : tronc vertical
# Hypothèse « sommet du crâne » : (stature − hauteur des yeux) / (hauteur des yeux − hauteur des épaules)
# Bodyspace P50 : femmes (1610−1505)/(1505−1310) = 0,54 ; hommes (1740−1630)/(1630−1425) = 0,54.
VERTEX_RATIO = 0.54
LANDMARK_DEFINITION_ERR = 0.02   # m : écart entre point MediaPipe et repère anthropométrique (acromion, coude)


class HardwareUnavailable(RuntimeError):
    """Matériel ou bibliothèque absent : message explicite pour l'utilisateur."""


class AcquisitionRefused(ValueError):
    def __init__(self, errors, quality=None):
        super().__init__("; ".join(errors))
        self.errors, self.quality = errors, quality or {}


# ----------------------------------------------------------------------------------------
# Géométrie d'une image
# ----------------------------------------------------------------------------------------
def _mid(a, b): return tuple((a[i] + b[i]) / 2 for i in range(len(a)))
def _dist(a, b): return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(len(a))))


def _tilt_from_vertical(top, bottom):
    """Angle (°) du segment par rapport à la verticale (axe y vers le haut)."""
    dx = [top[i] - bottom[i] for i in range(len(top))]
    n = math.sqrt(sum(v * v for v in dx)) or 1e-9
    return math.degrees(math.acos(max(-1.0, min(1.0, abs(dx[1]) / n))))


def frame_measures(p: dict, declared_stature: float | None, scale: float | None):
    """Une image -> (mesures en m) ou (None, raison). `p` : points en repère y vers le haut.
    Si `scale` (m/unité) est None, l'échelle est déduite de la stature déclarée."""
    for side in ("l", "r"):
        if _tilt_from_vertical(p[f"{side}_sh"], p[f"{side}_el"]) > MAX_ARM_TILT or \
           _tilt_from_vertical(p[f"{side}_el"], p[f"{side}_wr"]) > MAX_ARM_TILT:
            return None, "bras non tendus le long du corps"
        if p[f"{side}_wr"][1] > p[f"{side}_el"][1] or p[f"{side}_el"][1] > p[f"{side}_sh"][1]:
            return None, "bras non tendus le long du corps"
    sh_m, hip_m = _mid(p["l_sh"], p["r_sh"]), _mid(p["l_hip"], p["r_hip"])
    if _tilt_from_vertical(sh_m, hip_m) > MAX_TRUNK_TILT:
        return None, "tronc incliné"
    feet = [p[k][1] for k in ("l_heel", "r_heel", "l_toe", "r_toe") if k in p]
    floor = min(feet)
    eye = _mid(p["l_eye"], p["r_eye"])[1] - floor
    sh = sh_m[1] - floor
    el = _mid(p["l_el"], p["r_el"])[1] - floor
    if not (eye > sh > el > 0):
        return None, "ordre vertical yeux > épaules > coudes non respecté"
    if scale is None:
        if not declared_stature:
            return None, "stature déclarée requise pour mettre à l'échelle une webcam 2D"
        stature_units = eye + VERTEX_RATIO * (eye - sh)
        scale = declared_stature / stature_units
        stature = declared_stature
    else:
        stature = declared_stature or (eye + VERTEX_RATIO * (eye - sh)) * scale
    m = {"stature": stature, "eye_h": eye * scale, "shoulder_h": sh * scale, "elbow_h": el * scale,
         "upper_arm_l": _dist(p["l_sh"], p["l_el"]) * scale, "upper_arm_r": _dist(p["r_sh"], p["r_el"]) * scale,
         "forearm_l": _dist(p["l_el"], p["l_wr"]) * scale, "forearm_r": _dist(p["r_el"], p["r_wr"]) * scale,
         "shoulder_width": _dist(p["l_sh"], p["r_sh"]) * scale}
    return m, None


def _robust(values):
    """Médiane après rejet des valeurs aberrantes (MAD), coefficient de variation, nb rejetés."""
    med = st.median(values)
    mad = st.median([abs(v - med) for v in values]) * 1.4826
    kept = [v for v in values if mad == 0 or abs(v - med) <= 3.5 * mad]
    med = st.median(kept)
    cv = (st.pstdev(kept) / med) if med else 0.0
    return med, cv, len(values) - len(kept), (st.pstdev(kept) if len(kept) > 1 else 0.0)


def aggregate(frames_pts: list, source: str, declared_stature: float | None = None,
              scale: float | None = None, n_total: int | None = None, rejected: dict | None = None) -> dict:
    """Contrôles de qualité et agrégation. `frames_pts` : liste de dict (points y vers le haut)
    déjà filtrés sur la visibilité. Retourne un rapport ; `body` est None si l'acquisition est refusée."""
    rejected = dict(rejected or {})
    n_total = n_total or len(frames_pts)
    per = []
    for p in frames_pts:
        m, why = frame_measures(p, declared_stature, scale)
        if m is None:
            rejected[why] = rejected.get(why, 0) + 1
        else:
            per.append(m)
    errors, warns = [], []
    rate = len(per) / n_total if n_total else 0.0
    quality = {"frames_total": n_total, "frames_valid": len(per), "detection_rate": round(rate, 3),
               "rejections": rejected}
    if len(per) < MIN_VALID_FRAMES or rate < MIN_DETECTION_RATE:
        reasons = ", ".join(f"{k} ({v})" for k, v in sorted(rejected.items(), key=lambda x: -x[1])) or "aucune détection"
        errors.append(f"Détection insuffisante : {len(per)} images exploitables sur {n_total} "
                      f"(minimum {MIN_VALID_FRAMES} et {MIN_DETECTION_RATE:.0%}). Causes : {reasons}.")
        return {"ok": False, "body": None, "quality": quality, "errors": errors, "warnings": warns}

    keys = per[0].keys()
    agg, cvs, std = {}, {}, {}
    outliers = 0
    for k in keys:
        med, cv, nrej, sd = _robust([m[k] for m in per])
        agg[k], cvs[k], std[k] = med, cv, sd
        outliers += nrej
    quality["outliers_rejected"] = outliers
    quality["cv_max"] = round(max(cvs.values()), 4)
    # Stabilité entre images
    unstable = [k for k, cv in cvs.items() if cv > 0.08]
    if unstable:
        errors.append("Mesures instables entre images (variation > 8 %) : " + ", ".join(unstable) + ". Restez immobile.")
    elif any(cv > 0.04 for cv in cvs.values()):
        warns.append("Légère instabilité entre images (variation > 4 %).")
    # Symétrie gauche / droite
    for seg in ("upper_arm", "forearm"):
        l, r = agg[f"{seg}_l"], agg[f"{seg}_r"]
        asym = abs(l - r) / max(l, r)
        quality[f"asym_{seg}"] = round(asym, 3)
        if asym > 0.15:
            errors.append(f"Asymétrie gauche/droite de {asym:.0%} sur {seg} : posture ou détection incorrecte.")
        elif asym > 0.08:
            warns.append(f"Asymétrie gauche/droite de {asym:.0%} sur {seg}.")
    dims = {"stature": agg["stature"], "eye_h": agg["eye_h"], "shoulder_h": agg["shoulder_h"], "elbow_h": agg["elbow_h"],
            "upper_arm": (agg["upper_arm_l"] + agg["upper_arm_r"]) / 2, "forearm": (agg["forearm_l"] + agg["forearm_r"]) / 2,
            "shoulder_width": agg["shoulder_width"]}
    origin_kind = {"webcam_2d": "estimee_2d", "aruco_2d": "aruco_2d", "realsense_3d": "mesure_3d"}[source]
    origin = {k: origin_kind for k in DIMENSIONS}
    if declared_stature:
        origin["stature"] = "declaree"
    # Incertitude : définition des repères + bruit entre images + hypothèse sommet du crâne (si échelle déduite)
    noise = max(std.get(k, 0.0) for k in ("eye_h", "shoulder_h", "elbow_h"))
    vertex_err = 0.06 * (dims["eye_h"] - dims["shoulder_h"]) if scale is None else 0.0
    unc = math.sqrt(LANDMARK_DEFINITION_ERR ** 2 + noise ** 2 + vertex_err ** 2 + (0.01 if source != "realsense_3d" else 0.0) ** 2)
    body = Body(**{k: round(v, 4) for k, v in dims.items()}, source=source,
                label={"webcam_2d": "Estimation webcam 2D", "aruco_2d": "Webcam + ArUco (2D)", "realsense_3d": "RealSense 3D"}[source],
                origin=origin, uncertainty_m=round(unc, 4))
    v = validate_body(body)
    errors += v.errors
    warns += v.warnings
    if source == "webcam_2d":
        warns.insert(0, "Estimation 2D non calibrée : l'échelle provient de la stature déclarée et le sommet du crâne est estimé "
                        f"(hypothèse rapport {VERTEX_RATIO}). Pour une mesure fiable : caméra de profondeur calibrée.")
    if errors:
        return {"ok": False, "body": body.to_dict(), "quality": quality, "errors": errors, "warnings": warns}
    return {"ok": True, "body": body.to_dict(), "quality": quality, "errors": [], "warnings": warns}


def process_webcam_frames(frames: list, image_w: int, image_h: int, declared_stature: float | None) -> dict:
    """Points envoyés par le navigateur : frames = [[[x, y, z, visibility] × 33], …], x et y normalisés
    (0–1, y vers le bas). Les points peu visibles invalident l'image (pas d'invention de point manquant)."""
    if not declared_stature:
        return {"ok": False, "body": None, "quality": {"frames_total": len(frames)},
                "errors": ["Stature déclarée obligatoire en mode webcam 2D : mesurez-la à la toise."], "warnings": []}
    if not 1.35 <= declared_stature <= 2.10:
        return {"ok": False, "body": None, "quality": {}, "errors": ["Stature déclarée hors bornes (135–210 cm)."], "warnings": []}
    pts_frames, rejected, vis_sum, vis_n = [], {}, 0.0, 0
    for f in frames:
        if not isinstance(f, list) or len(f) < 33:
            rejected["aucune personne détectée"] = rejected.get("aucune personne détectée", 0) + 1
            continue
        low = [k for k in REQUIRED if f[LM[k]][3] < MIN_VISIBILITY]
        vis_sum += sum(f[LM[k]][3] for k in REQUIRED); vis_n += len(REQUIRED)
        if low:
            why = "points invisibles : " + ", ".join(sorted({k[2:] for k in low}))
            rejected[why] = rejected.get(why, 0) + 1
            continue
        # pixels, y vers le haut ; les pointes de pied ne servent que si elles sont visibles
        pts = {k: (f[i][0] * image_w, -f[i][1] * image_h) for k, i in LM.items()
               if k in REQUIRED or f[i][3] >= MIN_VISIBILITY}
        pts_frames.append(pts)
    out = aggregate(pts_frames, "webcam_2d", declared_stature=declared_stature, scale=None,
                    n_total=len(frames), rejected=rejected)
    out["quality"]["mean_visibility"] = round(vis_sum / vis_n, 3) if vis_n else 0.0
    return out


# ----------------------------------------------------------------------------------------
# Acquisition côté serveur (matériel requis)
# ----------------------------------------------------------------------------------------
class PoseDetector:
    """Adaptateur MediaPipe : API historique `mp.solutions.pose` (≤ 0.10.2x) ou API Tasks
    (versions récentes, qui exigent le fichier modèle pose_landmarker_*.task, chemin donné par
    la variable d'environnement ERGO_POSE_MODEL). Retourne 33 points (x, y normalisés, visibility)."""

    def __init__(self):
        try:
            import mediapipe as mp
        except ImportError as e:
            raise HardwareUnavailable("MediaPipe absent : pip install mediapipe") from e
        self.mp = mp
        if hasattr(mp, "solutions"):
            self.kind = "legacy"
            self.model = mp.solutions.pose.Pose(model_complexity=2, min_detection_confidence=0.6)
            return
        import os
        path = os.environ.get("ERGO_POSE_MODEL")
        if not path or not os.path.exists(path):
            raise HardwareUnavailable(
                "MediaPipe récent : téléchargez pose_landmarker_heavy.task (Google MediaPipe Models) et indiquez son "
                "chemin dans la variable d'environnement ERGO_POSE_MODEL.")
        from mediapipe.tasks.python import BaseOptions, vision
        self.kind = "tasks"
        self.model = vision.PoseLandmarker.create_from_options(vision.PoseLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=path), running_mode=vision.RunningMode.IMAGE,
            min_pose_detection_confidence=0.6))

    def detect(self, rgb):
        if self.kind == "legacy":
            res = self.model.process(rgb)
            return res.pose_landmarks.landmark if res.pose_landmarks else None
        res = self.model.detect(self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=rgb))
        return res.pose_landmarks[0] if res.pose_landmarks else None


class CameraMeasure:
    """Acquisition sur le poste par caméra branchée au serveur. Matériel requis :
    - mode "realsense" : Intel RealSense D4xx + pyrealsense2 ;
    - mode "aruco"     : webcam + marqueur ArUco DICT_4X4_50 de `marker_m` mètres dans le plan
                         de l'opératrice + opencv-contrib-python.
    Lève HardwareUnavailable avec un message explicite si le matériel est absent."""

    def __init__(self, mode: str = "realsense", declared_stature: float | None = None,
                 marker_m: float = 0.15, cam_index: int = 0):
        if mode not in ("realsense", "aruco"):
            raise ValueError("mode attendu : realsense ou aruco")
        self.mode, self.declared, self.marker_m = mode, declared_stature, marker_m
        # 1. Matériel d'abord (message le plus utile si la caméra manque)
        if mode == "realsense":
            try:
                import pyrealsense2 as rs
            except ImportError as e:
                raise HardwareUnavailable("pyrealsense2 absent : pip install pyrealsense2 (caméra Intel RealSense requise)") from e
            if len(rs.context().query_devices()) == 0:
                raise HardwareUnavailable("Aucune caméra RealSense branchée.")
        try:
            import cv2
        except ImportError as e:
            raise HardwareUnavailable("OpenCV absent : pip install opencv-contrib-python") from e
        self.cv2 = cv2
        # 2. Estimateur de pose (deux API MediaPipe selon la version installée)
        self.pose = PoseDetector()
        if mode == "realsense":
            self.rs = rs
            self.pipe = rs.pipeline()
            cfg = rs.config()
            cfg.enable_stream(rs.stream.color, 1280, 720, rs.format.bgr8, 30)
            cfg.enable_stream(rs.stream.depth, 1280, 720, rs.format.z16, 30)
            prof = self.pipe.start(cfg)
            self.align = rs.align(rs.stream.color)
            self.intr = prof.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
        else:
            self.cap = cv2.VideoCapture(cam_index)
            if not self.cap.isOpened():
                raise HardwareUnavailable(f"Webcam {cam_index} introuvable sur le serveur.")
            self.det = cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))

    def _frame(self):
        """Retourne (points y-haut, échelle m/unité, raison du rejet)."""
        cv2 = self.cv2
        if self.mode == "realsense":
            fr = self.align.process(self.pipe.wait_for_frames())
            color, depth = fr.get_color_frame(), fr.get_depth_frame()
            import numpy as np
            img = np.asanyarray(color.get_data())
        else:
            ok, img = self.cap.read()
            if not ok:
                return None, None, "image non lue"
        hgt, wid = img.shape[:2]
        lms = self.pose.detect(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        if lms is None:
            return None, None, "aucune personne détectée"
        if any(lms[LM[k]].visibility < MIN_VISIBILITY for k in REQUIRED):
            return None, None, "points invisibles"
        px = {k: (lms[i].x * wid, lms[i].y * hgt) for k, i in LM.items()}
        if self.mode == "realsense":
            pts = {}
            for k, (u, v) in px.items():
                u, v = int(min(max(u, 0), wid - 1)), int(min(max(v, 0), hgt - 1))
                z = depth.get_distance(u, v)
                if z <= 0:
                    if k in REQUIRED:
                        return None, None, "profondeur absente"
                    continue
                x, y, zz = self.rs.rs2_deproject_pixel_to_point(self.intr, [u, v], z)
                pts[k] = (x, -y, zz)
            return pts, 1.0, None
        corners, ids, _ = self.det.detectMarkers(img)
        if ids is None:
            return None, None, "marqueur ArUco non vu"
        c = corners[0][0]
        side_px = sum(math.dist(c[i], c[(i + 1) % 4]) for i in range(4)) / 4
        return {k: (u, -v) for k, (u, v) in px.items()}, self.marker_m / side_px, None

    def measure_report(self, seconds: float = 3.0) -> dict:
        frames, scales, rejected, n = [], [], {}, 0
        t0 = time.time()
        while time.time() - t0 < seconds:
            n += 1
            pts, sc, why = self._frame()
            if pts is None:
                rejected[why] = rejected.get(why, 0) + 1
                continue
            frames.append(pts); scales.append(sc)
        source = "realsense_3d" if self.mode == "realsense" else "aruco_2d"
        scale = st.median(scales) if scales else None
        return aggregate(frames, source, declared_stature=self.declared, scale=scale, n_total=n, rejected=rejected)

    def measure(self, seconds: float = 3.0) -> Body:
        """Compatibilité v1 : retourne un Body ou lève AcquisitionRefused."""
        r = self.measure_report(seconds)
        if not r["ok"]:
            raise AcquisitionRefused(r["errors"], r["quality"])
        return Body.from_dict(r["body"])


def hardware_status() -> dict:
    """Disponibilité des bibliothèques (le matériel lui-même n'est testé qu'à l'acquisition)."""
    out = {}
    for name, mod in (("opencv", "cv2"), ("mediapipe", "mediapipe"), ("pyrealsense2", "pyrealsense2"), ("pyserial", "serial")):
        try:
            __import__(mod)
            out[name] = True
        except Exception:
            out[name] = False
    return out
