"""
ErgoGuard AI – Smart Jig : optimisation des réglages H, A, D
===========================================================

Fonction objectif multi-critères (sans dimension, plus petit = meilleur) :

    J(H, A, D) = w1·J_épaule + w2·J_allonge + w3·J_cou + w4·J_déplacement

  J_épaule      moyenne pondérée d'une pénalité continue de l'élévation du bras dont la pente
                augmente avec les classes de l'item « bras » de RULA :
                0 jusqu'à 20°, 0→1 de 20 à 45°, 1→3 de 45 à 90°, puis +1 par 30° au-delà.
  J_allonge     pénalité au-delà de 85 % de l'allonge maximale (le tronc se penche) et en deçà de
                45 % (coudes écartés, poignets en extension).
  J_cou         écart de la ligne de regard vers le centre du gabarit à la zone 15–35° sous
                l'horizontale, plus la part du gabarit au-dessus des yeux (extension du cou).
  J_déplacement déplacement des 3 axes depuis la configuration initiale, normalisé par la course.

Poids par défaut et justification (modifiables par l'API) :
  w1 = 1.0   épaule : zone de TMS déclarée au poste (épaules douloureuses, sus-épineux).
  w2 = 0.8   allonge : la sur-extension ajoute flexion du tronc et charge de l'épaule.
  w3 = 0.5   cou : sollicité par le contrôle visuel des codes couleur, pas de TMS déclaré.
  w4 = 0.05  déplacement : simple départage entre solutions ergonomiquement équivalentes
             (réglage plus court, moins d'usure) ; ne peut pas dégrader l'ergonomie de plus de 0,05.

Contraintes dures : courses des axes, dégagement opératrice, bords haut/bas, tous les
points atteignables. Une configuration qui en viole une n'est jamais retenue.

Méthode : grille grossière sur tout le domaine (702 points) -> 3 meilleurs départs distincts
-> recherche par motifs (Hooke-Jeeves simplifiée) avec réduction du pas jusqu'à la résolution
des vérins (1 mm, 0,25°) -> critère de convergence = pas minimal atteint sans amélioration.
Entièrement déterministe : mêmes entrées, même résultat.
"""
from __future__ import annotations

import math
import time

from smart_jig import (AXIS_LIMITS, TAKT_TIME_S, Body, JigConfig, move_time, validate_body)
from ergonomics import (GAZE_RANGE, BOARD_SLOPE_LEN, board_point, evaluate, gaze_angle,
                        geometry_checks, point_metrics)

DEFAULT_WEIGHTS = {"epaule": 1.0, "allonge": 0.8, "cou": 0.5, "deplacement": 0.05}
WEIGHT_BOUNDS = (0.0, 5.0)

COARSE_STEP = {"h": 0.05, "a": 5.0, "d": 0.05}
START_STEP = {"h": 0.04, "a": 4.0, "d": 0.04}
MIN_STEP = {"h": 0.0025, "a": 0.25, "d": 0.0025}
MAX_ITER = 400
N_STARTS = 3

ANALYSIS_LIMITS = [
    "Modèle cinématique à deux segments par bras, tronc vertical et immobile ; coude placé au plus bas.",
    "Répartition des tâches sur le gabarit supposée gaussienne et centrée (σ = 25 cm) : à remplacer par la carte d'activité mesurée.",
    "Le bras utilisé est le plus proche du point ; le travail bimanuel réel n'est pas modélisé finement.",
    "Ni la force, ni la fréquence, ni la durée de maintien ne sont prises en compte (pas de RULA, REBA ou EN 1005-4 complet).",
    "Configuration initiale = hypothèse de démonstration tant qu'elle n'a pas été relevée sur le poste.",
    "Profils de référence britanniques (Bodyspace) ; longueurs de segments proportionnelles (Winter).",
    "Gabarit et vérins simulés : aucun déplacement physique n'est réalisé.",
]


def _shoulder_pen(e):
    if e <= 20: return 0.0
    if e <= 45: return (e - 20) / 25
    if e <= 90: return 1 + 2 * (e - 45) / 45
    return 3 + (e - 90) / 30


def _reach_pen(r):
    return 2 * max(0.0, r - 0.85) / 0.15 + 1.5 * max(0.0, 0.45 - r) / 0.45


def components(body: Body, c: JigConfig, init: JigConfig, pm=None) -> dict:
    pm = pm or point_metrics(body, c)
    g = gaze_angle(body, board_point(c, 0, 0))
    g_top = gaze_angle(body, board_point(c, BOARD_SLOPE_LEN / 2, 0))
    neck = max(0.0, GAZE_RANGE[0] - g) / 15 + max(0.0, g - GAZE_RANGE[1]) / 15 + max(0.0, -g_top) / 30
    mv = sum(abs(getattr(c, k) - getattr(init, k)) / (AXIS_LIMITS[k][1] - AXIS_LIMITS[k][0]) for k in "had") / 3
    return {"epaule": sum(p["w"] * _shoulder_pen(p["elev"]) for p in pm),
            "allonge": sum(p["w"] * _reach_pen(p["reach"]) for p in pm),
            "cou": neck, "deplacement": mv}


def objective(body, c, init, w, with_details=False):
    pm = point_metrics(body, c)
    feasible = all(k["ok"] for k in geometry_checks(c)) and all(p["reachable"] for p in pm)
    comp = components(body, c, init, pm)
    J = sum(w[k] * comp[k] for k in w)
    if with_details:
        return J, feasible, comp
    return (J if feasible else math.inf), feasible


def _violation(body, c):
    """Somme normalisée des violations de contraintes (pour classer les solutions infaisables)."""
    v = 0.0
    for k in geometry_checks(c):
        if not k["ok"] and "value" in k:
            lim = float(k["limit"].split()[1])
            v += abs(k["value"] - lim)
        elif not k["ok"]:
            v += 1
    v += sum(1 for p in point_metrics(body, c) if not p["reachable"]) * 0.01
    return v


def _clamp(c: JigConfig) -> JigConfig:
    f = lambda k: min(AXIS_LIMITS[k][1], max(AXIS_LIMITS[k][0], getattr(c, k)))
    return JigConfig(f("h"), f("a"), f("d"))


def _frange(lo, hi, st):
    n = int(round((hi - lo) / st))
    return [round(lo + i * st, 6) for i in range(n + 1)]


def _pattern_search(body, start, init, w):
    best = start
    bJ, _ = objective(body, best, init, w)
    step = dict(START_STEP)
    hist, it, evals = [bJ], 0, 1
    while it < MAX_ITER:
        it += 1
        improved = False
        for k in "had":
            for sgn in (1, -1):
                cand = _clamp(JigConfig(**{**best.__dict__, k: getattr(best, k) + sgn * step[k]}))
                J, _ = objective(body, cand, init, w)
                evals += 1
                if J < bJ - 1e-9:
                    best, bJ, improved = cand, J, True
        hist.append(bJ)
        if not improved:
            if all(step[k] <= MIN_STEP[k] + 1e-12 for k in step):
                return best, bJ, {"converged": True, "iterations": it, "evaluations": evals, "history": hist}
            step = {k: max(MIN_STEP[k], step[k] / 2) for k in step}
    return best, bJ, {"converged": False, "iterations": it, "evaluations": evals, "history": hist}


def check_weights(w: dict | None) -> dict:
    w = {**DEFAULT_WEIGHTS, **(w or {})}
    unknown = set(w) - set(DEFAULT_WEIGHTS)
    if unknown:
        raise ValueError(f"Poids inconnus : {', '.join(sorted(unknown))}")
    for k, v in w.items():
        if not isinstance(v, (int, float)) or not WEIGHT_BOUNDS[0] <= v <= WEIGHT_BOUNDS[1]:
            raise ValueError(f"Poids {k} = {v} hors de [{WEIGHT_BOUNDS[0]}, {WEIGHT_BOUNDS[1]}].")
    if w["epaule"] + w["allonge"] + w["cou"] <= 0:
        raise ValueError("Au moins un poids ergonomique (épaule, allonge, cou) doit être positif.")
    return {k: float(v) for k, v in w.items()}


def optimise(body: Body, initial: JigConfig | dict | None = None, weights: dict | None = None) -> dict:
    """Réglage optimal. Retourne configurations, valeurs de J, indicateurs avant/après,
    statut de faisabilité, convergence et limites de l'analyse."""
    from smart_jig import DEFAULT_INITIAL
    t0 = time.perf_counter()
    init = JigConfig.from_dict(initial) if isinstance(initial, dict) else (initial or JigConfig(**DEFAULT_INITIAL))
    w = check_weights(weights)
    val = validate_body(body)
    base = {"weights": w, "validation": val.to_dict(), "limits": ANALYSIS_LIMITS, "body": body.to_dict()}
    if not val.ok:
        return {**base, "status": "donnees_invalides", "message": "Optimisation refusée : mesures anthropométriques invalides.",
                "initial": None, "optimal": None, "compute_ms": round((time.perf_counter() - t0) * 1000, 1)}

    def pack(c):
        J, feas, comp = objective(body, c, init, w, with_details=True)
        ev = evaluate(body, c)
        return {"config": c.as_dict(), "J": round(J, 4), "components": {k: round(v, 4) for k, v in comp.items()},
                "feasible": feas, "indicators": ev["indicators"], "evaluations": ev["evaluations"],
                "constraints": ev["constraints"], "points": ev["points"]}

    initial_pack = pack(init)

    # 1. Grille grossière
    coarse = []
    for h in _frange(*AXIS_LIMITS["h"], COARSE_STEP["h"]):
        for a in _frange(*AXIS_LIMITS["a"], COARSE_STEP["a"]):
            for d in _frange(*AXIS_LIMITS["d"], COARSE_STEP["d"]):
                c = JigConfig(h, a, d)
                J, feas = objective(body, c, init, w)
                coarse.append((J, c, feas))
    feasible = sorted([x for x in coarse if x[2]], key=lambda x: (x[0], x[1].h, x[1].a, x[1].d))

    if not feasible:
        least = min(coarse, key=lambda x: (_violation(body, x[1]), x[1].h, x[1].a, x[1].d))[1]
        best_pack = pack(least)
        return {**base, "status": "infaisable",
                "message": "Aucun réglage ne respecte toutes les contraintes pour cette morphologie. "
                           "Réglage le moins contraint affiché à titre d'information ; pistes : allonger la course "
                           "des vérins, réduire la hauteur utile du gabarit, plateforme réglable.",
                "initial": initial_pack, "optimal": best_pack, "convergence": None,
                "move_time_s": None, "compute_ms": round((time.perf_counter() - t0) * 1000, 1)}

    # 2. Départs distincts (au moins un pas grossier d'écart sur un axe)
    starts = []
    for J, c, _ in feasible:
        if all(max(abs(c.h - s.h) / COARSE_STEP["h"], abs(c.a - s.a) / COARSE_STEP["a"], abs(c.d - s.d) / COARSE_STEP["d"]) > 1.01 for s in starts):
            starts.append(c)
        if len(starts) == N_STARTS:
            break

    # 3. Recherche locale depuis chaque départ
    runs = []
    for s in starts:
        c, J, info = _pattern_search(body, s, init, w)
        cq = c.quantized()
        Jq, feas_q = objective(body, cq, init, w)
        if feas_q:
            c, J = cq, Jq
        runs.append({"config": c, "J": J, **info, "start": s.as_dict()})
    runs.sort(key=lambda r: (round(r["J"], 6), r["config"].h, r["config"].a, r["config"].d))
    best = runs[0]
    convergence = {"converged": all(r["converged"] for r in runs), "starts": len(runs),
                   "evaluations": len(coarse) + sum(r["evaluations"] for r in runs),
                   "iterations": best["iterations"], "history": [round(x, 5) for x in best["history"]],
                   "spread_J": round(runs[-1]["J"] - best["J"], 5),
                   "local_optima": [{"config": r["config"].as_dict(), "J": round(r["J"], 5)} for r in runs]}

    # 4. Comparaison honnête avec la configuration initiale
    J_init = initial_pack["J"] if initial_pack["feasible"] else math.inf
    if best["J"] >= J_init - 1e-4:
        status, opt_cfg = "deja_optimal", init
        msg = "La configuration initiale est déjà la meilleure trouvée : aucun réglage n'est recommandé."
    else:
        status, opt_cfg = "optimal", best["config"]
        msg = "Réglage optimal trouvé et conforme à toutes les contraintes."
        if not initial_pack["feasible"]:
            msg += " La configuration initiale viole au moins une contrainte."
    opt_pack = pack(opt_cfg)
    mt = move_time(init, opt_cfg)
    opt_pack["constraints"].append({"id": "takt", "label": "Réglage plus court que le takt time", "ok": mt <= TAKT_TIME_S,
                                    "value": round(mt, 1), "limit": f"≤ {TAKT_TIME_S:.0f} s"})
    if not convergence["converged"]:
        msg += " Attention : la recherche n'a pas convergé (nombre maximal d'itérations atteint)."
    return {**base, "status": status, "message": msg, "initial": initial_pack, "optimal": opt_pack,
            "convergence": convergence, "move_time_s": round(mt, 1),
            "compute_ms": round((time.perf_counter() - t0) * 1000, 1)}
