"""
ErgoGuard AI – Smart Jig : modèle biomécanique et évaluation ergonomique
=======================================================================

Deux niveaux sont volontairement séparés :

1. INDICATEURS BIOMÉCANIQUES SIMPLIFIÉS (utilisés par l'optimiseur)
   Modèle des membres supérieurs à deux segments (bras, avant-bras + main), coude placé
   au plus bas (posture naturelle), tronc vertical et immobile. Pour chaque point de la
   zone de travail du gabarit : élévation de l'épaule, flexion du coude, allonge.
   Les points sont pondérés par une hypothèse de répartition des tâches (gaussienne
   centrée, σ = 25 cm) : « part pondérée des points » n'est PAS un temps mesuré.

2. ÉVALUATIONS NORMATIVES (registre extensible `EVALUATORS`)
   - items isolés de la grille RULA (bras, avant-bras) : ce ne sont PAS des scores RULA ;
   - ISO 11226 étape 1 pour l'élévation du bras (durée de maintien inconnue) ;
   - RULA complet : déclaré non calculable, avec la liste des données manquantes ;
   - REBA : emplacement prévu, non implémenté.
"""
from __future__ import annotations

import math

from smart_jig import (BOARD_SLOPE_LEN, WORK_HALF_WIDTH, EYE_FORWARD, MIN_BODY_CLEARANCE,
                       MIN_BOTTOM_EDGE_H, MAX_TOP_EDGE_H, Body, JigConfig, config_limit_errors)

GRID_S, GRID_L = 7, 5      # points de travail : 7 le long de la pente × 5 en largeur
TASK_SIGMA = 0.25          # m : hypothèse de concentration des tâches au centre (encliquetage)
GAZE_RANGE = (15.0, 35.0)  # ° sous l'horizontale : zone de confort visuel usuelle pour un travail debout


# ----------------------------------------------------------------------------------------
# Géométrie du gabarit
# ----------------------------------------------------------------------------------------
def board_point(c: JigConfig, s: float, l: float, offset: float = 0.0):
    """Point du gabarit : s le long de la pente (haut > 0), l latéral, offset le long de la
    normale tournée vers l'opératrice."""
    a = math.radians(c.a)
    return (l, c.h + s * math.cos(a) + offset * math.sin(a), c.d + s * math.sin(a) - offset * math.cos(a))


def work_points(c: JigConfig):
    pts, wsum = [], 0.0
    for i in range(GRID_S):
        s = -BOARD_SLOPE_LEN / 2 + i * BOARD_SLOPE_LEN / (GRID_S - 1)
        for j in range(GRID_L):
            l = -WORK_HALF_WIDTH + j * 2 * WORK_HALF_WIDTH / (GRID_L - 1)
            w = math.exp(-(s / TASK_SIGMA) ** 2 - (l / TASK_SIGMA) ** 2)
            wsum += w
            pts.append({"s": s, "l": l, "w": w, "p": board_point(c, s, l)})
    for p in pts:
        p["w"] /= wsum
    return pts


# ----------------------------------------------------------------------------------------
# Cinématique inverse du membre supérieur
# ----------------------------------------------------------------------------------------
def _sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def _norm(v): return math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)


def arm_ik(body: Body, target, side: int = 1) -> dict:
    """IK deux segments. Le coude est placé au plus bas dans le plan contenant épaule et cible.
    Retourne : élévation de l'épaule (° depuis le bras pendant), flexion du coude (0 = tendu),
    rapport d'allonge (distance / longueur du membre), atteignabilité et positions des articulations."""
    sh = (side * body.shoulder_half, body.shoulder_joint_h, 0.0)
    v = _sub(target, sh)
    r = _norm(v)
    lu, lf = body.upper_arm, body.forearm_grip
    u = (v[0] / r, v[1] / r, v[2] / r)
    reach = r / (lu + lf)
    if r >= lu + lf:                    # hors d'atteinte : bras tendu vers la cible
        up, flex, reachable = u, 0.0, False
        hand = tuple(sh[i] + u[i] * (lu + lf) for i in range(3))
    else:
        r_ = max(r, abs(lu - lf) + 1e-3)
        cb = max(-1.0, min(1.0, (lu * lu + r_ * r_ - lf * lf) / (2 * lu * r_)))
        beta = math.acos(cb)
        dd = -u[1]                       # projection de la verticale descendante hors de l'axe épaule-cible
        perp = (-dd * u[0], -1 - dd * u[1], -dd * u[2])
        n = _norm(perp)
        perp = (perp[0] / n, perp[1] / n, perp[2] / n) if n > 1e-6 else (0.0, 0.0, -1.0)
        up = tuple(math.cos(beta) * u[i] + math.sin(beta) * perp[i] for i in range(3))
        ce = max(-1.0, min(1.0, (lu * lu + lf * lf - r_ * r_) / (2 * lu * lf)))
        flex, reachable, hand = 180.0 - math.degrees(math.acos(ce)), True, tuple(target)
    elev = math.degrees(math.acos(max(-1.0, min(1.0, -up[1]))))
    elbow = tuple(sh[i] + up[i] * lu for i in range(3))
    return {"elev": elev, "flex": flex, "reach": reach, "reachable": reachable,
            "sh": sh, "el": elbow, "ha": hand}


def gaze_angle(body: Body, point) -> float:
    """Angle (°) sous l'horizontale de la ligne œil -> point (négatif = au-dessus des yeux)."""
    eye = (0.0, body.eye_h, EYE_FORWARD)
    return math.degrees(math.atan2(eye[1] - point[1], max(1e-6, point[2] - eye[2])))


# ----------------------------------------------------------------------------------------
# Analyse d'une configuration
# ----------------------------------------------------------------------------------------
def point_metrics(body: Body, c: JigConfig):
    """Calcul de base, partagé par l'optimiseur et l'évaluation (bras le plus proche)."""
    out = []
    for p in work_points(c):
        k = arm_ik(body, p["p"], 1 if p["l"] >= 0 else -1)
        out.append({"s": p["s"], "l": p["l"], "w": p["w"], "elev": k["elev"], "flex": k["flex"],
                    "reach": k["reach"], "reachable": k["reachable"]})
    return out


def geometry_checks(c: JigConfig) -> list:
    """Contraintes mécaniques et géométriques. Chaque contrainte : id, libellé, respectée ?, valeur, limite."""
    a = math.radians(c.a)
    half = BOARD_SLOPE_LEN / 2
    near_z = min(c.d - half * math.sin(a), c.d + half * math.sin(a))
    bottom = c.h - half * math.cos(a)
    top = c.h + half * math.cos(a)
    lim = config_limit_errors(c)
    return [
        {"id": "axes", "label": "Consignes dans la course des 3 vérins", "ok": not lim, "detail": "; ".join(lim) or "H, A, D dans les limites"},
        {"id": "clearance", "label": "Dégagement gabarit / opératrice", "ok": near_z >= MIN_BODY_CLEARANCE - 1e-9,
         "value": round(near_z, 3), "limit": f"≥ {MIN_BODY_CLEARANCE:.2f} m"},
        {"id": "bottom", "label": "Bord bas au-dessus du bâti", "ok": bottom >= MIN_BOTTOM_EDGE_H - 1e-9,
         "value": round(bottom, 3), "limit": f"≥ {MIN_BOTTOM_EDGE_H:.2f} m"},
        {"id": "top", "label": "Bord haut sous le bâti", "ok": top <= MAX_TOP_EDGE_H + 1e-9,
         "value": round(top, 3), "limit": f"≤ {MAX_TOP_EDGE_H:.2f} m"},
    ]


def _wmean(pm, key):
    return sum(p["w"] * p[key] for p in pm)


def _share(pm, pred):
    return 100.0 * sum(p["w"] for p in pm if pred(p))


def indicators(body: Body, c: JigConfig, pm=None) -> dict:
    pm = pm or point_metrics(body, c)
    centre = board_point(c, 0, 0)
    top = board_point(c, BOARD_SLOPE_LEN / 2, 0)
    bottom = board_point(c, -BOARD_SLOPE_LEN / 2, 0)
    unreach = [p for p in pm if not p["reachable"]]
    g = gaze_angle(body, centre)
    return {
        "shoulder": {
            "mean": round(_wmean(pm, "elev"), 1),
            "max": round(max(p["elev"] for p in pm), 1),
            "share_above_20": round(_share(pm, lambda p: p["elev"] > 20), 1),
            "share_above_45": round(_share(pm, lambda p: p["elev"] > 45), 1),
            "share_above_60": round(_share(pm, lambda p: p["elev"] > 60), 1),
            "bins": {"0-20": round(_share(pm, lambda p: p["elev"] <= 20), 1),
                     "20-45": round(_share(pm, lambda p: 20 < p["elev"] <= 45), 1),
                     "45-90": round(_share(pm, lambda p: 45 < p["elev"] <= 90), 1),
                     ">90": round(_share(pm, lambda p: p["elev"] > 90), 1)},
        },
        "elbow": {
            "mean": round(_wmean(pm, "flex"), 1),
            "share_outside_60_100": round(_share(pm, lambda p: not 60 <= p["flex"] <= 100), 1),
        },
        "reach": {
            "max_ratio": round(max(p["reach"] for p in pm), 3),
            "share_above_085": round(_share(pm, lambda p: p["reach"] > 0.85), 1),
            "unreachable_points": len(unreach),
        },
        "gaze": {
            "centre": round(g, 1), "top": round(gaze_angle(body, top), 1), "bottom": round(gaze_angle(body, bottom), 1),
            "centre_in_range": GAZE_RANGE[0] <= round(g) <= GAZE_RANGE[1],
            "range": list(GAZE_RANGE),
        },
        "weighting": "Part pondérée des points de travail (hypothèse : tâches concentrées au centre, σ = 25 cm) — pas un temps mesuré.",
    }


# ----------------------------------------------------------------------------------------
# Évaluations normatives (registre extensible)
# ----------------------------------------------------------------------------------------
def _rula_upper_arm_item(elev):
    return 4 if elev > 90 else 3 if elev > 45 else 2 if elev > 20 else 1


def eval_rula_items(body, c, pm):
    ua = sum(p["w"] * _rula_upper_arm_item(p["elev"]) for p in pm)
    fa = sum(p["w"] * (1 if 60 <= p["flex"] <= 100 else 2) for p in pm)
    return {"name": "Items isolés de la grille RULA", "status": "partiel",
            "values": {"item_bras_moyen": round(ua, 2), "item_avant_bras_moyen": round(fa, 2)},
            "note": "Moyennes pondérées des items « bras » (1–4) et « avant-bras » (1–2) seuls, sans ajustements "
                    "(épaule surélevée, abduction, appui) : ce n'est PAS un score RULA."}


def eval_iso11226_arm(body, c, pm):
    return {"name": "ISO 11226 — élévation du bras, étape 1", "status": "partiel",
            "values": {"acceptable_<=20": round(_share(pm, lambda p: p["elev"] <= 20), 1),
                       "sous_conditions_20-60": round(_share(pm, lambda p: 20 < p["elev"] <= 60), 1),
                       "non_recommande_>60": round(_share(pm, lambda p: p["elev"] > 60), 1)},
            "note": "Postures statiques. La zone 20–60° dépend de la durée de maintien (étape 2), inconnue ici ; "
                    "le travail réel est répétitif (EN 1005-4 plus adaptée)."}


def eval_rula_full(body, c, pm):
    return {"name": "RULA complet", "status": "non_calculable",
            "missing": ["angles et torsion du poignet", "flexion du cou et du tronc mesurées",
                        "appui des jambes", "utilisation musculaire (répétitivité / maintien)", "force ou charge"],
            "note": "Calculable avec le module vision ErgoGuard (posture complète mesurée au poste) — non simulé ici."}


def eval_reba(body, c, pm):
    return {"name": "REBA", "status": "non_implemente",
            "note": "Emplacement prévu : mêmes données manquantes que RULA, plus le tronc et les jambes."}


EVALUATORS = {"rula_items": eval_rula_items, "iso11226_bras": eval_iso11226_arm,
              "rula_complet": eval_rula_full, "reba": eval_reba}


# ----------------------------------------------------------------------------------------
# Postures pour l'affichage 3D (calculées ici : le frontend ne fait aucune cinématique)
# ----------------------------------------------------------------------------------------
def _r(t): return [round(x, 4) for x in t]


def _arm_pose(body, target, side):
    k = arm_ik(body, target, side)
    return {"sh": _r(k["sh"]), "el": _r(k["el"]), "ha": _r(k["ha"]),
            "elev": round(k["elev"], 1), "flex": round(k["flex"], 1), "reach": round(k["reach"], 3)}


def display_postures(body: Body, c: JigConfig) -> dict:
    """Postures des deux bras pour chaque point de travail (main droite au point, main gauche
    en appui à côté) et posture de repos (mains hors du gabarit pendant les déplacements)."""
    poses = []
    for p in work_points(c):
        rt = board_point(c, p["s"], p["l"] + 0.05, 0.04)
        lt = board_point(c, p["s"] - 0.03, p["l"] - 0.08, 0.04)
        poses.append({"s": round(p["s"], 3), "l": round(p["l"], 3), "R": _arm_pose(body, rt, 1), "L": _arm_pose(body, lt, -1)})
    y = body.shoulder_joint_h - body.upper_arm - body.forearm_grip + 0.03
    rest = {"R": _arm_pose(body, (body.shoulder_half + 0.01, y, 0.03), 1),
            "L": _arm_pose(body, (-body.shoulder_half - 0.01, y, 0.03), -1)}
    return {"work": poses, "rest": rest}


def evaluate(body: Body, h: float | JigConfig, a: float | None = None, d: float | None = None,
             with_postures: bool = False) -> dict:
    """Évaluation complète d'une configuration. Signature v1 conservée : evaluate(body, h, a, d)."""
    c = h if isinstance(h, JigConfig) else JigConfig(h, a, d)
    pm = point_metrics(body, c)
    out = {"config": c.as_dict(), "indicators": indicators(body, c, pm),
           "evaluations": {k: f(body, c, pm) for k, f in EVALUATORS.items()},
           "constraints": geometry_checks(c),
           "points": [{"s": round(p["s"], 3), "l": round(p["l"], 3), "w": round(p["w"], 4), "elev": round(p["elev"], 1),
                       "flex": round(p["flex"], 1), "reach": round(p["reach"], 3)} for p in pm]}
    out["constraints"].append({"id": "reach", "label": "Tous les points de travail atteignables",
                               "ok": out["indicators"]["reach"]["unreachable_points"] == 0,
                               "value": out["indicators"]["reach"]["unreachable_points"], "limit": "0 point hors d'atteinte"})
    out["feasible"] = all(k["ok"] for k in out["constraints"])
    if with_postures:
        out["postures"] = display_postures(body, c)
    return out
